/* Metrowerks ARM Runtime Support Library 
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2003/03/18 17:57:08 $
 * $Revision: 1.1 $
 */

#ifndef _ALLOCA_H 
#define _ALLOCA_H

#define alloca __alloca

#endif /* _ALLOCA_H  */

/* Change record:
 * cc  010409 moved alloca from malloc.h
 */