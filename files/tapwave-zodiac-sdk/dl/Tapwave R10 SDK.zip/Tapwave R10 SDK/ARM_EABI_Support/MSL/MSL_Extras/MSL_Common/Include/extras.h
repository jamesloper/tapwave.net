/* Metrowerks Standard Library
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2003/06/03 15:37:24 $
 * $Revision: 1.11 $
 */

#ifndef _MSL_EXTRAS_H
#define _MSL_EXTRAS_H
      					
#include <ansi_parms.h>
#include <size_t.h>
#include <unistd.h> 	
#include <null.h>
#include <stdio.posix.h>  /* need this for fileno */

#if (__dest_os == __win32_os || __dest_os == __wince_os)
	#include <extras.win32.h>
#endif
	
#if _MSL_WIDE_CHAR		
		#include <wchar_t.h>
#endif

_MSL_BEGIN_EXTERN_C

	_MSL_IMP_EXP_C	int _MSL_CDECL stricmp(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL strnicmp(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL strcmpi(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL strncmpi(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	int	_MSL_CDECL strcasecmp (const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	int	_MSL_CDECL strncasecmp(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL strset(char *, int ) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL strnset(char *, int , __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL strrev(char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL strupr(char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL strspnp(char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C  char * _MSL_CDECL strlwr (char *) _MSL_CANT_THROW; 
	_MSL_IMP_EXP_C  char * _MSL_CDECL strdate(char *str) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C  char * _MSL_CDECL strdup(const char *str) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL stricoll(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL strncoll(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL strnicoll(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C  int _MSL_CDECL  heapmin(void) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C  char * _MSL_CDECL itoa(int, char *, int) _MSL_CANT_THROW;  
	_MSL_IMP_EXP_C  int _MSL_CDECL filelength(int fileno) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C  char * _MSL_CDECL ultoa(unsigned long, char *, int) _MSL_CANT_THROW;
	
	#ifndef _No_Disk_File_OS_Support
	_MSL_IMP_EXP_C  int _MSL_CDECL chsize(int,long) _MSL_CANT_THROW;		/*- cc 010924 -*/
	#endif
	
	_MSL_IMP_EXP_C	int _MSL_CDECL _stricmp(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strnicmp(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strcmpi(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strncmpi(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;	
	_MSL_IMP_EXP_C 	int	_MSL_CDECL _strcasecmp (const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	int	_MSL_CDECL _strncasecmp(const char *, const char *,  __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strrev(char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strupr(char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strset(char *, int ) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strnset(char *, int , __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	char * _MSL_CDECL _strspnp(char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _strdate(char *str) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _strdup(const char *str) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _strlwr (char *) _MSL_CANT_THROW; 
	_MSL_IMP_EXP_C	int _MSL_CDECL _stricoll(const char *, const char *) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strncoll(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C	int _MSL_CDECL _strnicoll(const char *, const char *, __std(size_t)) _MSL_CANT_THROW;

	_MSL_IMP_EXP_C  int _MSL_CDECL _heapmin(void) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _itoa(int, char *, int) _MSL_CANT_THROW; 
	_MSL_IMP_EXP_C  int _MSL_CDECL _filelength(int fileno) _MSL_CANT_THROW;
	_MSL_IMP_EXP_C 	char * _MSL_CDECL _ultoa(unsigned long, char *, int) _MSL_CANT_THROW; 
	
	#ifndef _No_Disk_File_OS_Support
	#if	(__dest_os	== __win32_os || __dest_os == __mac_os)
	_MSL_IMP_EXP_C  int _MSL_CDECL _chsize(int,long) _MSL_CANT_THROW;						/*- cc 010924 -*/
	#endif

	#endif
	
	__inline char* _MSL_CDECL ltoa(int x, char *y, int z) _MSL_CANT_THROW	{ return (itoa(x, y, z)); }
	
	#ifndef _No_Disk_File_OS_Support
	__inline long _MSL_CDECL tell(int fildes) _MSL_CANT_THROW				{ return (lseek(fildes, 0L, SEEK_CUR)); }
	#endif
	
	__inline char* _MSL_CDECL _ltoa(int x, char *y, int z) _MSL_CANT_THROW	{ return (itoa(x, y, z)); }
	
	#ifndef _No_Disk_File_OS_Support
	__inline long _MSL_CDECL _tell(int fildes) _MSL_CANT_THROW			{ return (lseek(fildes, 0L, SEEK_CUR)); }
	#endif
			
	#ifndef _No_Floating_Point
		_MSL_IMP_EXP_C char * _MSL_CDECL gcvt(double, int, char *) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C char * _MSL_CDECL _gcvt(double, int, char *) _MSL_CANT_THROW; 
	#endif
		
	#define _MAX_DRIVE  3   /* max. length of drive component */
	#define _MAX_DIR    256 /* max. length of path component */
	#define _MAX_EXT    256 /* max. length of extension component */
	#define _MAX_FNAME 256
	#define __max(a,b)  (((a) > (b)) ? (a) : (b))
	#define __min(a,b)  (((a) < (b)) ? (a) : (b))
	
	#if _MSL_WIDE_CHAR				
		
		_MSL_IMP_EXP_C	wchar_t * _MSL_CDECL itow(int, wchar_t *, int) _MSL_CANT_THROW; 				
	    _MSL_IMP_EXP_C		int   _MSL_CDECL wtoi(const wchar_t *_a) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C		int   _MSL_CDECL wcsicmp(const wchar_t *s1, const wchar_t *s2) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C		int   _MSL_CDECL wcsnicmp(const wchar_t *s1, const wchar_t *s2, __std(size_t) n) _MSL_CANT_THROW; 
	    _MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wstrrev(wchar_t * str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wcsrev(wchar_t *str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wcsupr(wchar_t *str) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wcslwr(wchar_t *str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wcsset(wchar_t *str, wchar_t wc) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wcsnset(wchar_t *str, wchar_t wc, __std(size_t) n) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wcsspnp(const wchar_t *s1, const wchar_t *s2) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL wcsdup (const wchar_t *str) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL wcsicoll(const wchar_t *, const wchar_t *) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL wcsncoll(const wchar_t *, const wchar_t *, __std(size_t)) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL wcsnicoll(const wchar_t *, const wchar_t *, __std(size_t)) _MSL_CANT_THROW;
		
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _itow(int, wchar_t *, int) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wtoi(const wchar_t *_a) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 		int	  _MSL_CDECL _wcsicmp(const wchar_t *s1, const wchar_t *s2) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsnicmp(const wchar_t *s1, const wchar_t *s2, __std(size_t) n) _MSL_CANT_THROW; 
	    _MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wstrrev(wchar_t * str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsrev(wchar_t *str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsupr(wchar_t *str) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcslwr(wchar_t *str) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsset(wchar_t *str, wchar_t wc) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsnset(wchar_t *str, wchar_t wc, __std(size_t) n) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsspnp(const wchar_t *s1, const wchar_t *s2) _MSL_CANT_THROW; 
		_MSL_IMP_EXP_C 	wchar_t * _MSL_CDECL _wcsdup (const wchar_t *str) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsicoll(const wchar_t *, const wchar_t *) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsncoll(const wchar_t *, const wchar_t *, __std(size_t)) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C 		int   _MSL_CDECL _wcsnicoll(const wchar_t *, const wchar_t *, __std(size_t)) _MSL_CANT_THROW;
		_MSL_IMP_EXP_C   double   _MSL_CDECL watof(const wchar_t * ) _MSL_CANT_THROW; 
  
	#endif  /* #if _MSL_WIDE_CHAR	*/

_MSL_END_EXTERN_C
	
#endif  /* _MSL_EXTRAS_H */

/* Change record:
 * cc  000428 moved _tell to extras.win32.h 
 * cc  000428 readded #include <unistd.h>
 * cc  000428 reremoved #include <unistd.h>
 * cc  000511 added  _heapmin to extras.h
 * cc  000516 moved __myraise to unix.h
 * cc  000828 removed raise from extras. and left it in csignal
 * cc  010306 added _tell
 * cc  010405 removed pragma options align native and reset	 
 * cc  010409 updated defines to JWW new namespace macros 
 * cc  010517 renamed _lseek to lseek 	
 * cc  010713 renamed all the _functions to non-underscored.
 * cc  010713 added strcasecmp and strncasecmp for Ed 
 * cc  010714 added strcmpi and strncmpi
 * cc  010715 added the underscore version of the functions
 * cc  010910 removed strlen and strcpy they are in cstring
 * cc  010924 added Hisham's version of chsize  
 * ejs 011128 Added strcoll/wcscoll variants
 * cc  011203 Added _MSL_CDECL for new name mangling 
 * hh  020603 Added no throw spec to functions
 * cc  021029 Added _No_Disk_File_OS_Support 
 * cc  021119 Moved watof from the C lib to extras
 * JWW 030224 Changed __NO_WIDE_CHAR flag into the new more configurable _MSL_WIDE_CHAR
 */