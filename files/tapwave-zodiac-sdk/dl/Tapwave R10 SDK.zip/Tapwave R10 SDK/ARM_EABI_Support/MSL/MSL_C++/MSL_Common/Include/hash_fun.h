/* Metrowerks Standard Library
 * Copyright � 1995-2003 Metrowerks Corporation.  All rights reserved.
 *
 * $Date: 2003/01/14 21:35:29 $
 * $Revision: 1.7 $
 */

// hash_fun.h

/*
	WARNING - WARNING - WARNING

	This header is NON-STANDARD

	The classes herein are offered as extensions to the C++ standard.
	They are marked as such by the namespace Metrowerks.
*/

#ifndef _HASH_FUN_H
#define _HASH_FUN_H

#include <hash_fun>

#ifndef _MSL_NO_CPP_NAMESPACE
	using Metrowerks::hash;
#endif

#endif  // _HASH_FUN_H

// hh 991120 Created
