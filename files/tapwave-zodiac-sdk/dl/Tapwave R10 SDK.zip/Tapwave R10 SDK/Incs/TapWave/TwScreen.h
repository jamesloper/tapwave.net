/* Copyright (c) 2002-2003 Tapwave, Inc. All rights reserved. */

#ifndef __TWSCREEN_H__
#define __TWSCREEN_H__

#include <PalmOS.h>

#ifdef __cplusplus
extern "C" {
#endif


/*
 *  API's to get/set Display State.
 */

    
#define twHoldNone     0x00000000   // Normal mode, device running, will sleep if asked 
#define twHoldRequest  0x00000001   // Hold mode requested, device running, will not sleep but display will turn off
#define twHoldInvoke   0x00000002   // Hold mode invoked, display is off 
#define twHoldLock     0x00000004   // don't let EvtResetAutoOffTimer exit hold mode,
                                    // to unlock do TwSetHoldState with twHoldRequest, twHoldNone, or twHoldWake 
#define twHoldWake     0x00000008   // force device to wake up, exits both 'invoke' and 'lock' and leaves state in 'request'
#define twHoldSleeping 0x00000010   // internal flag used when switching from hold to sleep

Int32 TwGetHoldState (void)
    TAL_TRAP(trapTwGetHoldState);
 
Err  TwSetHoldState (Int32 state)
    TAL_TRAP(trapTwSetHoldState);


#ifdef __cplusplus
}
#endif

#endif /* __TWSCREEN_H__ */
