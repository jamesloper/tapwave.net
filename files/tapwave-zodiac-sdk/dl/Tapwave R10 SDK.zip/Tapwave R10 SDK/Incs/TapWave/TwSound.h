/* Copyright (c) 2003 Tapwave, Inc. All rights reserved. */

#ifndef __TWSOUND_H__
#define __TWSOUND_H__

#include <PalmOS.h>
#include <TwTraps.h>


#define twNotifyMuteEvent	'mute'	// broadcast when the system is muted or unmuted

typedef struct TwNotifyMuteDetailsTag {
	Int32 muted;
	UInt32 unmuteAt;
} TwNotifyMuteDetailsType;


enum TwSysBeepTag {
	// these match SysBeepTag in SoundMgr.h
	twSndInfo = 1,
	twSndWarning,
	twSndError,
	twSndStartUp,
	twSndAlarm,
	twSndConfirmation,
	twSndClick,

	// these are new TapWave additions
	twSndBumpedEdge = 200,
	twSndFollowedLink,
	twSndCardInserted,
	twSndCardRemoved,
	twSndDocked,
	twSndUndocked,
	twSndNextPage,
	twSndPrevPage,
	twSndSyncBegin,
	twSndSyncEnd,
    twSndEnter,
    twSndLaunch,
    twSndSelection,
    twSndLeave,
    twSndGraffitiOpen,
    twSndGraffitiClose,
    twSndRotate,
    twSndBluetoothOn,
    twSndBluetoothOff,
    twSndVolumeChange,
    twSndConnect,
    twSndGoDoPlay
};

typedef UInt8 TwSysBeepTagType;


#ifdef __cplusplus
extern "C" {
#endif

/*
 * Get the "master" volume.
 */
UInt16 TwSndGetVolume(void)
	TAL_TRAP(trapTwSndGetVolume);

/*
 * Set the "master" volume. The legal range for newVolume is
 * 0-sndMaxAmp. Any other value returns an error.
 */
Err TwSndSetVolume(UInt16 newVolume)
	TAL_TRAP(trapTwSndSetVolume);

/*
 * Set the mute and a time to unmuteAt. A zero value for unmuteAt
 * means mute forever.
 */
void TwSndSetMute(Boolean mute, UInt32 unmuteAt)
	TAL_TRAP(trapTwSndSetMute);

/*
 * Query the current mute setting and the time to unmuteAt. If
 * unmuteAt must be non-NULL to get the value.
 */
Boolean TwSndGetMute(UInt32 *unmuteAt)
	TAL_TRAP(trapTwSndGetMute);

/*
 * Set the bass boost level. The legal range for boostLevel is
 * 0-sndMaxAmp. Any other value returns an error.
 */
Err TwSndSetBassBoost(UInt16 boostLevel)
	TAL_TRAP(trapTwSndSetBassBoost);

/*
 * Query the current bass boost level.
 */
UInt16 TwSndGetBassBoost(void)
	TAL_TRAP(trapTwSndGetBassBoost);

/*
 * Play a system sound. Returns an error for an invalid beepID.
 * volume can be usual 0..sndMaxAmp, or one of the special values
 * sndSystemVolume, sndGameVolume, or sndAlarmVolume to use the
 * system-wide volume setting
 */
Err TwSndPlaySystemSound(TwSysBeepTagType beepID, Int16 volume)
	TAL_TRAP(trapTwSndPlaySystemSound);


/*
 * Sets up the system to play an alarm sound:
 *    all other sound channels are muted
 *    mute state is temporarily disabled
 *    the external speakers are turned on
 *    the final amplifier is set to alarm volume
 * Note: attention manager does this for you!
 */
Err TwSndSetAlarmPlaying(Boolean isAlarm)
    TAL_TRAP(trapTwSndSetAlarmPlaying);


#ifdef __cplusplus
}
#endif

#endif /* __TWSOUND_H__ */
