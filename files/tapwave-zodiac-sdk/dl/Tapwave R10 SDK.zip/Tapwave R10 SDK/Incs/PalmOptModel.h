/******************************************************************************
 *
 * Copyright (c) 1999-2002 PalmSource, Inc. All rights reserved.
 *
 * File: PalmOptModel.h
 *
 * Release: Palm OS 5 SDK (68K) R2.
 *
 *****************************************************************************/

#include <BuildDefines.h>
#ifdef MODEL
#undef MODEL
#endif
#define MODEL MODEL_GENERIC
