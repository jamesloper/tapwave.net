/* $Id: s_signgam.c,v 1.3 2002/02/11 22:54:17 ceciliar Exp $ */
#ifndef _No_Floating_Point  
#include "fdlibm.h"
_INT32 signgam = 0; /*- cc 020130 -*/
#endif