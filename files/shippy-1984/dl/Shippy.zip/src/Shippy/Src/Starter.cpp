/******************************************************************************
 *
 * File: Starter.cpp
 *
 *****************************************************************************/

#include <PalmOS.h>
#include <PCENativeCall.h>
#include <PNOLoader.h>
#include "StarterRsc.h"
#include <MemGlue.h>

/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define appFileCreator			'PDsp'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

// Define the minimum OS version we support (5.0 for now).
#define kOurMinVersion	sysMakeROMVersion(5,0,0,sysROMStageDevelopment,0)
#define kPalmOS10Version	sysMakeROMVersion(1,0,0,sysROMStageRelease,0)

enum {
  hf_pin_present = 1              // has VG
  // 2, 4, 8, 16 ...
};

static UInt32 hw_flags = 0;

/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/


/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
MemPtr GetThePNO();
MemPtr GetThePNO()
{

	UInt32 numRes = 1;
	UInt32 wholesize = 0;
	MemHandle mh;
	MemPtr wholeP;
	UInt32 offset = 0;
	MemPtr mpP;

	while(mh = DmGetResource('ARMC', numRes++))
	{
		wholesize+=MemHandleSize(mh);
		DmReleaseResource(mh);
	}
	if (numRes == 0)
		return NULL;

	if (errNone != FtrPtrNew(appFileCreator, 1, wholesize, &wholeP))
		return NULL;

	numRes = 1;

	while (mh = DmGetResource('ARMC', numRes++))
	{
		mpP = MemHandleLock(mh);
		DmWrite(wholeP, offset, mpP, MemPtrSize(mpP));
		offset += MemPtrSize(mpP);
		MemPtrUnlock(mpP);
		DmReleaseResource(mh);
	}

	return wholeP;

}

#define memNewChunkFlagNonMovable    0x0200
#define memNewChunkFlagAllowLarge    0x1000  // this is not in the sdk *g*

SysAppInfoPtr 
SysGetAppInfo(SysAppInfoPtr *uiAppPP, SysAppInfoPtr *actionCodeAppPP)
  SYS_TRAP(sysTrapSysGetAppInfo); 

/*UInt32 host_event_handler ( UInt32 arg ) {
  UInt32 a;

	a=arg;

    // memglueptrnew

    //return (UInt32) MemPtrNew ( a );
    return (UInt32) MemChunkNew ( 0,a,0x200|0x1000 );

}*/

void host_event ( void );
void host_event ( void )
{
	EventType Event;
	EvtGetEvent(&Event,0);
	SysHandleEvent(&Event);

}


UInt32 host_event_handler ( UInt32 size );
UInt32 host_event_handler ( UInt32 size ) {
  SysAppInfoPtr appInfoP;
  UInt16        ownerID;


  //ownerID =((SysAppInfoPtr)SysGetAppInfo(&appInfoP, &appInfoP))->memOwnerID;

 // return (UInt32)MemChunkNew ( 0, size, ownerID | memNewChunkFlagNonMovable | memNewChunkFlagAllowLarge );

	return (UInt32)MemGluePtrNew(size);
}

static void hw_set_fullscreen ( UInt8 fullscreenp ) 
{
	EventType event;

  if ( fullscreenp ) {

    if ( hw_flags & hf_pin_present ) 
    {
        PINSetInputAreaState ( pinInputAreaClosed );
      	StatHide();
	    EvtGetEvent(&event,0);
	    while(event.eType != nilEvent)
	    {
	    	EvtGetEvent(&event,0);
	    	SysHandleEvent(&event);
	    }

    }

  } else {

    if ( hw_flags & hf_pin_present ) {
      StatShow();
    }

  }

  return;
}

void hw_guess_screen_dimensions ( /*UInt32 *r_width, UInt32 *r_height,
				   UInt32 *r_pitch*/ )
{
  /* WAIT; OS5 has WinScreenGetAttribute; life is good. */
  /* Process:
   * OS < 5
   *   ZOT requires OS5.
   *   Sony?
   *     If Sony, check Sony API .. its either low res, or we can ask API
   *   Non-Sony
   *     Is it a T|W? It should have DIA..
   *     If DIA, ask it.
   *     Otherwise, low res, bail.
   * OS >= 5
   *   DIA?
   *     If so, ask it.
   *   No DIA, so.. Sony?
   *     If Sony, ask it.
   *   No DIA, No Sony...
   *     Is it Treo? IF slo, low res
   *     If not Treo, must be high res (T|T1, T|T2)
   * Now, if new low res OS5 device comes out.. sucks.
   */
  UInt32 pitch = 0;
  UInt32 width = 0;
  UInt32 height = 0;
	UInt32 deviceID;
	//char Temp1[30],Temp2[30],Temp3[30]; 

	Err devErr; 



  // is it double density or single density? this is only available in
  // Window Manager v4; OS5 includes v4 always, however.
  WinScreenGetAttribute ( winScreenRowBytes, &pitch );
  //   T|T3 returned 640b for pitch; 16bit -> 320px
  //   zodiac returns 960b; 16bit -> 480px
  WinScreenGetAttribute ( winScreenWidth, &width );
  WinScreenGetAttribute ( winScreenHeight, &height );
  // zodiac lies returns 320 width always
  
  /*StrCopy(Temp1,StrIToA(Temp1,pitch));
  StrCat(Temp1,"-");
  StrCopy(Temp2,StrIToA(Temp2,width));
  StrCat(Temp2,"-");
  StrCopy(Temp3,StrIToA(Temp3,height));


  FrmCustomAlert(10024,Temp1,Temp2,Temp3);*/

  // deal with lies by using pitch..
  width = pitch / 2;
  pitch = pitch / 2;

  // Do we see a DIA present? (T|T3, Zodiac, UX50, Garmin, later devices..)
  {
    UInt32 version;
    Err err = FtrGet ( pinCreator, pinFtrAPIVersion, &version );
    if ( ! err && version ) {
      //PINS exists
      //DEBUGS("PIN present");
      hw_flags |= hf_pin_present;
      hw_set_fullscreen(1);

    } // pin?
  } // DIA PIN?

  // done
  //*r_width = width;
  //*r_height = height;
  //*r_pitch = pitch;
  
  devErr = FtrGet(sysFtrCreator, sysFtrNumOEMDeviceID, &deviceID); 
	if (deviceID == 'prmr')
	{
		width = 480;
		height = 320;
		pitch = 480;
	}


	FtrSet(appFileCreator,1113,(unsigned long)width);
	FtrSet(appFileCreator,1114,(unsigned long)height);
	FtrSet(appFileCreator,1115,(unsigned long)pitch);


  return;
}


static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;
	UInt32 displayFtrP;
	
#ifndef DEV_BUILD
	//SysSetOrientation(sysOrientationLandscape);
	//PINSetInputAreaState(1);
	//StatHide();
	displayFtrP =(UInt32)BmpGetBits(WinGetBitmap(WinGetDisplayWindow()));
	FtrSet(appFileCreator,1111,(unsigned long)displayFtrP);
#endif
	FtrSet(appFileCreator,1112,(unsigned long)host_event_handler);
	FtrSet(appFileCreator,1116,(unsigned long)host_event);

	hw_guess_screen_dimensions();
	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Palm OS 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion <= kPalmOS10Version)
				{
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return sysErrRomIncompatible;
		}

	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    void *
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void * GetObjectPtr(UInt16 objectID)
{
	FormPtr frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}


/***********************************************************************
 *
 * FUNCTION:    MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:  frm - pointer to the MainForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void MainFormInit(FormPtr /*frmP*/)
{
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;
	FormPtr frmP;

	switch (command)
		{
		case MainOptionsAboutStarterApp:
			MenuEraseStatus(0);					// Clear the menu status from the display.
			frmP = FrmInitForm (AboutForm);
			FrmDoDialog (frmP);					// Display the About Box.
			FrmDeleteForm (frmP);
			handled = true;
			break;

		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr eventP)
{
	Boolean handled = false;
	FormPtr frmP;

	switch (eventP->eType) 
		{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);

		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			MainFormInit( frmP);
			FrmDrawForm ( frmP);

			// call the PACE Native Object
			UInt32 processor;
			FtrGet(sysFtrCreator, sysFtrNumProcessorID, &processor);

			if (sysFtrNumProcessorIsARM(processor))
			{
				PnoDescriptor pno;
				Err err;
				MemPtr pnoPtr = GetThePNO();

				//err = PnoLoadFromResources(&pno, 'ARMC', 1, appFileCreator, 1);
				
				if (!pnoPtr)
					SysFatalAlert("failed to load pno");

				PnoLoad(&pno, pnoPtr);
				UInt32 result = PnoCall(&pno, 0);
				PnoUnload(&pno);
			}

			handled = true;
			break;
			
		case frmUpdateEvent:
			// To do any custom drawing here, first call FrmDrawForm(), then do your
			// drawing, and then set handled to true.
			break;

		default:
			break;
		
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AppHandleEvent(EventPtr eventP)
{
	UInt16 formId;
	FormPtr frmP;

	if (eventP->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
			{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			default:
//				ErrFatalDisplay("Invalid Form Load Event");
				break;

			}
		return true;
		}
	
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;

	do {
		EvtGetEvent(&event, evtWaitForever);

		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     Err value 0 if nothing went wrong
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err AppStart(void)
{
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppStop(void)
{
	// Close all the open forms.
	FrmCloseAllForms ();
}


/***********************************************************************
 *
 * FUNCTION:    StarterPalmMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 *
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static UInt32 StarterPalmMain(UInt16 cmd, MemPtr /*cmdPBP*/, UInt16 launchFlags)
{
	Err error;
    UInt32 new_depth = 16;
    FormPtr frmP;



	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			WinScreenMode(winScreenModeSet,NULL,NULL,&new_depth,NULL);

			//error = AppStart();
			error = RomVersionCompatible (kOurMinVersion, launchFlags);
			if (error) return (error);

			// call the PACE Native Object
			UInt32 processor;
			FtrGet(sysFtrCreator, sysFtrNumProcessorID, &processor);

			if (sysFtrNumProcessorIsARM(processor))
			{
				PnoDescriptor pno;
				Err err;
				//MemPtr pnoPtr = GetThePNO();

				err = PnoLoadFromResources(&pno, 'ARMC', 1, appFileCreator, 1);
				
				//if (!pnoPtr)
				//	SysFatalAlert("failed to load pno");

				//PnoLoad(&pno, pnoPtr);

				UInt32 result = PnoCall(&pno, 0);
				PnoUnload(&pno);
			}

			//if (error) 
			//	return error;
				
			//FrmGotoForm(MainForm);
			//AppEventLoop();
			//AppStop();
			break;

		default:
			break;

		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 PilotMain( UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	return StarterPalmMain(cmd, cmdPBP, launchFlags);
}
