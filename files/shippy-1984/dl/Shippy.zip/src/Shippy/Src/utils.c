/*
	File:			utils.c

	Description:	Utility Functions

	Author:		

	Copyright:		Copyright � 2003 by Tapwave, Inc.

	Disclaimer:		IMPORTANT:  This Tapwave software is provided by Tapwave, Inc. ("Tapwave").  Your 
					use is subject to and governed by terms and conditions of the Software Development 
					Kit Agreement ("SDK Agreement") between you and Tapwave.  If you have not entered 
					into Tapwave�s standard SDK Agreement with Tapwave, you have no right or license 
					to use, reproduce, modify, distribute or otherwise exploit this Tapwave software.  
					You may obtain a copy of Tapwave�s standard SDK Agreement by calling 650-960-1817
					or visiting Tapwave at http://www.tapwave.com/developers/. 

	Change History (most recent first):
				
*/

#include <PalmOS.h>
#include "utils.h"
#include <stdio.h>
#include "host.h"
#include <sys/stat.h>
#include <zlib.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>


#ifdef __cplusplus
extern "C" {
#endif


static UInt32 start_clock_count;


#if CPU_TYPE == CPU_68K
#define LittleEndianSwap16(x) \
	((((x) >> 8) & 0xFF) | \
	 (((x) & 0xFF) << 8))
#else
#define LittleEndianSwap16(x) \
    (x)
#endif

typedef struct 
{
	UInt16   signature;
	UInt16   _pad_;
	UInt32   size;
	UInt32   reserved;
	UInt32   dataOffset;
} BitmapFileHeader;

typedef struct 
{
	UInt32	sizeInfoHeader;
	UInt32	width;
	UInt32	height;
	UInt16	planes;
	UInt16	bitCount;
	UInt32	compression;
	UInt32	sizeGlyph;
	UInt32	xPixelsPerM;
	UInt32	yPixelsPerM;
	UInt32	colorsUsed;
	UInt32	colorsImportant;
} BitmapInfoHeader;

#if defined(__arm) || defined(_MSC_VER)
#define ENDIAN '<'
#else
#define ENDIAN '>'
#endif

const char*
pack(const char* format, char* buf, const void* source)
{
    int bswap = 0;
    const char* src = (char*) source;

    for (;;) {
        char ch = *format++;
        switch (ch) {
        case 0:
            return src;
        case '<': case '>':
            bswap = (ch != ENDIAN);
            continue;
        case '=':
            bswap = 0;
            continue;
        case '!':
            bswap = 1;
            continue;
        case 'b': case 'B':
            *buf++ = *src++;
            continue;
        case 'h': case 'H':
            if (bswap) {
                buf[1] = src[0];
                buf[0] = src[1];
            } else {
                buf[0] = src[0];
                buf[1] = src[1];
            }
            buf += 2;
            src += 2;
            continue;
        case 'i': case 'I': case 'f':
            if (bswap) {
                buf[3] = src[0];
                buf[2] = src[1];
                buf[1] = src[2];
                buf[0] = src[3];
            } else {
                buf[0] = src[0];
                buf[1] = src[1];
                buf[2] = src[2];
                buf[3] = src[3];
            }
            buf += 4;
            src += 4;
            continue;
        case 'l': case 'L': case 'd':
            if (bswap) {
                buf[7] = src[0];
                buf[6] = src[1];
                buf[5] = src[2];
                buf[4] = src[3];
                buf[3] = src[4];
                buf[2] = src[5];
                buf[1] = src[6];
                buf[0] = src[7];
            } else {
                buf[0] = src[0];
                buf[1] = src[1];
                buf[2] = src[2];
                buf[3] = src[3];
                buf[0] = src[4];
                buf[1] = src[5];
                buf[2] = src[6];
                buf[3] = src[7];
            }
            buf += 4;
            src += 4;
            continue;
        case 'x':
            buf += 1;
            continue;
        case 'X':
            buf -= 1;
            continue;
        case 'y':
            src += 1;
            continue;
        case 'Y':
            src -= 1;
            continue;
		case ' ': case ',':
			continue;
        default:
            DbgBreak();
            continue;
        }
    }

	return src;
}

char * LoadImage(char *filename)
{
	FILE *fp;
	char *dataP;
	int size=0;
	
    size = file_size(filename);
	if((fp=fopen(filename,"rb"))==NULL)
    	return NULL;
    	
    dataP = (char *)malloc(size);
    fread(dataP,1,size,fp);
    fclose(fp);
    	
	return dataP;
}



Err
AppReadBMP(HBITMAP *bmp, const void * dataP)
{
    int compression;
    int row;
    int column;
    Int32 sourceBytesPerRow;
    Err error=0;
	BitmapFileHeader fileHeader;
	BitmapInfoHeader infoHeader;
	const void * p = dataP;
	const void * newDataP = NULL;
	int red;
	int green;
	int blue;
    
	// unpack the fileHeader structure.  This is to solve alignment differences on
	// 68K, x86, and ARM.
	p = pack("<hxxiii", (char*)&fileHeader, (const char*)p);
	pack("<iiihhiiiiii", (char*)&infoHeader, (const char*)p);
    
	if (fileHeader.signature != 'MB' && fileHeader.signature != 'BM') return 1; // 'BM' for 68K
	
    bmp->bmWidth = (Int32) infoHeader.width;
    bmp->bmHeight = (Int32) infoHeader.height;
    
    compression = (int) infoHeader.compression;
    
    sourceBytesPerRow = (((infoHeader.bitCount * bmp->bmWidth + 7) / 8 + 3) / 4) * 4;
    
    switch (infoHeader.bitCount)
    {
        case 16:
            bmp->rowbytes = (void *)malloc(bmp->bmWidth * bmp->bmHeight * sizeof(UInt16));
            
            // 16 bit glyphs can not be compressed.
            if (compression == 0)
            {
                UInt8 *pixelsDestP;
                UInt8 *pixelsSourceP;
                UInt16 *destP;
                UInt16 *sourceP;
                
                // The data must be converted to 565 RGB.
                pixelsDestP = (UInt8 *) MemGluePtrNewL((UInt32) (bmp->bmWidth * bmp->bmHeight * sizeof(UInt16)));
                pixelsSourceP = (UInt8 *) dataP + fileHeader.dataOffset;
                
                for (row = 0; row < bmp->bmHeight; row++)
                {
                    destP = (UInt16 *) (pixelsDestP + row * bmp->bmWidth * sizeof(UInt16));
                    sourceP = (UInt16 *) (pixelsSourceP + 
                        ((bmp->bmHeight - 1) - row) * sourceBytesPerRow);
                    
                    for (column = 0; column < bmp->bmWidth; column++)
                    {
                        // Convert from 555 to 565.
                        *destP = *sourceP & 31 | ((*sourceP & (0x7fff ^ 31)) << 1);
                        destP++;
                        sourceP++;
                    }
                }
                
                // The data may really be padded out to 32 bit boundaries.
                //error = TwGfxWriteSurface(*aResult, pixelsDestP, false);
                MemMove(bmp->rowbytes, pixelsDestP, bmp->bmWidth * bmp->bmHeight * sizeof(UInt16));
                free(pixelsDestP);
            }
            else if (compression == 3)
            {
                // DOLATER
                // Convert RGB from the bitmasks in RGBQUAD
            }
            break;
            
        case 24:
            bmp->rowbytes = (void *)malloc(bmp->bmWidth * bmp->bmHeight * sizeof(UInt16));
			            
            // 24 bit glyphs can not be compressed.
            if (compression == 0)
            {
                UInt8 *pixelsDestP;
                UInt8 *pixelsSourceP;
                UInt16 *destP;
                UInt8 *sourceP;
                UInt16 pixel;
                
                // The data must be converted to 565 RGB.
                pixelsDestP = (UInt8 *) MemGluePtrNewL((UInt32) (bmp->bmWidth * bmp->bmHeight * sizeof(UInt16)));
                pixelsSourceP = (UInt8 *) dataP + fileHeader.dataOffset;
                
                for (row = 0; row < bmp->bmHeight; row++)
                {
                    destP = (UInt16 *) (pixelsDestP + row * bmp->bmWidth * sizeof(UInt16));
                    sourceP = pixelsSourceP + ((bmp->bmHeight - 1) - row) * sourceBytesPerRow;
                    
                    for (column = 0; column < bmp->bmWidth; column++)
                    {
                        // Convert from BGR 888 to RGB 565.
#if 1
                        blue = *sourceP++;
                        green = *sourceP++;
                        red = *sourceP++;
                        pixel = TwGfxMakeDisplayRGB(red, green, blue);
#else
                        pixel = (UInt16) (*sourceP++ >> 3);
                        pixel |= (UInt16) ((*sourceP++ >> 2) << 5);
                        pixel |= (UInt16) ((*sourceP++ >> 3) << 11);
#endif
                        pixel = LittleEndianSwap16(pixel);
                        *destP++ = pixel;
                    }
                }
                
                // The data may really be padded out to 32 bit boundaries.
                //error = TwGfxWriteSurface(*aResult, pixelsDestP, false);
                MemMove(bmp->rowbytes, pixelsDestP, bmp->bmWidth * bmp->bmHeight * sizeof(UInt16));
                free(pixelsDestP);
            }
            else if (compression == 3)
            {
                // DOLATER - 
                // Convert RGB from the bitmasks in RGBQUAD
            }
            break;
    }
    
    if (newDataP != NULL)
    	MemPtrFree((void *) newDataP);
        	
    return error;
    
}

void CopyRect(RECT *dest, RECT *src)
{
	dest->left = src->left;
	dest->top = src->top;
	dest->right = src->right;
	dest->bottom = src->bottom;
}
void SetRectEmpty(RECT *dest)
{
	dest->left = 0;
	dest->top = 0;
	dest->right = 0;
	dest->bottom = 0;
}

bool IntersectRect(RECT *d, RECT *s1, RECT *s2)
{
	RectangleType rs1, rs2, rd;
	
	rs1.topLeft.x = s1->left;
	rs1.topLeft.y = s1->top;
	rs1.extent.x = s1->right-s1->left;
	rs1.extent.y = s1->bottom-s1->top;
	
	rs2.topLeft.x = s2->left;
	rs2.topLeft.y = s2->top;
	rs2.extent.x = s2->right-s2->left;
	rs2.extent.y = s2->bottom-s2->top;
	
	rd.topLeft.x = d->left;
	rd.topLeft.y = d->top;
	rd.extent.x = d->right-d->left;
	rd.extent.y = d->bottom-d->top;
	
	RctGetIntersection(&rs1, &rs2, &rd);
	
	d->left = rd.topLeft.x;
	d->top = rd.topLeft.y;
	d->right = rd.extent.x + rd.topLeft.x;
	d->bottom = rd.extent.y + rd.topLeft.y;
	
	if (d->right == 0 || d->bottom == 0)
	{
		d->left = 0;
		d->top = 0;
		d->right = 0;
		d->bottom = 0;
		return false;
	}
	else
		return true;
}

bool IsRectEmpty(RECT *d)
{
	if (d->right == 0 || d->bottom == 0)
		return true;
	else
		return false;
}

BOOL OffsetRect(RECT *lprc,int dx,int dy)
{
	lprc->left += dx;
	lprc->right += dx;
	lprc->top += dy;
	lprc->bottom += dy;
	return true;
}
BOOL SetRect(RECT *src,int xLeft,int yTop,int xRight,int yBottom)
{
	src->left = xLeft;
	src->top = yTop;
	src->right = xRight;
	src->bottom = yBottom;
	
	return true;
}
BOOL PtInRect(RECT *d,POINT pt)
{
	RectangleType rd;
	
	rd.topLeft.x = d->left;
	rd.topLeft.y = d->top;
	rd.extent.x = d->right-d->left;
	rd.extent.y = d->bottom-d->top;

	return RctPtInRectangle(pt.x, pt.y, &rd);
}

BOOL UnionRect(RECT *Dst, const RECT *Src1,const RECT *Src2)
{


	Dst->left = (Src1->left < Src2->left) ? Src1->left : Src2->left;
	Dst->top = (Src1->top < Src2->top) ? Src1->top : Src2->top;
	Dst->right = (Src1->right > Src2->right) ? Src1->right : Src2->right;
	Dst->bottom = (Src1->bottom > Src2->bottom) ? Src1->bottom : Src2->bottom;

	return true;
}


void block_draw(UInt16 *buf,signed short int x,signed short int y,
				UInt16 *screen, int screenw, int screenh, Int32 transparent,
				RECT rsrc, int totalw, int totalh)
{
  Int16 i,j;
  Int16 xoff,xlen;
  Int16 yoff,ylen;
  UInt16 color;
  int w,h;
  
  w=rsrc.right-rsrc.left;
  h=rsrc.bottom-rsrc.top;

  
  // clip the block to fit within screen
  xlen = w;
  xoff = rsrc.left;

  if(x<0) {
    xlen+=x;
    xoff=-x;
    x=0;
  }

  if(x+w > screenw-1)
    xlen = screenw-x;

  ylen = h;
  yoff = rsrc.top;
  if(y<0) {
    ylen+=y;
    yoff=-y;
    y=0;
  }

  if(y+h > screenh-1)
    ylen = screenh-y;

  if((xlen<1) || (ylen<1))
    return;

  // setup the pointers
  screen+=y*screenw+x;
  buf+=yoff*totalw+xoff;

  for(i=0;i<ylen;i++) {
    for(j=0;j<xlen;j++) {
      color = buf[j];
      if(color != transparent)
        screen[j] = color;
    }
    screen+=screenw;
    buf+=totalw;
  }
}
void fast_draw(UInt16 *buf,const RECT *rdst,
				UInt16 *screen, Int32 transparent,
				const RECT *rsrc, int totalw, int totalh)
{
  Int16 i,j;
  Int16 xoff,xlen;
  Int16 yoff,ylen;
  UInt16 color;
  int x, y;
  
  xlen=rdst->right-rdst->left;
  ylen=rdst->bottom-rdst->top;
  yoff = rsrc->top;
  xoff = rsrc->left;
  x = rdst->left;
  y = rdst->top;
  
  // setup the pointers
  screen+=y*screenWidth+x;
  buf+=yoff*totalw+xoff;

  for(i=0;i<ylen;i++) {
    for(j=0;j<xlen;j++) {
      color = buf[j];
      if(color != transparent)
        screen[j] = color;
    }
    screen+=screenWidth;
    buf+=totalw;
  }
}

void alpha_block_draw(UInt16 *buf,signed short int x,signed short int y,
				UInt16 *screen, int screenw, int screenh, Int32 transparent,
				RECT rsrc, int totalw, int totalh, int alpha)
{
  Int16 i,j;
  Int16 xoff,xlen;
  Int16 yoff,ylen;
  UInt16 color;
  RGBColorType RGBsrc, RGBDst, RGBTemp;
  int w,h;
  register int idst;
  register int isrc;

  w=rsrc.right-rsrc.left;
  h=rsrc.bottom-rsrc.top;

  
  // clip the block to fit within screen
  xlen = w;
  xoff = rsrc.left;

  if(x<0) {
    xlen+=x;
    xoff=-x;
    x=0;
  }

  if(x+w > screenw-1)
    xlen = screenw-x;

  ylen = h;
  yoff = rsrc.top;
  if(y<0) {
    ylen+=y;
    yoff=-y;
    y=0;
  }

  if(y+h > screenh-1)
    ylen = screenh-y;

  if((xlen<1) || (ylen<1))
    return;

  // setup the pointers
  screen+=y*screenw+x;
  buf+=yoff*totalw+xoff;

  for(i=0;i<ylen;i++) {
    for(j=0;j<xlen;j++) {
      color = buf[j];
      if(color != transparent)
      {
		idst = screen[j];
		isrc = color;
		screen[j] = ((twGfxRMask & ((idst & twGfxRMask) + 
			((int)(((int)(isrc & twGfxRMask) -
      		(int)(idst & twGfxRMask)) * alpha) >>8))) |
   			(twGfxGMask & ((idst & twGfxGMask) +
      		((int)(((int)(isrc & twGfxGMask) -
      		(int)(idst & twGfxGMask)) * alpha) >>8))) |
   			(twGfxBMask & ((idst & twGfxBMask) +
      		((int)(((int)(isrc & twGfxBMask) -
      		(int)(idst & twGfxBMask)) * alpha) >>8))) );

      }
    }
    screen+=screenw;
    buf+=totalw;
  }
}

void Screen_Transitions(int effect)
{
// this function can be called to perform a myraid of screen transitions
// to the destination buffer, make sure to save and restore the palette
// when performing color transitions in 8-bit modes

UInt32 index;           // used as loop counter
int screen_width;
int screen_height;
screen_height= screenHeight;
screen_width = screenWidth;

//PALETTEENTRY work_color;         // used in color algorithms

// test which screen effect is being selected
switch(effect)
      {

      case SCREEN_SWIPE_X:
           {
           // do a screen wipe from right to left, left to right
           for (index=0; index < (screen_width/2); index+=2)
               {
               // use this as a 1/100th of second time delay
               
               Start_Clock(); Wait_Clock(1);

               // draw two vertical lines at opposite ends of the screen
               WinDrawLine(index,(screen_height-1),index,0);  //left
               WinDrawLine((screen_width-1)-index,(screen_height-1),(screen_width-1)-index,0);  // right
               WinDrawLine(index+1,(screen_height-1),index+1,0); // left + 1
               WinDrawLine((screen_width-1)-(index+1),(screen_height-1),(screen_width-1)-(index+1),0); // right + 1

               } // end for index

           } break;

      case SCREEN_SWIPE_Y:
           {
           // do a screen wipe from top to bottom, bottom to top
           for (index=0; index < (screen_height/2); index+=2)
               {
               // use this as a 1/100th of second time delay
               
               Start_Clock(); Wait_Clock(1);

               // draw two horizontal lines at opposite ends of the screen
               WinDrawLine((screen_width-1),index,0,index);  // Top
               WinDrawLine((screen_width-1),(screen_height-1)-index,0,(screen_height-1)-index);		// Bottom
               WinDrawLine((screen_width-1),index+1,0,index+1); // Top + 1
               WinDrawLine((screen_width-1),(screen_height-1)-(index+1),0,(screen_height-1)-(index+1));	// Bottom -1
               
               } // end for index


            } break;

      case SCREEN_SCRUNCH:
           {
           // do a screen wipe from top to bottom, bottom to top
           for (index=0; index < (screen_width/2); index+=2)
               {
               // use this as a 1/100th of second time delay
               
               Start_Clock(); Wait_Clock(1);

               // test screen depth             
               // draw two horizontal lines at opposite ends of the screen
               WinDrawLine((screen_width-1),index,0,index);  // Top
               WinDrawLine((screen_width-1),(screen_height-1)-index,0,(screen_height-1)-index);		// Bottom
               WinDrawLine((screen_width-1),index+1,0,index+1); // Top + 1
               WinDrawLine((screen_width-1),(screen_height-1)-(index+1),0,(screen_height-1)-(index+1));	// Bottom -1

               // draw two vertical lines at opposite ends of the screen
               // draw two vertical lines at opposite ends of the screen
               WinDrawLine(index,(screen_height-1),index,0);  //left
               WinDrawLine((screen_width-1)-index,(screen_height-1),(screen_width-1)-index,0);  // right
               WinDrawLine(index+1,(screen_height-1),index+1,0); // left + 1
               WinDrawLine((screen_width-1)-(index+1),(screen_height-1),(screen_width-1)-(index+1),0); // right + 1

               } // end for index

           } break;

      case SCREEN_DISOLVE:
           {
           // disolve the screen by plotting zillions of little black dots

               for (index=0; index<=(screen_width+20)*(screen_height+20); index++)
               {
                   WinDrawPixel(SysRandom(0)%screen_width,SysRandom(0)%screen_height);
               }

           } break;

      case SCREEN_TWIST:
           {
           // do a screen wipe from top to bottom, bottom to top
           for (index=0; index < (screen_height); index+=2)
               {
               // use this as a 1/100th of second time delay
               
               Start_Clock(); Wait_Clock(1);

               // test screen depth             
               // draw two horizontal lines at opposite ends of the screen
               WinDrawLine(index,(screen_height-1),(screen_width-1)-index,0);  // Bottom left to Top right *whew!*
               WinDrawLine((screen_width-1),(screen_height-1)-(index),0,(index));		// Bottom right to Top Left
               WinDrawLine(index+1,(screen_height-1),(screen_width-1)-index+1,0);  // Bottom left to Top right *whew!*
               WinDrawLine((screen_width-1),(screen_height-1)-(index+1),0,(index+1));		// Bottom right to Top Left


               } // end for index

           } break;


       default:break;

      } // end switch

} // end Screen_Transitions

UInt32 Get_Clock(void)
{
// this function returns the current tick count

// return time
return(TimGetTicks());

} // end Get_Clock


UInt32 Start_Clock(void)
{
// this function starts the clock, that is, saves the current
// count, use in conjunction with Wait_Clock()

return(start_clock_count = Get_Clock());

} // end Start_Clock

////////////////////////////////////////////////////////////

UInt32 Wait_Clock(UInt32 count)
{
// this function is used to wait for a specific number of clicks
// since the call to Start_Clock

while((Get_Clock() - start_clock_count) < count);
return(Get_Clock());

} // end Wait_Clock

typedef struct
{
    Coord x;
    Coord y;
    Coord width;
} FontCharDataType;

typedef struct
{
    HBITMAP fontGlyphs;
    UInt16 fontColorBorder;
    TwGfxPackedRGBType fontColorBackground;
    Coord lineHeight;
    FontCharDataType chars[128];
} FontInfoType;

static FontInfoType FontInfo;

// Those wanting more info on font formats in general would enjoy reading
// http://pfaedit.sourceforge.net/
// http://freetype.sourceforge.net/index2.html 
// and especially http://freetype.sourceforge.net/freetype2/docs/glyphs/glyphs-7.html

extern Err FontInit()
{
    Err error;
    UInt16 * glyphP;
    //TwGfxSurfaceInfoType surfInfo;
    Int32 rowWords;
    Coord rootX;
    Coord rootY;
    Coord x;
    Coord y;
    void * fontGlyphsP;
    void * fontGlyphsUncompressedP = NULL;
    int row;
    int column;
    int c;
    gzFile File;
    UInt32 buflen=0;
    
	fontGlyphsUncompressedP = (void *)malloc(2048);
//    return errNone;


    
    // Some of the images are compressed using gzip.  BMP images > 256 colors
    // are not compressed.  GZip is quite effective, quick and portable and makes a 
    // good choice.
    File = gzopen("FontLarge.bmp.gz", "r");
    while (!gzeof(File))
    {
    	buflen+= gzread(File,fontGlyphsUncompressedP,2048);
    }
    gzclose(File);
    
    free(fontGlyphsUncompressedP);
    fontGlyphsUncompressedP = (void *)malloc(buflen);
    File = gzopen("/palm/programs/isohex/FontLarge.bmp.gz", "r");
    gzread(File,fontGlyphsUncompressedP,buflen);
    gzclose(File);
    
    error = AppReadBMP(&FontInfo.fontGlyphs, 
        fontGlyphsUncompressedP);
    
    if (fontGlyphsUncompressedP != NULL)
        free(fontGlyphsUncompressedP);
        
    //TwGfxLockSurface(FontInfo.fontGlyphs, (void**)&glyphP);
    //surfInfo.size = sizeof(surfInfo);
    //error = TwGfxGetSurfaceInfo(FontInfo.fontGlyphs, &surfInfo);
    rowWords = (int) FontInfo.fontGlyphs.bmWidth;
    glyphP = (UInt16*)FontInfo.fontGlyphs.rowbytes;
    
    FontInfo.fontColorBorder = *glyphP; 
    
    // Scan for the root x, y;
    rootX = 0;
    rootY = 0;
    while (glyphP[rootX + rootY * rowWords] == FontInfo.fontColorBorder)
    {
        rootX++;
        rootY++;
    }
    FontInfo.fontColorBackground = glyphP[rootX + rootY * rowWords];
    
    // Find the height.  The height of all chars is assumed to the same, and the
    // chars are positioned as desired within the vertical space.
    // Find the right border.
    y = rootY;
    while (glyphP[rootX + y * rowWords] != FontInfo.fontColorBorder)
    {
        y++;
    }
    FontInfo.lineHeight = (y - 1 - rootY + 1);
    
    // Skip the border
    x = rootX;
    while (glyphP[x + rootY * rowWords] == FontInfo.fontColorBorder)
    {
        x++;
    }
    
    
    // scan through the glyph picking out characters and adding them to the 
    // tables for quick access.
    for (row = 2; row < 8; row++)
    {
        x = rootX;
        y = rootY + (FontInfo.lineHeight + rootY) * (row - 2);
        
        for (column = 0; column < 16; column++)
        {
            c = row * 16 + column;
            
            // All characters are fully boxed so that bounds can easily be determined.
            // Top
            FontInfo.chars[c].x = x;
            FontInfo.chars[c].y = y;
            
            // Find the right border.
            while (glyphP[x + y * rowWords] != FontInfo.fontColorBorder)
            {
                x++;
            }
            FontInfo.chars[c].width = x - FontInfo.chars[c].x;
            
            // Skip the border
            while (glyphP[x + y * rowWords] == FontInfo.fontColorBorder &&
                x < FontInfo.fontGlyphs.bmWidth)
            {
                x++;
            }
        }
    }
    
    
    return error;
}

void FontClose()
{
	HBITMAP *bmp;
	bmp = &FontInfo.fontGlyphs;
	if (bmp->rowbytes)
		free(bmp->rowbytes);
}


Int16 FontGetLineHeight()
{
    if (FontInfo.fontGlyphs.rowbytes != NULL)
        return FontInfo.lineHeight;
    
    return 0;
}


Int16 FontGetCharWidth(char c)
{
    if (FontInfo.fontGlyphs.rowbytes != NULL)
        return FontInfo.chars[c].width;
    
    return 0;
}

// How many lines of inwidth pixels will ptr text take?
int FontWordWrap(char *ptr, int inWidth)
{
	int count;
	Int32 length = StrLen(ptr);
	Int32 flength = length;
	int numlines = 0;
	Int32 fWidth=inWidth;
	int charsDone=0;
	char *str, *temppos;
	int templen;
	int found=false;
	
	
	
	length = StrLen(ptr);
	flength = length;
	templen = 0;
	
	FontGetCharsInWidth(ptr, &flength, &fWidth, NULL);
	if (flength)
	{
		if (flength == length)
		{
			return flength;

		}
		else
		{
			//Need to back up until a linebreak or whitespace
			templen = flength;
			str = malloc(length+1);
			StrCopy(str,ptr);
			temppos = str;
			temppos+= templen-1;
			while (templen>0)
			{
				if (isspace(*temppos))
				{
					found = true;
					break;
				}
				else
				{
				
					--temppos;
					--templen;
				}
			}
			if (!found)
				templen = flength;
				
		}
	}
	free(str);
	
	return templen;
}


void FontGetCharsInWidth(const char * s, 
    Int32 * lengthP, //! pass in the length, the length that fits is returned
    Int32 * widthP,  //! pass in the width, the width used is returned.
    char * truncationCharP //! pass in the truncation char, the char (if any) used
    )
{
    Int32 width = 0;
    Int32 length = *lengthP;
    Int32 truncationWidth;
    Int32 charWidth;
    Int32 truncationLength = 0;
    
    if (*widthP == 0)
        *widthP = 0x7fff;
    
    truncationWidth = *widthP;
    if (truncationCharP != NULL)
        truncationWidth -= FontGetCharWidth(*truncationCharP);
    
    if (FontInfo.fontGlyphs.rowbytes != NULL)
    {
        while (length > 0 && width < *widthP)
        {
            if (0x20 <= *s && *s <= 0x7f)
            {
                charWidth = FontGetCharWidth(*s);
                if (width + charWidth <= *widthP)
                    width += charWidth;
                else
                    break;
                
                // If the char can be added without exceeding the truncation area, do so
                if (width <= truncationWidth)
                    truncationLength++;
            }
            s++;
            length--;
        }
        
        if (width <= truncationWidth && truncationCharP != NULL)
            *truncationCharP = '\0';
    }
    
    *widthP = width;
    *lengthP -= length;
}


Int32 FontDrawChars(const char * s, Int32 length, UInt16 *destSurface, Int32 x, Int32 y)
{
    Int32 width = 0;
    RECT sourceBounds;
    POINT destPoint;
    
    if (FontInfo.fontGlyphs.rowbytes != NULL)
    {
        destPoint.x = x;
        destPoint.y = y;
        
        
        
        while (length > 0)
        {
            if (0x20 <= *s && *s <= 0x7f)
            {
                sourceBounds.left = FontInfo.chars[*s].x;
                sourceBounds.top = FontInfo.chars[*s].y;
                sourceBounds.right = sourceBounds.left + FontInfo.chars[*s].width;
                sourceBounds.bottom = sourceBounds.top + FontInfo.lineHeight;
                
                // Copy the source window (contains the image to draw) to the draw window.
                block_draw(FontInfo.fontGlyphs.rowbytes, destPoint.x, destPoint.y,destSurface,
                    screenWidth, screenHeight, FontInfo.fontColorBackground, sourceBounds,
                    FontInfo.fontGlyphs.bmWidth, FontInfo.fontGlyphs.bmHeight);

                destPoint.x += FontInfo.chars[*s].width;
            }
            s++;
            length--;
        }
        
        width = destPoint.x - x;
    }
    
    return width;
}



#ifdef __cplusplus
} // extern "C"
#endif
