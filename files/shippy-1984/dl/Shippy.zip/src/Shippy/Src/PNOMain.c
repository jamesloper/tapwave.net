#include "host.h"
#include <PalmOS.h>
#include <VFSMgr.h>
#include "endianutils.h"

#include "AdnDebugMgr.h"
//#include "PACEInterfaceLib.h"
#include <PCENativeCall.h>
#include <size_t.h>
#include <cstddef>
#include <string.h>
#include <ctype.h>
#include <float.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <file_struc.h>
#include <console_io.h>
#include <dirent.h>


// Linker still looks for ARMlet_Main as entry point, but the
// "ARMlet" name is now officially discouraged.  Compare an
// contrast to "PilotMain" for 68K applications.
#define PNO_Main ARMlet_Main

// Define DEBUG as 0 to turn off debugging support in the PNO.
// With this on, the PNO will register itself with the Palm OS
// Debugger on startup, allowing stepping through the code.
#define DEBUG 1

// Original stationery application but using library interface
// rather than class-derived interface.

/*
 * The following functions provide malloc/free support to Metrowerks
 * Standard Library (MSL). This feature requires the MSL library be
 * built with _MSL_OS_DIRECT_MALLOC enabled.
 */
UInt32 *host_event_handler;
UInt32 *host_event;

void	*my_emulStateP;
Call68KFuncType	*my_call68KFuncP;


void *MemGluePtrNewL ( UInt32 foo ) {
  UInt32 r;
  UInt32 arg;

  arg = ByteSwap32 ( foo );

  r = my_call68KFuncP ( my_emulStateP,
			(UInt32)host_event_handler  , &arg, 4 );

  if ((UInt8*) (r) == 0)
  	SysFatalAlert("Out of Memory");

  return ( (UInt8*) (r) );
}

void CallEvent(void)
{

	my_call68KFuncP ( my_emulStateP,
			(UInt32)host_event  , NULL, 0 );
}

 
/*
 * The following functions provide MemGluePtrNewL/free support to Metrowerks
 * Standard Library (MSL). This feature requires the MSL library be
 * built with _MSL_OS_DIRECT_MALLOC enabled.
 */
 
 // constants for TwGetSlotNumberForVolume()
#define twSlotUnknown           -1
#define twSlotInternal          0
#define twSlotLeft              1
#define twSlotRight             2

// constants for TwGet{PRC|DB}DataDirectory
#define kTwDirectoryPrefix      "/PALM/Programs/"
#define kTwPathNameResType      'Twdp'
#define kTwPathNameResID        0

 
void*
__sys_alloc(size_t size)
{
    void * ptr = MemGluePtrNewL(size);
    ErrFatalDisplayIf(ptr == NULL, "out of memory");
    return ptr;
}

void
__sys_free(void* ptr)
{
    (void) MemPtrFree(ptr);
}

size_t
__sys_pointer_size(void* ptr)
{
    return (size_t) MemPtrSize(ptr);
}

/*
 * This function converts stanard windows path into palmos path.
 */
int TwGetSlotNumberForVolume(int volume)
{
	if (volume == 2)
		return 1;
	else if (volume == 3)
		return 2;
	else if (volume == 1)
		return 0;

}

Err TwGetDBDataDirectory(MemHandle dbH, UInt16 *volRefNumP, Char *pathNameP, UInt16 maxLen)
{
	
}
 
int __sys_path(const char* path, char* buffer, size_t length)
{
    UInt16 volume;

    if (path[1] == ':') {
        // absolute path
        // convert drive letter to slot number, ref ascii table.
        int slot = (path[0] & 0x1F);
        if (slot == 3) {
            slot = twSlotInternal;
        }
        // iterate all volumes
        UInt32 it = vfsIteratorStart;
        while (!VFSVolumeEnumerate(&volume, &it)) {
            if (slot == TwGetSlotNumberForVolume(volume)) {
                if (strlen(path) < length) {
                    strcpy(buffer, path + 2);
                    goto done;
                }
                break;
            }
        }
    } 
    else 
    {
        // relative path
        // find application data volume and directory
        //if (!TwGetDBDataDirectory(NULL, &volume, buffer, length)) 
        volume = palm_vfs_vol();
        if (!StrStr(path,PALMOPENDIR))
        	strcpy(buffer,PALMOPENDIR);
        //{
            if (path[0] == '/' || path[0] == '\\') 
            {
                buffer[0] = 0;
            }
            if (strlen(buffer) + 1 + strlen(path) < length) 
            {
                strcat(buffer, "/");
                strcat(buffer, path);
                goto done;
            }
        //}
    }
    return -1;
 done:
    for (int i = 0; buffer[i] != 0; i++) {
        if (buffer[i] == '\\') {
            buffer[i] = '/';
        }
    }
    return volume;
}

/*
 * The following functions provide hooks for stdin/stdout/stderr.
 * Applications may override them to do whatever they want. The
 * default implementation redirects console IO through ARM semihosting
 * interface.
 */
int
__close_console(__file_handle file)
{
    return __no_io_error;
}

int
__read_console(__file_handle file, unsigned char * buff, size_t * count, __ref_con ref_con)
{
    return __io_EOF;
}

int
__write_console(__file_handle file, unsigned char * buff, size_t * count, __ref_con ref_con)
{
    return __no_io_error;
}

/*
 * The following functions provide basic support for non-console stdio.
 */
int
__open_file(const char * path, __file_modes mode, __file_handle * handle)
{
    char buffer[256];
    int volume = __sys_path(path, buffer, sizeof(buffer));
    UInt16 vfsmode = 0;
    Err err;
    
    if (mode.open_mode == __create_if_necessary) {
        vfsmode |= vfsModeCreate;
    } else if (mode.open_mode == __create_or_truncate) {
        vfsmode |= vfsModeCreate | vfsModeTruncate;
    }
    if (mode.io_mode & __read) {
        vfsmode |= vfsModeRead;
    } else if (mode.io_mode & __write) {
        vfsmode |= vfsModeWrite;
    }
    err = VFSFileOpen(volume, buffer, vfsmode, handle);
    return (err ? __io_error : __no_io_error);
}

int
__close_file(__file_handle file)
{
    Err err = VFSFileClose((FileRef) file);
    return (err ? __io_error : __no_io_error);
}

int
__read_file(__file_handle file, unsigned char * buff, size_t * count, __ref_con ref_con)
{
    Err err = VFSFileRead((FileRef) file, *count, buff, count);
    return (*count ? __no_io_error : (err == vfsErrFileEOF ? __io_EOF : __io_error));
}

int
__write_file(__file_handle file, unsigned char * buff, size_t * count, __ref_con ref_con)
{
    Err err = VFSFileWrite((FileRef) file, *count, buff, count);
    return (err ? __io_error : __no_io_error);
}

int
__position_file(__file_handle file, fpos_t * position, int mode, __ref_con ref_con)
{
    Err err = VFSFileSeek((FileRef) file, (FileOrigin) mode, (Int32) *position);
    if (err == errNone || err == vfsErrFileEOF) {
        err = VFSFileTell((FileRef) file, position);
    }
    return (err ? __io_error : __no_io_error);
}

int
__delete_file(const char * name)
{
    char buffer[256];
    int volume = __sys_path(name, buffer, sizeof(buffer));
    return (VFSFileDelete(volume, buffer) ? __io_error : __no_io_error);
}

int
__rename_file(const char * src, const char * dst)
{
    char srcbuf[256];
    int srcvol = __sys_path(src, srcbuf, sizeof(srcbuf));
    char dstbuf[256];
    int dstvol = __sys_path(dst, dstbuf, sizeof(dstbuf));
    if (srcvol == dstvol && !VFSFileRename(srcvol, srcbuf, dstbuf)) {
        return __no_io_error;
    }
    return __io_error;
}

/*
 * The following function provide common unix system call interface.
 */
int open(const char *path, int flags, ...)
{
    __file_handle fd = -1;
    __file_modes mod = {0};
    if (flags & O_RDONLY) mod.io_mode = __read;
    if (flags & O_WRONLY) mod.io_mode = __write;
    if (flags & O_RDWR  ) mod.io_mode = __read_write;
    if (flags & O_APPEND) mod.io_mode = __append;
    __open_file(path, mod, &fd);
    return (int) fd;
}

int close(int fd)
{
    Err err = VFSFileClose((FileRef) fd);
    return (err ? -1 : 0);
}

int read(int fd, void* buf, size_t len)
{
    Err err = VFSFileRead((FileRef) fd, len, buf, &len);
    return (len > 0) ? len : (err ? -1 : 0);
}

int write(int fd, void* buf, size_t len)
{
    Err err = VFSFileWrite((FileRef) fd, len, buf, &len);
    return (len > 0) ? len : (err ? -1 : 0);
}

long lseek(int fd, long offset, int whence)
{
    VFSFileSeek((FileRef) fd, (FileOrigin) whence, offset);
    return VFSFileTell((FileRef) fd, (UInt32*)&offset) ? -1 : offset;
}

int chsize(int fd, long size)
{
    return VFSFileResize((FileRef) fd, size) ? -1 : 0;
}

int fstat(int fd, struct stat * buf)
{
    memset(buf, 0, sizeof(*buf));
    VFSFileGetDate((FileRef) fd, vfsFileDateModified, (UInt32*)&buf->st_mtime);
    buf->st_mtime -= 2082844800;
    return VFSFileSize((FileRef) fd, (UInt32*)&buf->st_size) ? -1 : 0;
}

int access(const char *path, int mode)
{
    char buffer[256];
    int volume = __sys_path(path, buffer, sizeof(buffer));
    FileRef f;

    if (!VFSFileOpen(volume, buffer, (mode == W_OK ? vfsModeWrite : vfsModeRead), &f)) {
        VFSFileClose(f);
        return 0;
    }

    return -1;
}

int mkdir(const char *path, ...)
{
    char buffer[256];
    int volume = __sys_path(path, buffer, sizeof(buffer));
    return VFSDirCreate(volume, buffer) ? -1 : 0;
}

int rmdir(const char* path)
{
    char buffer[256];
    int volume = __sys_path(path, buffer, sizeof(buffer));
    return VFSFileDelete(volume, buffer) ? -1 : 0;
}

void abort(void)
{
    ErrDisplayFileLineMsg(__FILE__, 0, "abort");
}

void exit(int status)
{
    ErrDisplayFileLineMsg(__FILE__, status, "Installation Error - File not Found");
}

/*
 * The following functions provide simple time support to MSL.
 */
time_t
__get_time(void)
{
    // Convert epoch 1904-01-01 to 1970-01-01
    return TimGetSeconds() - 2082844800;
}

int
__to_gm_time(time_t* time)
{
    // Convert local time to utc time
    *time -= (PrefGetPreference(prefTimeZone) + PrefGetPreference(prefDaylightSavingAdjustment)) * 60;
    return 1;
}

int
__isdst(void)
{
    // Check if we in day light saving time currently.
    return PrefGetPreference(prefDaylightSavingAdjustment) != 0;
}

struct DIR
{
    struct dirent   _d__dirent;
    UInt32          _d__ref;        /* new style FSRef of directory to iterate */
    UInt32          _d__iterator;   /* new style directory iterator reference */
    FileInfoType    _d__f_info;
};

DIR* opendir (const char * path)
{
    char buf[256];
    int volume = __sys_path(path, buf, sizeof(buf));
    DIR * dir = NULL;
    FileRef dirRef;

    if (errNone == VFSFileOpen(volume, buf, vfsModeRead, &dirRef)) {
        dir = (DIR*) MemGluePtrNewL(sizeof(DIR));
        if (NULL != dir) {
            dir->_d__ref = dirRef;
            dir->_d__iterator = vfsIteratorStart;
            dir->_d__f_info.nameBufLen = sizeof(dir->_d__dirent.d_name);
            dir->_d__f_info.nameP = dir->_d__dirent.d_name;
        }
    }
    
    return dir;
}

int closedir(DIR * dir)
{
    int res = -1;

    if (dir) {
        res = VFSFileClose(dir->_d__ref) ? -1 : 0;
        free(dir);
    }
    
    return res;
}

struct dirent* readdir(DIR * dir)
{
    if (VFSDirEntryEnumerate(dir->_d__ref, &dir->_d__iterator, &dir->_d__f_info)) {
        return (struct dirent*) NULL;
    }

    return &dir->_d__dirent;
}


#define __STACK_SIZE__ 32*1024 

uint32 my_stack,my_stackal,old_stack;
  
asm uint32 swap_stack(uint32 new ,uint32 dummy)
{	
	mov  r1,r13
	mov  r13,r0
	mov	 r0,r1
	bx	 lr
}

// ------------------------

unsigned long PNO_Main(
	const void *emulStateP, 
	void *userData68KP, 
	Call68KFuncType *call68KFuncP)
{
	#if DEBUG
	AdnDebugNativeRegister('appl', appFileCreator, 'ARMC', 1);
	#endif
	
	my_emulStateP = (void *)emulStateP;
	my_call68KFuncP = call68KFuncP;

	
	// needed before making any OS calls using the 
	// PACEInterface library
	//InitPACEInterface(emulStateP, call68KFuncP);
	
	//FrmCustomAlert(10024,"PNO_MAIN","","");

	FtrGet(appFileCreator,1112,&host_event_handler);

	/*new stack*/
  	my_stack=(uint32)MemPtrNew(__STACK_SIZE__+8);
  	my_stackal=my_stack+__STACK_SIZE__;
  	my_stackal-=my_stackal&7;

  	old_stack=swap_stack(my_stackal,0);
  	

  	my_emulStateP = (void *)emulStateP;
	my_call68KFuncP = call68KFuncP;

	MameAppStart();

  	swap_stack(old_stack,0);
  	MemPtrFree((void*)my_stack);

	return errNone;
}
