/**
 * BGM/SE manager header file.
 *
 * @version $Revision: 1.1.1.1 $
 */
 
#include <PalmOS.h>
 
#ifdef __cplusplus
extern "C" {
#endif

void closeSound();
void initSound();
Boolean playMusic(char *SongName);
void fadeMusic();
void stopMusic();
void playChunk(int idx);
void playRandomMusic();

extern int useAudio;

extern long MikMod_flags;
extern unsigned long *MikMod_audio_buf;
extern unsigned long MikMod_game_rom;
#ifdef __cplusplus
} // extern "C"
#endif