/*
 * $Id: soundmanager.c,v 1.4 2003/02/09 07:34:16 kenta Exp $
 *
 * Copyright 2002 Kenta Cho. All rights reserved.
 */

/**
 * BGM/SE manager(using SDL_mixer).
 *
 * @version $Revision: 1.4 $
 */
//#include "SDL.h"
#include <PalmOS.h>
#include <stdlib.h>
//#include <stdio.h>
//#include <signal.h>
#include <string.h>
#include <dirent.h>
//#include "stdfile.h"
#include <stdio.h>

//#include "SDL_mixer.h"
#include "soundmanager.h"
#include "host.h"

int useAudio = 0;
int ModPlaying = 0;
Int32 track;

static int NumMusicMods = 0;
unsigned char fnames[256][128]={}; //Global

UInt8 *music[256];
UInt32 musicsize[256];

#define CHUNK_NUM 6
#define MAX_SONGS 256

static char *chunkFileName[CHUNK_NUM] = {
  "shot.wav", "hit.wav", "helix.wav", "die.wav", "splash.wav", "fanfare.wav" 
};
enum
{
	SHOT_WAV=2000,
	HIT_WAV,
	HELLIX_WAV,
	DIE_WAV,
	SPLASH_WAV,
	FANFARE_WAV

};
//static Mix_Chunk *chunk[CHUNK_NUM];
static int chunkFlag[CHUNK_NUM];

void closeSound() {
  int i;
  if ( !useAudio ) return;
  if (ModPlaying == 1)
	  stopMusic();
	  
  MikMod_flags &= 0;
  MikMod_flags |= BF_FREEMOD; 
  Run();
  
  /*for ( i=0 ; i<MUSIC_NUM ; i++ ) {
    if ( music[i] ) {
      free(music[i]);
    }
  }*/
  /*for ( i=0 ; i<CHUNK_NUM ; i++ ) {
    if ( chunk[i] ) {
      Mix_FreeChunk(chunk[i]);
    }
  }
  Mix_CloseAudio();
  */
}


// Initialize the sound.

char *Mix_LoadMUS(const char *filename)
{
	UInt32 fsize;
	char *p=NULL;
	UInt8 fname[256]="";
	UInt8 filename2[256] = "";
	
	
	//AK - add sounds dir to filename.
	//strcpy(filename2,PALMPREFIXDIR);
	strcpy(filename2,"data/");
	strcat(filename2,filename);
	
	fsize = file_size(filename2);
	if (fsize)
	{
		p = malloc(fsize);
		strcpy(fname,filename2);
		FILE* fp = fopen( fname, "r" );
		if ( fp )
		{

			fread( p,sizeof(char), fsize , fp );
			fclose( fp );
		}

	}
	musicsize[0] = fsize;
	return p;

}


static void loadSounds() {
  int i;
  char fname[256];
  char temp[128];
  char temp2[128];

  /*for ( i=0 ; i<MUSIC_NUM ; i++ ) {
    strcpy(fname, "sounds/");
    strcat(fname, musicFileName[i]);
    if ( NULL == (music[i] = Mix_LoadMUS(fname,i)) ) {
      //fprintf(stderr, "Couldn't load: %s\n", name);
      //useAudio = 0;
      //return;
    }
  }*/
  
    struct dirent *DirectoryEntry;
    DIR *DirectoryStream;
    int count = 0;
    strcpy(fname,PALMVFSDIR);
    strcat(fname, "data");

    DirectoryStream = opendir(fname);
    

    while ((DirectoryEntry = readdir(DirectoryStream)) != NULL) 
    {
    	SafeStrCopy(temp,strrchr(DirectoryEntry->d_name, '.'),128,__FILE__,__LINE__);
    	if ((!strcmp(StrToLower(temp2,temp),".it")) || (!strcmp(StrToLower(temp2,temp),".xm")) || (!strcmp(StrToLower(temp2,temp),".mod")))
    	{
	        SafeStrCopy(fnames[count],DirectoryEntry->d_name, 128,__FILE__,__LINE__);
	        count++;
	        if (count >=MAX_SONGS)
	        	break;	
	    }
    }

    closedir(DirectoryStream);
	NumMusicMods = count;
}

void initSound() {
  useAudio = 1;

  loadSounds();
  MikMod_flags &= 0;
  MikMod_flags |= BF_INITMOD; 
  Run();

}

// Play/Stop the music/chunk.

Boolean playMusic(char *SongName) {
	int i;
	int numtracks;
	int found = 0;

  if ( !useAudio ) return;
    
 	if (NumMusicMods == 0) return;
 	stopMusic();
 	
    //track = rand() % NumMusicMods;
    
    for (i=0;i<MAX_SONGS;i++)
    {
    	if (!StrCaselessCompare(SongName,fnames[i]))
    	{
    		found = 1;
    		break;
    	}
    }

	if (found)
	{
	    MikMod_flags &= 0;
	    MikMod_flags |= BF_PLAYMOD;
	    music[0] = Mix_LoadMUS(fnames[i]);
	    MikMod_audio_buf = music[0];
	    MikMod_game_rom = musicsize[0];
	    ModPlaying = 1;
	  	Run();
  	}
  	return found;
}
Boolean Mix_PlayMusic(int track, int foo) {
	int i;
	int numtracks;
	int found = -1;

  if ( !useAudio ) return -1;
    
 	if (NumMusicMods == 0) return -1;
 	stopMusic();
 	
    //track = rand() % NumMusicMods;
    
    if (track > MAX_SONGS)
    	track = 0;

	    MikMod_flags &= 0;
	    MikMod_flags |= BF_PLAYMOD;
	    music[0] = Mix_LoadMUS(fnames[track]);
	    MikMod_audio_buf = music[0];
	    MikMod_game_rom = musicsize[0];
	    ModPlaying = 1;
	  	Run();
	  	
  	return 1;
}
void playRandomMusic() {
	int i;
	int numtracks;

  if ( !useAudio ) return;
    
 	if (NumMusicMods == 0) return;
 	stopMusic();
 	
    track = rand() % NumMusicMods;

    MikMod_flags &= 0;
    MikMod_flags |= BF_PLAYMOD;
    music[0] = Mix_LoadMUS(fnames[track]);
    MikMod_audio_buf = music[0];
    MikMod_game_rom = musicsize[0];
    ModPlaying = 1;
  	Run();
}

/*void fadeMusic() {
  //if ( !useAudio ) return;
  //stopMusic();
}*/

void stopMusic() {
  if ( !useAudio ) return;
  if (ModPlaying == 1)
  {
    MikMod_flags &= 0;
    MikMod_flags |= BF_STOPMOD;
    ModPlaying = 0;
  	Run();
  	free(music[0]);
  	
  }
  
}
void PlayToneOS5(int EffectID)
{
	MemHandle h;
	h = DmGetResource('wave', EffectID);  // find the resource in this PRC (added in the .r file)
	if (h) {
		// play it at the standard volume for game sounds, synchronously.
		SndPlayResource(MemHandleLock(h), 280, sndFlagAsync);
			
		MemHandleUnlock(h);
	}
}

void playChunk(int idx) {
  if ( !useAudio ) return;
  PlayToneOS5((idx+2000));
}
