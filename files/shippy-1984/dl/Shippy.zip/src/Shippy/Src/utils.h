/*
	File:			utils.h

	Description:	Utility Functions

	Author:		

	Copyright:		Copyright � 2003 by Tapwave, Inc.

	Disclaimer:		IMPORTANT:  This Tapwave software is provided by Tapwave, Inc. ("Tapwave").  Your 
					use is subject to and governed by terms and conditions of the Software Development 
					Kit Agreement ("SDK Agreement") between you and Tapwave.  If you have not entered 
					into Tapwave�s standard SDK Agreement with Tapwave, you have no right or license 
					to use, reproduce, modify, distribute or otherwise exploit this Tapwave software.  
					You may obtain a copy of Tapwave�s standard SDK Agreement by calling 650-960-1817
					or visiting Tapwave at http://www.tapwave.com/developers/. 

	Change History (most recent first):
				
*/
#ifndef ISO_UTILS_H
#define ISO_UTILS_H

#include "host.h"
#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************/

/*
 * Macro to construct a frame buffer compatible rgb565 color given
 * three 8 bit components. This is a manually optimized version that
 * is consistent with the other color macros here.
 *
 * Note that the 68k version of this macro generates data that is
 * byte-swapped into little-endian format. This means that data passed
 * to TwGfxDrawBitmap and TwGfxWriteSurface will be properly arranged
 * if you use this macro.
 */
 
typedef UInt32 TwGfxPackedRGBType;
 
#define TwGfxMakeDisplayRGB_BigEndian(_r,_g,_b) \
  ( (((_g) & 0xFC) << 11) | (((_b) & 0xF8) << 5) | ((_r) & 0xF8) | (((_g) & 0xFF) >> 5) )

#define TwGfxMakeDisplayRGB_LittleEndian(_r,_g,_b) \
  ( (((_r) & 0xF8) << 8) | (((_g) & 0xFC) << 3) | (((_b) & 0xF8) >> 3) )

#if CPU_TYPE == CPU_68K
#define TwGfxMakeDisplayRGB(_r,_g,_b) TwGfxMakeDisplayRGB_BigEndian(_r,_g,_b)
#else
#define TwGfxMakeDisplayRGB(_r,_g,_b) TwGfxMakeDisplayRGB_LittleEndian(_r,_g,_b)
#endif

/*
 * This macro converts a RGBColorType structure to a frame buffer
 * compatible display value.
 */
#define TwGfxRGBToDisplayRGB(_rgb) TwGfxMakeDisplayRGB((_rgb).r, (_rgb).g, (_rgb).b)

/*
 * These macros take an 8 bit color component and adjusts them to be
 * sized to match the rgb565 display framebuffer
 */
#define TwGfxRComponentToDisplayComponent(_r) (((_r) & 0xF8) >> 3)
#define TwGfxGComponentToDisplayComponent(_g) (((_g) & 0xFC) >> 2)
#define TwGfxBComponentToDisplayComponent(_b) (((_b) & 0xF8) >> 3)

/*
 * Format information for the rgb565 display buffer
 */
#define twGfxRShift     11
#define twGfxRMask      0xF800
#define twGfxGShift     5
#define twGfxGMask      0x07E0
#define twGfxBShift     0
#define twGfxBMask      0x001F

/*
 * This macro converts from a packed component RGB to a packed display RGB
 */
#define TwGfxPackedRGBToDisplayRGB(_rgb)                               \
  ( (TwGfxRComponentToDisplayComponent((_rgb) >> 16) << twGfxRShift) | \
    (TwGfxGComponentToDisplayComponent((_rgb) >> 8) << twGfxGShift) |  \
    (TwGfxBComponentToDisplayComponent((_rgb)) << twGfxBShift) )

/*
 * This macro converts a packed display RGB value to a packed component RGB value
 */
#define TwGfxDisplayRGBToPackedRGB(_u16)                            \
  TwGfxComponentsToPackedRGB( ((_u16) >> (twGfxRShift - 3)) & 0xF8, \
                              ((_u16) >> (twGfxGShift - 2)) & 0xFC, \
                              ((_u16) << 3) & 0xF8 )
/*
 * This macro converts a RGBColorType structure to a
 * TwGfxPackedRGBType value.
 */
#define TwGfxRGBToPackedRGB(_rgb)                      \
  ((TwGfxPackedRGBType) ( (((UInt32)(_rgb).r) << 16) | \
                          ((UInt32)((_rgb).g) << 8) |  \
                          ((UInt32)(_rgb).b) ) )

/*
 * This macro converts rgb components to a TwGfxPackedRGBType
 */
#define TwGfxComponentsToPackedRGB(_r,_g,_b)                \
  ((TwGfxPackedRGBType) ( ((((UInt32)(_r)) & 0xFF) << 16) | \
                          ((((UInt32)(_g)) & 0xFF) << 8) |  \
                          (((UInt32)(_b)) & 0xFF) ) )

/*
 * This macro helps fill in a TwGfxPointType
 */
#define TwGfxMakePoint(_point, _x, _y) \
  ((_point).x = (_x), (_point).y = (_y))

/*
 * This macro helps fill in a TwGfxRectType
 */
#define TwGfxMakeRect(_rect, _x, _y, _w, _h) \
  ((_rect).x = (_x), (_rect).y = (_y), (_rect).w = (_w), (_rect).h = (_h))

/***********************************************************************/
#define SCREEN_SWIPE_X		0
#define SCREEN_SWIPE_Y		1
#define SCREEN_SCRUNCH		2
#define SCREEN_DISOLVE		4
#define SCREEN_TWIST		3

#define MAX_SCREEN_TRANSITIONS	4


typedef struct
{
	void *rowbytes;
	int bmWidth;
	int bmHeight;

}HBITMAP;

extern Err
AppReadBMP(HBITMAP *bmp, const void * dataP);
    
extern const char* pack(const char* format, char* buf, const void* source);
extern char * LoadImage(char *filename);
extern void CopyRect(RECT *dest, RECT *src);
extern void SetRectEmpty(RECT *dest);
extern bool IntersectRect(RECT *d, RECT *s1, RECT *s2);
extern bool IsRectEmpty(RECT *d);
extern BOOL OffsetRect(RECT *lprc,int dx,int dy);
extern BOOL SetRect(RECT *src,int xLeft,int yTop,int xRight,int yBottom);
extern BOOL PtInRect(RECT *d,POINT pt);
extern void block_draw(UInt16 *buf,signed short int x,signed short int y,
				UInt16 *screen, int screenw, int screenh, Int32 transparent,
				RECT rsrc, int totalw, int totalh);
extern BOOL UnionRect(RECT *Dst, const RECT *Src1,const RECT *Src2);
extern void fast_draw(UInt16 *buf,const RECT *rdst,
				UInt16 *screen, Int32 transparent,
				const RECT *rsrc, int totalw, int totalh);
extern void Screen_Transitions(int effect);
extern UInt32 Start_Clock(void);
extern UInt32 Wait_Clock(UInt32 count);
extern UInt32 Get_Clock(void);
extern void alpha_block_draw(UInt16 *buf,signed short int x,signed short int y,
				UInt16 *screen, int screenw, int screenh, Int32 transparent,
				RECT rsrc, int totalw, int totalh, int alpha);

Err FontInit();
extern Int32 FontDrawChars(const char * s, Int32 length, UInt16 *destSurface, Int32 x, Int32 y);
extern void
FontGetCharsInWidth(const char * s, 
    Int32 * lengthP, //! pass in the length, the length that fits is returned
    Int32 * widthP,  //! pass in the width, the width used is returned.
    char * truncationCharP //! pass in the truncation char, the char (if any) used
    );
extern int FontWordWrap(char *ptr, int inWidth);
extern Int16 FontGetLineHeight();
extern Int16 FontGetCharWidth(char c);
extern void FontClose();


#ifdef __cplusplus
} // extern "C"
#endif

#endif