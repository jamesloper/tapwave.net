#define MAX_FILENAME 256
typedef struct AppNode_struct {
    AppListEntry entry;
    struct AppNode_struct* next;
} AppNodeType;

static Boolean AddAppList( AppNodeType** startP, AppNodeType** currentP, UInt32 creator, Char* name )
{
    AppNodeType* p;
    AppNodeType* newNode;

    p = *startP;

    while ( p != NULL ) {
         if ( p->entry.creator == creator )
             return false;

         p = p->next;
    }

    newNode = MemPtrNew( sizeof( AppNodeType ) );
    if ( newNode == NULL )
        return false;

    MemSet( newNode, sizeof( AppNodeType ), 0 );

    newNode->entry.name = MemPtrNew( StrLen( name ) + 1 );

    if ( newNode->entry.name == NULL ) {
        MemPtrFree( newNode );
        return false;
    }

    newNode->entry.displayName = MemPtrNew( StrLen( name ) + 1 + MAX_ADD_STRING );

    if ( newNode->entry.displayName == NULL ) {
        MemPtrFree( newNode->entry.name );
        MemPtrFree( newNode );
        return false;
    }

    StrCopy( newNode->entry.name, name );
    newNode->entry.creator = creator;

    if ( *currentP == NULL ) {
        *startP = newNode;
    }
    else {
        ( *currentP )->next = newNode;
    }
    *currentP = newNode;
    
    return true;
}



static void ScanDir( FormVariables* v, AppNodeType** startP, AppNodeType** currentP,
    UInt16 volRefNum, Char* dir )
{
    UInt32        iterator;
    FileInfoType  info;
    FileRef       dirRef;
    Err           err;
    Char          nameBuf[ MAX_FILENAME ];

    err = VFSFileOpen( volRefNum, dir, vfsModeRead, &dirRef );

    if ( err != errNone )
        return;

    info.nameP      = nameBuf;
    info.nameBufLen = MAX_FILENAME;

    iterator = vfsIteratorStart;

    while ( iterator != vfsIteratorStop  ) {
        FileRef  fileRef;
        UInt16   attributes;
        UInt32   creator;
        UInt32   type;
        Char     dbName[ dmDBNameLength ];
        Char     fileName[ MAX_FILENAME ];

        err = VFSDirEntryEnumerate( dirRef, &iterator, &info );

        if ( err != errNone )
            break;

        if ( info.attributes & vfsFileAttrDirectory )
            continue;

        if ( MAX_FILENAME <= StrLen( info.nameP ) + StrLen( dir ) + 2 )
            continue;

        if ( StrLen( info.nameP ) < 4 ||
             ( StrCaselessCompare( info.nameP + StrLen( info.nameP ) - 4, ".prc" )  ) )
            continue;

        StrCopy( fileName, dir );
        StrCopy( fileName + StrLen( fileName ), "/" );
        StrCopy( fileName + StrLen( fileName ), info.nameP );

        err = VFSFileOpen( volRefNum, fileName, vfsModeRead, &fileRef );

        if ( err != errNone ) {
            continue;
        }

        err = VFSFileDBInfo( fileRef, dbName, &attributes,
                  NULL, NULL, NULL,  NULL, NULL, NULL, NULL,
                  &type, &creator, NULL );

        if ( err != errNone || type != 'appl' ) {
            continue;
        }

        VFSFileClose( fileRef );

        if ( AddAppList( startP, currentP, creator, dbName ) )
            v->numEntries++;
    }
}



static void MakeDir1( Char* p )
{
     *p++ = '/';
     *p++ = 'P';
     *p++ = 'A';
     *p++ = 'L';
     *p++ = 'M';
     *p++ = '/';
     *p++ = 'L';
     *p++ = 'a';
     *p++ = 'u';
     *p++ = 'n';
     *p++ = 'c';
     *p++ = 'h';
     *p++ = 'e';
     *p++ = 'r';
     *p = 0;
}



static void MakeDir2( Char* p )
{
     *p++ = '/';
     *p++ = 'A';
     *p++ = 'p';
     *p++ = 'p';
     *p++ = 'l';
     *p++ = 'i';
     *p++ = 'c';
     *p++ = 'a';
     *p++ = 't';
     *p++ = 'i';
     *p++ = 'o';
     *p++ = 'n';
     *p++ = 's';
     *p = 0;
}



static void SetupList( FormVariables* v )
{
     DmSearchStateType state;
     Boolean       first;
     LocalID       id;
     UInt16        card;
     UInt16        i;
     AppNodeType*  start;
     AppNodeType*  current;
     UInt16 volRefNum;
     UInt32 volIterator;
     Err    err;


     v->numEntries = 0;
     first         = true;

     start   = NULL;
     current = NULL;

     while ( errNone ==
         DmGetNextDatabaseByTypeCreator( first, &state,
             'appl', 0,
             false, &card, &id ) ) {
         Char name[ dmDBNameLength ];
         UInt32 creator;

         first = false;

         DmDatabaseInfo( card, id, name,
             NULL, NULL,
             NULL, NULL, NULL, NULL, NULL, NULL, NULL,
             &creator );

         if ( AddAppList( &start, &current, creator, name ) )
             v->numEntries++;
    }

    for ( volIterator = vfsIteratorStart ; volIterator != vfsIteratorStop ; ) {
        err = VFSVolumeEnumerate( &volRefNum, &volIterator );
        if ( err == errNone ) {
            Char dir[ 80 ];
            
            MakeDir1( dir );

            ScanDir( v, &start, &current, volRefNum, dir );

            MakeDir2( dir );

            ScanDir( v, &start, &current, volRefNum, dir );
        }
    }

    v->list = MemPtrNew( sizeof( AppListEntry ) * v->numEntries );
    if ( v->list == NULL ) {
        v->numEntries = 0;
        return;
    }
    v->displayNameList = MemPtrNew( sizeof( Char* ) * v->numEntries );
    if ( v->list == NULL ) {
        v->numEntries = 0;
        MemPtrFree( v->list );
        v->list = NULL;
        return;
    }
    
    current = start;
    i       = 0;

    while ( current != NULL ) {
        AppNodeType* prev;

        v->list[ i ] = current->entry;
        v->displayNameList[ i ] = current->entry.displayName;
        i++;
        prev    = current;
        current = current->next;
        MemPtrFree( prev );
    }

#if 0
        { Char f[3],s[10];
        f[0]='%';
        f[1]='d';
        f[2]=0;
        StrPrintF(s,f,123);
        SysFatalAlert(s); }
#endif

    SysInsertionSort( v->list, v->numEntries,
        sizeof( AppListEntry ), Compare, 0 );

    for ( i = 0 ; i < v->numEntries ; i++ )
         v->displayNameList[ i ] = v->list[ i ].displayName;

    LoadActives( v );
}

