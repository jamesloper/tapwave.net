#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#include "Force16_Res.h"

#define MODEL_GENERIC      0
#define MODEL_HAVE_NVFS    1
#define MODEL_MANUAL_FLUSH 2

#define RESID 999

#define SWAP32( x ) ( ( ( x ) >> 24 ) | ( ( ( x ) & 0x00FF0000l ) >> 8 ) | ( ( ( x ) & 0x0000FF00l ) << 8 ) |  ( ( x ) << 24 ) )

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

void HALInvalidateICache(void *address, UInt32 size);
static UInt8 DetectModel( void );
static void Flush( void );

Boolean Activate( Boolean state )
{
    MemHandle resource;
    LocalID   db;
    Boolean   unregistered;
    DmSearchStateType searchState;
    Err err;

    FtrUnregister( MY_CRID, FTR_CURRENT_APP );

    err = DmGetNextDatabaseByTypeCreator( true, &searchState,
               'HACK', MY_CRID, false, &db );

    if ( errNone != err )
        return false;

    unregistered = false;

    if ( errNone == FtrGet( MY_CRID, FTR_LAUNCH_NOTIFICATION_HANDLER_RESOURCE,
            ( UInt32* )&resource ) ) {
        SysNotifyUnregister( db, sysNotifyAppLaunchingEvent, 0 );
        MemHandleUnlock( resource );
        FtrUnregister( MY_CRID, FTR_LAUNCH_NOTIFICATION_HANDLER_RESOURCE );
        unregistered = true;
    }

    if ( state ) {
        void* launchNotificationHandler;
        DmOpenRef ref;

        ref = DmOpenDatabase( db, dmModeReadOnly );

        if ( ref == NULL )
            return false;

        resource = DmGetResource( 'armc', 998 );

        if ( resource == NULL ) {
            DmCloseDatabase( ref );
            return false;
        }

        FtrSet( MY_CRID, FTR_LAUNCH_NOTIFICATION_HANDLER_RESOURCE, ( UInt32 )resource );

        launchNotificationHandler = MemHandleLock( resource );

        Flush();

        SysNotifyRegister( db, sysNotifyAppLaunchingEvent,
            launchNotificationHandler,
            0, NULL );

        DmReleaseResource( resource );

        DmCloseDatabase( ref );

        return true;
    }
    else {
        return unregistered;
    }

}


static UInt8 DetectModel( void )
{
    UInt32 companyID;
    UInt32 deviceID;
    Err    err;

    err = FtrGet( sysFtrCreator, sysFtrNumOEMCompanyID, &companyID );

    if ( err != errNone )
        return MODEL_GENERIC;

    err = FtrGet( sysFtrCreator, sysFtrNumOEMDeviceID, &deviceID );

    if ( err != errNone )
        return MODEL_GENERIC;

    if ( companyID == 'palm' && deviceID == 'TnT5' )
        return MODEL_HAVE_NVFS; // T5

    if ( companyID == 'hspr' && deviceID == 'H102' )
        return MODEL_HAVE_NVFS; // Treo 650

    if ( companyID == 'palm' && deviceID == 'Frg1' )
        return MODEL_MANUAL_FLUSH;

//   if ( companyID == 'sony' )       SysReset();

    return MODEL_GENERIC;
}


static void Flush( void )
{
    if ( MODEL_MANUAL_FLUSH & DetectModel() ) {
        asm( "mov    r0,#0" );
        asm( "mcr    p15,0,r0,c7,c10,4" );
        asm( "mcr    p15,0,r0,c7,c7,0" );
    }
    else {
        HALInvalidateICache( 0, 0 );
    }
}




