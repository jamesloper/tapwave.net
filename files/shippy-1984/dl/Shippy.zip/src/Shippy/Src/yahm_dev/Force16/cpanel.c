#include <PalmOS.h>
#include <SonyCLIE.h>
#include "Force16_Res.h"

#define RESID 2000

#define MAX_ADD_STRING 2 // StrLen("+ ")

#define RIGHT_OFFSET 10 // 9 + 1, 9 = size of arrow boxes

typedef struct {
    UInt32  creator;
    Char*   name;
    Char*   displayName;
    Boolean active;
} AppListEntry;

typedef struct {
    AppListEntry* list;
    Char**     displayNameList;
    UInt16     numEntries;
    Int16      lastItem;
    Boolean    handleLauncher;
} FormVariables;

static Int16 GetItem( Coord x, Coord y );
static void Show( UInt16 id, Boolean state );
static void* GetObjectPtr( UInt16 id );
static Boolean GetBooleanPref( UInt16 id );
static void SetBooleanPref( UInt16 id, Boolean state );
static FormVariables* LoadFormVariables( void );
static void DestroyFormVariables( void );
static void InitializeForm( FormVariables* v );
static void SaveActives( FormVariables* v );
static void SetSameState( FormVariables* v, Boolean state );
static void SetDefaults( FormVariables* v );
static void ToggleState( FormVariables* v, UInt16 i );
static void UpdateList( FormVariables* v );
static ListType* GetList( void );

Boolean FormHandler( EventType* event )
{
    Boolean        handled;
    FormVariables* v;

    handled = false;
    v       = LoadFormVariables();

    if ( v == NULL )
        return false;

    switch (event->eType) {
        case frmOpenEvent:
            InitializeForm( v );
            handled = true;
            break;

        case frmCloseEvent:
            DestroyFormVariables();
            handled = false;
            break;

        case penUpEvent: {
            Int16 item;

            item = GetItem( event->data.penUp.end.x, event->data.penUp.end.y );

            if ( 0 <= item &&
                 item == GetItem( event->data.penUp.start.x,
                             event->data.penUp.start.y ) ) {
                LstSetSelection( GetList(), item );
                ToggleState( v, item );
                UpdateList( v );
            }
            else {
                v->lastItem = -1;
            }

            break;
        }

        case keyDownEvent: {
            FontID old;
            UInt16 numPerScreen;

            old = FntSetFont( stdFont );
            numPerScreen = LIST_HEIGHT / FntLineHeight();
            FntSetFont( old );

            switch ( event->data.keyDown.chr ) {
                 case pageUpChr:
                 case vchrJogUp:
                      LstScrollList( GetList(), winUp, numPerScreen );
                      handled = true;
                      break;
                 case pageDownChr:
                 case vchrJogDown:
                      LstScrollList( GetList(), winDown, numPerScreen );
                      handled = true;
                      break;
                 default:
                      if ( ! ( event->data.keyDown.modifiers & commandKeyMask ) &&
                           32 <= event->data.keyDown.chr &&
                           event->data.keyDown.chr < 127 ) {
                          UInt16 i;
                          Char   s[ 2 ];

                          *s = ( UInt8 )event->data.keyDown.chr;
                          s[ 1 ] = 0;

                          for ( i = 0 ; i < v->numEntries ; i++ ) {
                               if ( StrCaselessCompare( s, v->list[ i ].name ) <= 0 ||
                                    i + 1 == v->numEntries ) {
                                   UInt16 cur;

                                   cur = LstGetTopItem( GetList() );

                                   if ( cur < i ) {
                                       LstScrollList( GetList(), winDown, i - cur );
                                   }
                                   else if ( i < cur ) {
                                       LstScrollList( GetList(), winUp, cur - i );
                                   }
                                   break;
                               }
                          }
                          handled = true;
                          break;
                      }
                      handled = false;
                      break;
            }
        }

        case ctlSelectEvent: {
            switch( event->data.ctlEnter.controlID ) {
                case chkLauncherFix:
                    SetBooleanPref( PREF_NO_LAUNCHER_FIX,
                        ! CtlGetValue( GetObjectPtr( chkLauncherFix ) ) );
                    handled = true;
                    break;

                case btnDone:
                    DestroyFormVariables();
                    FrmGotoForm( 9000 );
                    handled = true;
                    break;

                case btnAllOn:
                    SetSameState( v, true );
                    SaveActives( v );
                    UpdateList( v );
                    handled = true;
                    break;

                case btnAllOff:
                    SetSameState( v, false );
                    SaveActives( v );
                    UpdateList( v );
                    handled = true;
                    break;

                case btnDefaults:
                    SetDefaults( v );
                    UpdateList( v );
                    handled = true;
                    break;
            }
        }

        case lstSelectEvent: {
            switch ( event->data.lstSelect.listID ) {
                case lstApps:
#if 0
                    if ( 0 <= event->data.lstSelect.selection &&
                         event->data.lstSelect.selection == v->lastItem )
                        ToggleState( v, event->data.lstSelect.selection );
                    v->lastItem = -1;
                    UpdateList( v );
#endif
                    LstSetSelection( GetList(), noListSelection );
                    handled = true;
                    break;
            }
        }

        default:
            break;
    }
    return handled;
}



static FormVariables* LoadFormVariables( void )
{
    Err    err;
    UInt32 value;
    FormVariables* v;

    err = FtrGet( MY_CRID, FTR_FORM_VARIABLES, &value );
    if ( err == errNone )
        return ( FormVariables* )value;

    v = MemPtrNew( sizeof( FormVariables ) );

    if ( v != NULL ) {
        FtrSet( MY_CRID, FTR_FORM_VARIABLES, ( UInt32 )v );
        MemSet( v, sizeof( *v ), 0 );
        v->lastItem = -1;
    }

    return v;
}



static void DestroyFormVariables( void )
{
    Err     err;
    UInt32  value;
    FormVariables* v;

    err = FtrGet( MY_CRID, FTR_FORM_VARIABLES, &value );

    if ( err == errNone ) {
        v = ( FormVariables* )value;
        if ( NULL != v ) {
            if ( NULL != v->displayNameList ) {
                UInt16 i;
                for ( i = 0 ; i < v->numEntries ; i++ )
                     if ( NULL != v->displayNameList[ i ] )
                         MemPtrFree( v->displayNameList[ i ] );

                MemPtrFree( v->displayNameList );
                LstSetListChoices( GetList(), NULL,
                    0 );
            }
            if ( NULL != v->list ) {
                UInt16 i;
                for ( i = 0 ; i < v->numEntries ; i++ )
                     if ( NULL != v->list[ i ].name )
                         MemPtrFree( v->list[ i ].name );

                MemPtrFree( v->list );
            }
            MemPtrFree( v );
        }
        FtrUnregister( MY_CRID, FTR_FORM_VARIABLES );
    }
}



static void SetActiveInList( FormVariables* v, 
    UInt16 i, Boolean state )
{
     FontID oldFont;
     Int16  fit;
     Coord  maxWidth;
     Boolean doFit;

     v->list[ i ].active = state;

     StrPrintF( v->displayNameList[ i ],
         state ? "+ %s" : "- %s",
         v->list[ i ].name );

     oldFont = FntSetFont( stdFont );

     maxWidth = LIST_WIDTH - RIGHT_OFFSET;

     fit = StrLen( v->displayNameList[ i ] );

     FntCharsInWidth( v->displayNameList[ i ], &maxWidth, &fit, &doFit );

     v->displayNameList[ i ][ fit ] = 0;

     FntSetFont( oldFont );
}



static void SetActiveInListByCreator( FormVariables* v,
    UInt32 creator, Boolean state )
{
     UInt16 i;

     for ( i = 0 ; i < v->numEntries ; i++ ) {
          if ( v->list[ i ].creator == creator ) {
              SetActiveInList( v, i, state );
              return;
          }
     }
     return;
}



static void LoadActives( FormVariables* v )
{
    UInt16  size;
    UInt32* list;
    UInt16  numCreatorIds;
    UInt16  i;

    size = 0;
    
    SetSameState( v, false );

    if ( noPreferenceFound ==
             PrefGetAppPreferences( MY_CRID, PREF_CREATOR_ID_LIST,
             NULL, &size, true ) ) {
        SetDefaults( v );
        return;
    }

    numCreatorIds = size / sizeof( UInt32 );

    if ( numCreatorIds == 0 )
        return;

    size = sizeof( UInt32 ) * numCreatorIds;

    list = MemPtrNew( size );
    if ( list == NULL )
        return;

    PrefGetAppPreferences( MY_CRID, PREF_CREATOR_ID_LIST,
        list, &size, true );

    v->handleLauncher = true;
    for ( i = 0 ; i < numCreatorIds ; i++ ) {
        SetActiveInListByCreator( v, list[ i ], true );
        if ( list[ i ] == 'lnch' )
            v->handleLauncher = true;
    }

    MemPtrFree( list );
}



static void SaveActives( FormVariables* v )
{
    UInt16 i;
    UInt16 j;
    UInt16 size;
    UInt16 numActives;
    UInt32* list;
    Boolean launcherState;
    
    launcherState = false;

    numActives = 0;

    for ( i = 0 ; i < v->numEntries ; i++ )
         if ( v->list[ i ].active )
             numActives++;

    if ( numActives == 0 ) {
        UInt8  dummy = 0;

        PrefSetAppPreferences( MY_CRID, PREF_CREATOR_ID_LIST,
            1, &dummy,
            1, true );

        v->handleLauncher = launcherState;
        return;
    }

    size = numActives * sizeof( UInt32 );
    list = MemPtrNew( size );
    if ( list == NULL ) {
        v->handleLauncher = launcherState;
        return;
    }

    j = 0;
    for ( i = 0 ; i < v->numEntries ; i++ ) {
         if ( v->list[ i ].active ) {
             list[ j++ ] = v->list[ i ].creator;
             if ( v->list[ i ].creator == 'lnch' )
                 launcherState = true;
         }
    }

    PrefSetAppPreferences( MY_CRID, PREF_CREATOR_ID_LIST,
        1, list, size, true );

    v->handleLauncher = launcherState;

    MemPtrFree( list );
}



static void SetSameState( FormVariables* v, Boolean state )
{
    UInt16 i;

    for ( i = 0 ; i < v->numEntries ; i ++ )
         SetActiveInList( v, i, state );
}



static void SetDefaults( FormVariables* v )
{
    SetSameState( v, false );

    SetActiveInListByCreator( v, 'lnch', true ); // launcher
    SetActiveInListByCreator( v, 'MSAp', true ); // audio player
    SetActiveInListByCreator( v, 'ClMe', true ); // clie memo
    SetActiveInListByCreator( v, 'IrRm', true ); // clie RMC
    SetActiveInListByCreator( v, 'SdUt', true ); // sound utl
    SetActiveInListByCreator( v, 'SaVm', true ); // voice rec
    SetActiveInListByCreator( v, 'SWAC', true ); // world alarm clock
    
    v->handleLauncher = true;

    SaveActives( v );
}



static void ToggleState( FormVariables* v, UInt16 i )
{
    SetActiveInList( v, i, ! v->list[ i ].active );
    SaveActives( v );
}


static Int16 Compare( void* a, void* b, Int32 other )
{
     return StrCaselessCompare( ( ( AppListEntry* )a )->name, ( ( AppListEntry* )b )->name );
}


#include "setuplist.c"


static void InitializeForm( FormVariables* v )
{
    FrmDrawForm( FrmGetActiveForm() );

    if ( v->list == NULL ) {

        SetupList( v );
    }

    if ( v->numEntries != 0 ) {
        LstSetListChoices( GetList(), v->displayNameList,
            v->numEntries );
        LstSetSelection( GetList(), noListSelection );
    }

    CtlSetValue( GetObjectPtr( chkLauncherFix ),
        ! GetBooleanPref( PREF_NO_LAUNCHER_FIX ) );

    UpdateList( v );
}



static void UpdateList( FormVariables* v )
{
    LstDrawList( GetList() );
    Show( chkLauncherFix, v->handleLauncher );

}




static ListType* GetList( void )
{

     return GetObjectPtr( lstApps );
}



static void* GetObjectPtr( UInt16 id )
{
    return FrmGetObjectPtr( FrmGetActiveForm(),
                   FrmGetObjectIndex( FrmGetActiveForm(),
                       id ) );
}


static void Show( UInt16 id, Boolean state )
{
    FormType* currentForm;

    UInt16 index;

    currentForm = FrmGetActiveForm();

    index = FrmGetObjectIndex( currentForm,
        id );

    if ( state )
        FrmShowObject( currentForm, index );
    else
        FrmHideObject( currentForm, index );
    if ( FrmGetObjectType( currentForm, index ) ==
             frmControlObj )
        CtlSetUsable( GetObjectPtr( id ), state);
}


static void SetBooleanPref( UInt16 id, Boolean state )
{
    PrefSetAppPreferences( MY_CRID, id,
        1, &state, sizeof( state ), true );
}



static Int16 GetItem( Coord x, Coord y )
{
    Int16 retval;

    retval = -1;

    if ( ADJ_LIST_X <= x && x < ADJ_LIST_X + LIST_WIDTH && ADJ_LIST_Y <= y && y < ADJ_LIST_Y + LIST_HEIGHT ) {
        FontID oldFont;
        UInt16 pos;
        UInt16 numPerScreen;
        ListType* list;

        list = GetList();

        oldFont = FntSetFont( stdFont );

        numPerScreen = LIST_HEIGHT / FntLineHeight();

        pos = LstGetTopItem( list ) +
                  ( y - ADJ_LIST_Y ) / FntLineHeight();

#if 0
        { Char f[3],s[10];
        f[0]='%';
        f[1]='d';
        f[2]=0;
        StrPrintF(s,f,x);
        SysFatalAlert(s); }
#endif

        if ( y < ADJ_LIST_Y + FntLineHeight() * numPerScreen &&
             pos < LstGetNumberOfItems( list ) ) {
            Char* s;

            s = LstGetSelectionText( list, pos );

            if ( x < ADJ_LIST_X + 3 + FntCharsWidth( s, StrLen( s ) ) ) {
                retval = pos;
            }
        }

        FntSetFont( oldFont );

    }
    return retval;
}


#include "pref.c"
