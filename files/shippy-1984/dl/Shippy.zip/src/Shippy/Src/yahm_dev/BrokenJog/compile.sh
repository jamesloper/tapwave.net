pilrc -q -ro BrokenJog.rcp
arm-palmos-gcc -Wall -Wno-multichar -fshort-enums -fpack-struct -O1  -DMY_CRID=\'BrJo\' -nostartfiles -D_ARM_HACK_ -c -o code03e8.o code03e8.c
arm-palmos-gcc -nostartfiles -o code03e8 code03e8.o ../lib/libarmboot.a
build-prc --no-check-resources -o BrokenJog.prc -n "BrokenJog" -c BrJo -t 'HACK' BrokenJog.ro code03e8
