#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#include "Force16_Res.h"

#include "palmbitmap.h"

#define RESID 1002

#define RED_BITS                     5
#define GREEN_BITS                   6
#define BLUE_BITS                    5

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

static const UInt16 indexToRGB[ 256 ] = { 65535, 65151, 64735, 64319, 63903, 63519, 65529,
65145, 64729, 64313, 63897, 63513, 65523, 65139, 64723, 64307, 63891, 63507,
53247, 52863, 52447, 52031, 51615, 51231, 53241, 52857, 52441, 52025, 51609,
51225, 53235, 52851, 52435, 52019, 51603, 51219, 40959, 40575, 40159, 39743,
39327, 38943, 40953, 40569, 40153, 39737, 39321, 38937, 40947, 40563, 40147,
39731, 39315, 38931, 26623, 26239, 25823, 25407, 24991, 24607, 26617, 26233,
25817, 25401, 24985, 24601, 26611, 26227, 25811, 25395, 24979, 24595, 14335,
13951, 13535, 13119, 12703, 12319, 14329, 13945, 13529, 13113, 12697, 12313,
14323, 13939, 13523, 13107, 12691, 12307, 2047, 1663, 1247, 831, 415, 31, 2041,
1657, 1241, 825, 409, 25, 2035, 1651, 1235, 819, 403, 19, 65516, 65132, 64716,
64300, 63884, 63500, 65510, 65126, 64710, 64294, 63878, 63494, 65504, 65120,
64704, 64288, 63872, 63488, 53228, 52844, 52428, 52012, 51596, 51212, 53222,
52838, 52422, 52006, 51590, 51206, 53216, 52832, 52416, 52000, 51584, 51200,
40940, 40556, 40140, 39724, 39308, 38924, 40934, 40550, 40134, 39718, 39302,
38918, 40928, 40544, 40128, 39712, 39296, 38912, 26604, 26220, 25804, 25388,
24972, 24588, 26598, 26214, 25798, 25382, 24966, 24582, 26592, 26208, 25792,
25376, 24960, 24576, 14316, 13932, 13516, 13100, 12684, 12300, 14310, 13926,
13510, 13094, 12678, 12294, 14304, 13920, 13504, 13088, 12672, 12288, 2028,
1644, 1228, 812, 396, 12, 2022, 1638, 1222, 806, 390, 6, 2016, 1632, 1216, 800,
384, 4226, 8452, 16936, 21162, 29614, 35921, 44373, 48599, 57083, 61309, 50712,
32768, 32784, 1024, 1040, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, };

typedef void (*pfnWinDrawBitmap)( BitmapType* bitmapP, Coord x, Coord y );

static UInt32 GetCurrentApp( void );
static Boolean GetBooleanPref( UInt16 id );
//static Boolean ClieLauncher( void );

void MyWinDrawBitmap( BitmapType* bitmapP, Coord x, Coord y )
{
    pfnWinDrawBitmap oldTrap;
    UInt32 tval;
    UInt32 maxCombined;
    Boolean haveTval;
    BitmapType* next;
    UInt16 firstVal;
    WinHandle drawW;
    UInt32 color;
    BitmapType* bitmap;
    UInt32 value;

    FtrGet(MY_CRID, RESID, (UInt32*) &oldTrap );

    if ( GetCurrentApp() != 'lnch' ||
         errNone != FtrGet( MY_CRID, FTR_ACTIVE, &value ) ||
         GetBooleanPref( PREF_NO_LAUNCHER_FIX ) ){
        oldTrap( bitmapP, x, y );
        return;
    }

    drawW = WinGetDrawWindow();

    if ( x != 0 || y != 0 ||
         drawW == WinGetDisplayWindow() ) {
        oldTrap( bitmapP, x, y );
        return;
    }

    bitmap = WinGetBitmap( drawW );

    if ( bitmap == NULL ||
         BmpGetBitDepth( bitmap ) != 16 ||
         BmpGetVersion( bitmap ) != 3 ||
         ( ( PalmBitmapTypeV3* )bitmap )->width != 64 ||
         ( ( PalmBitmapTypeV3* )bitmap )->height != 44 ) {
        oldTrap( bitmapP, x, y );
        return;
    }

#if 0
                { char s[55];
                RGBColorType c;
                WinGetPixelRGB( 0,0,&c );
                StrPrintF(s,"%04x",*( UInt16* )( BmpGetBits( bitmap ) ) );
                WinDrawChars(s,4,0,0);
                StrPrintF(s,"%04x",firstVal);
                WinDrawChars(s,4,0,20);
                 }
#endif

    tval     = 0xFFFFFFFFul;
    haveTval = false;
    maxCombined = 0;

    next = bitmapP;

    while ( NULL != next ) {
        UInt32 combined;

        combined = BmpGetBitDepth( next ) | ( BmpGetDensity( next ) << 16 );

        if ( maxCombined < combined ) {
            maxCombined = combined;
            if ( 8 <= ( combined & 0xFF ) ) {
                haveTval = BmpGetTransparentValue( next, &tval );
            }
            firstVal = * ( UInt16* ) BmpGetBits( next );
        }

        next = BmpGetNextBitmapAnyDensity( next );
    }

    if ( tval == 0xFFFFFFFFul ) {
        oldTrap( bitmapP, x, y );
        return;
    }

    if ( ( maxCombined & 0xFF ) == 16 ) {
        RGBColorType c, c0;
        RectangleType r = { { 0,0}, {64,44} };
        color = tval;

        c.r = ( tval >> ( BLUE_BITS + GREEN_BITS ) ) * 255u / MAX_RED;
        c.g = ( ( tval >> ( BLUE_BITS ) ) & MAX_GREEN ) * 255u / MAX_GREEN;
        c.b = ( tval & MAX_BLUE ) * 255u / MAX_BLUE;

        WinSetForeColorRGB( &c, &c0 );
        WinDrawRectangle( &r, 0 );
        WinSetForeColorRGB( &c0, 0 );
    }
    else {
        color = indexToRGB[ tval & 0xFF ];
    }
    oldTrap( bitmapP, x, y );

    FtrSet( MY_CRID, FTR_DO_TRANSPARENCY, 1 );
    BmpSetTransparentValue( bitmap, color );
    FtrUnregister( MY_CRID, FTR_DO_TRANSPARENCY );
}


static UInt32 GetCurrentApp( void )
{
  UInt32 creator;

  if ( errNone == FtrGet( MY_CRID, FTR_CURRENT_APP, &creator ) )
      return creator;
  else
      return 0;
}

#include "pref.c"
//#include "clielauncher.c"
