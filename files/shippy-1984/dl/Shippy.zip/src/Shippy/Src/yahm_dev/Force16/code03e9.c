#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#include "Force16_Res.h"

#define RESID 1001

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

static UInt32 GetCurrentApp( void );
static Boolean GetBooleanPref( UInt16 id );
//static Boolean ClieLauncher( void );

typedef void (*pfnBmpSetTransparentValue)( BitmapType* bitmapP,
   UInt32 transparentValue );

void MyBmpSetTransparentValue( BitmapType* bitmapP, UInt32 transparentValue )
{
    pfnBmpSetTransparentValue oldTrap;
    UInt32 value;

    if ( GetCurrentApp() == 'lnch' &&
         errNone == FtrGet( MY_CRID, FTR_ACTIVE, &value ) &&
         ! GetBooleanPref( PREF_NO_LAUNCHER_FIX ) &&
         errNone != FtrGet( MY_CRID, FTR_DO_TRANSPARENCY, &value ) &&
         BmpGetTransparentValue( bitmapP, &value )
       )
        return;

    FtrGet(MY_CRID, RESID, (UInt32*) &oldTrap );

    oldTrap( bitmapP, transparentValue );
}


static UInt32 GetCurrentApp( void )
{
  UInt32 creator;
  
  if ( errNone == FtrGet( MY_CRID, FTR_CURRENT_APP, &creator ) )
      return creator;
  else
      return 0;
}



#include "pref.c"
//#include "clielauncher.c"
