Boolean ActivatedForCreator( UInt32 creator )
{
    UInt16  size;
    UInt32* list;
    UInt16  numCreatorIds;
    UInt16  i;
    Boolean active;

    size = 0;

    if ( noPreferenceFound ==
             PrefGetAppPreferences( MY_CRID, PREF_CREATOR_ID_LIST,
             NULL, &size, true ) ) {
        switch ( creator ) {
          case 'lnch': // Launcher
          case 'MSAp': // Audio Player
    //      case 'CLFl': // Clie Files
          case 'ClMe': // Clie Memo
          case 'IrRm': // Clie RMC
          case 'SdUt': // Sound Utl
          case 'SaVm': // Voice Rec
          case 'SWAC': // World Alarm Clock
               return true;
          default:
               return false;
        }
    }

    numCreatorIds = size / sizeof( UInt32 );

    if ( numCreatorIds == 0 )
        return false;

    size = sizeof( UInt32 ) * numCreatorIds;
    list = MemPtrNew( size );

    if ( list == NULL )
        return false;

    PrefGetAppPreferences( MY_CRID, PREF_CREATOR_ID_LIST,
        list, &size, true );

    active = false;

    creator = ByteSwap32( creator );

    for ( i = 0 ; i < numCreatorIds ; i++ ) {
        if ( list[ i ] == creator ) {
            active = true;
            break;
        }
    }

    MemPtrFree( list );

    return active;
}


