pilrc -q -ro A5AgendaHack.rcp
arm-palmos-gcc -Wall -Wno-multichar -fshort-enums -fpack-struct -O1  -DMY_CRID=\'Gil3\' -nostartfiles -D_ARM_HACK_ -c -o code03e8.o code03e8.c
arm-palmos-gcc -nostartfiles -o code03e8 code03e8.o ../lib/libarmboot.a
build-prc --no-check-resources -o A5AgendaHack.prc -n "A5AgendaHack" -c Gil3 -t 'HACK' A5AgendaHack.ro code03e8
