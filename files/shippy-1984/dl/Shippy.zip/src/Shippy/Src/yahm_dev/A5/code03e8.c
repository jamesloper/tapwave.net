#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#define RESID 1000

#define A5_CRID 'Gill'

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);


typedef void (*pfnFrmGotoForm)(UInt16 formId);

Boolean isDateBookActive(void);
void RunDatebook(void);

void myFrmGotoForm(UInt16 formId){
	pfnFrmGotoForm oldTrap;

	FtrGet(MY_CRID, RESID, (UInt32 *)&oldTrap);
	if (isDateBookActive() && formId == 0x898){
		RunDatebook();
	}
	oldTrap(formId);
}

void RunDatebook(void){
	DmSearchStateType dss;
	LocalID lid;
	UInt16 cardNo;
	if (DmGetNextDatabaseByTypeCreatorV40(true, &dss, 'appl', A5_CRID, true, &cardNo, &lid) == errNone){
		SysUIAppSwitchV40(cardNo, lid, 0x8001, NULL);
	}
}

Boolean isDateBookActive(void){
	LocalID lid;
	UInt16 cardNo;
	UInt32 crid;

	if (SysCurAppDatabaseV40(&cardNo, &lid) != errNone){
		return false;
	}
	if (DmDatabaseInfoV40(cardNo, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, &crid) != errNone){
		return false;
	}
	return crid == 'date';
}
