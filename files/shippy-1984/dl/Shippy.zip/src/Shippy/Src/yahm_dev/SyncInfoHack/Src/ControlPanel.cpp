#include <palmos.h>
#include "SyncInfoHack.h"
#include "SyncInfoHackRsc.h"
#include "DLServer.h"

static Char* StrIdx(Char* str, UInt16 index);
static void * GetObjectPtr(UInt16 objectID);
static Boolean GetNameFromCrid(UInt32 crid,Char* buffer);
static void StringSort(Char **src, UInt16 numitem);
static void OpenDatabase(DmOpenRef *dbref);
static Err CloseDatabase(DmOpenRef dbref);
static void SaveProcedure();
static UInt16 FindRecord(Char *app,DmOpenRef dbref);
static void CSetFieldContent(UInt16 FieldID, Char *text);
static void GetHSForApplication(Char *app, Char* HS, DmOpenRef dbref);
static void RemoveCurrent();

typedef struct
{
	Char *listptr,*choicesptr; // for holding listitems
	UInt16 idx;
	UInt16 jumlah;
	MemHandle listchoices;
	DmOpenRef dbref;

} HackVar;

extern "C" bool Entry_Point( EventPtr event )
{
  FormPtr     	form;
  Boolean      	handled = false;
  HackVar		*ftrtemp;	 	
  Err			err,errs;
  Boolean		first;
  DmSearchStateType dsst;
  UInt16 		cardno,ix,attr;
  LocalID		dbidp;
  Char          *tbuf,*tbuf1;
  ListPtr		thelist;
  UInt32		crid;
  ControlPtr	ctrlptr;

  switch ( event->eType ) 
  {
    case frmOpenEvent:
    
      form = FrmGetActiveForm();
      FrmDrawForm( form );
		
	  ftrtemp=(HackVar*)MemPtrNew(sizeof(HackVar));		
	  FtrSet(MY_CRID,100,(UInt32)ftrtemp);

	  ftrtemp->listptr=(Char*)MemPtrNew(2000);
	  ftrtemp->idx=0;
	  ftrtemp->jumlah=0;

	  tbuf=(Char*)MemPtrNew(30);
	  
//	  StrCopy(ftrtemp->listptr, "All Applications");	
//	  ftrtemp->idx+=StrLen(ftrtemp->listptr)+1;
//	  ftrtemp->jumlah++;

	  first=true;

	  do
	  {
			errs=DmGetNextDatabaseByTypeCreator(first, &dsst, 'appl', 0, true, &cardno, &dbidp);
			first=false;
			DmDatabaseInfo(cardno, dbidp, tbuf, &attr, NULL, NULL, NULL, NULL, NULL, NULL,
			  	NULL, NULL, &crid);

			if (!(attr & dmHdrAttrHidden))
			{
				if (GetNameFromCrid(crid,tbuf))		
				{
					StrCopy(&ftrtemp->listptr[ftrtemp->idx],tbuf);
					ftrtemp->idx+=StrLen(tbuf)+1;
					ftrtemp->jumlah++;
				}					
			}				
	  
	  } while (errs==errNone);

	  MemPtrFree(tbuf);

	  thelist=(ListPtr)GetObjectPtr(ControlPanelAppList);

	  ftrtemp->listchoices=SysFormPointerArrayToStrings(ftrtemp->listptr, ftrtemp->jumlah);
	  ftrtemp->choicesptr=(Char*)MemHandleLock(ftrtemp->listchoices);
	  
	  StringSort((Char**)ftrtemp->choicesptr,ftrtemp->jumlah);

	  LstSetListChoices(thelist, (Char**)ftrtemp->choicesptr, ftrtemp->jumlah);
	  
	  OpenDatabase(&ftrtemp->dbref);

      handled = true;
      break;
      
    case appStopEvent:
      
      // If the user presses a hard key or taps a silkscreen button while 
      // the control panel is open, this is where any necessary cleanup 
      // should occur

		err=FtrGet(MY_CRID,100,(UInt32*)&ftrtemp);
		if ((!err) && (ftrtemp))
		{
			if (ftrtemp->dbref)
				CloseDatabase(ftrtemp->dbref);

			MemHandleUnlock(ftrtemp->listchoices);
			MemHandleFree(ftrtemp->listchoices);
			MemPtrFree(ftrtemp->listptr);
		  	MemPtrFree((void*)ftrtemp);
		}		  	
		  	
	 	if (!err)
	 		FtrUnregister(MY_CRID,100);

      break;

    case popSelectEvent:
		err=FtrGet(MY_CRID,100,(UInt32*)&ftrtemp);
		
		tbuf=(Char*)MemPtrNew(100);
		tbuf1=((Char**)ftrtemp->choicesptr)[event->data.popSelect.selection];
	
		GetHSForApplication(tbuf1, tbuf, ftrtemp->dbref);
	  	CSetFieldContent(ControlPanelHotSyncField, tbuf);
	
		form=FrmGetActiveForm();
		FrmSetFocus(form, noFocus);
	
		MemPtrFree(tbuf);

	  	
	  break;
	  

    case ctlSelectEvent:

      switch ( event->data.ctlSelect.controlID ) 
      {
        case ControlPanelOKButton:

		 	err=FtrGet(MY_CRID,100,(UInt32*)&ftrtemp);
			if ((!err) && (ftrtemp))
			{
				if (ftrtemp->dbref)
					CloseDatabase(ftrtemp->dbref);
			
			
				MemHandleUnlock(ftrtemp->listchoices);
				MemHandleFree(ftrtemp->listchoices);
				MemPtrFree(ftrtemp->listptr);
			  	MemPtrFree((void*)ftrtemp);
			}		  	
		  	
		 	if (!err)
	 			FtrUnregister(MY_CRID,100);
       
          FrmGotoForm( 9000 );   // Return to YAHM control panel
          handled = true;
 
          break;
          
        case ControlPanelCancelButton:

			err=FtrGet(MY_CRID,100,(UInt32*)&ftrtemp);
       	
			for (ix=0; ix<10; ix++)
				WinDrawChars(StrIdx(ftrtemp->listptr,ix),StrLen(StrIdx(ftrtemp->listptr,ix)),0,ix*11);  

	
			StrIToA(ftrtemp->listptr, ftrtemp->jumlah);
	       	WinDrawChars(ftrtemp->listptr,StrLen(ftrtemp->listptr),0,140);
        
          break;
          
        case ControlPanelSaveButton:
			SaveProcedure();
			form=FrmGetActiveForm();
			FrmSetFocus(form, noFocus);

			handled=true;
          break;
          
		case ControlPanelResetButton:
			RemoveCurrent();
			form=FrmGetActiveForm();
			FrmSetFocus(form, noFocus);
			handled=true;
		  break;
          
      }
      break;
      
    default:
      break;
  }
  
  return handled;
}

static void RemoveCurrent()
{
	Char		*popstr,*tbuf;
	ControlPtr	tpoptrigger;
	UInt16		recfind;
	HackVar		*ftrtemp;
	Err 		err;
	
	err=FtrGet(MY_CRID,100,(UInt32*)&ftrtemp);

	tbuf=(Char*)MemPtrNew(50);

	
	tpoptrigger=(ControlPtr)GetObjectPtr(ControlPanelAppPopTrigger);
	popstr=(Char*)CtlGetLabel(tpoptrigger);
	
	recfind=FindRecord(popstr, ftrtemp->dbref);

	if (recfind!=65535)
	{
		StrCopy(tbuf,"DEFAULT!"); // get default syncinfo
		DlkGetSyncInfo(NULL, NULL, NULL, tbuf, NULL, NULL);
		CSetFieldContent(ControlPanelHotSyncField, tbuf);
		DmRemoveRecord(ftrtemp->dbref, recfind);
	}

	MemPtrFree(tbuf);

}





static void OpenDatabase(DmOpenRef *dbref)
{
	Err err;
	
	*dbref=DmOpenDatabaseByTypeCreator('DATA', MY_CRID, dmModeReadWrite);
	
	if (*dbref==0)
	{
		err=DmGetLastErr();
		if (err==dmErrCantFind)
		{
			err=DmCreateDatabase(0, "SyncInfoHackData", MY_CRID, 'DATA', false);
			if (err==errNone)
			{
				*dbref=DmOpenDatabaseByTypeCreator('DATA', MY_CRID, dmModeReadWrite);
			}
		}
	}
}

static void SaveProcedure()
{
	Char 		*fieldstr,*popstr;
	FieldPtr	tfield;
	ControlPtr	tpoptrigger;
	UInt16		recfind,size;
	MemHandle	recH,oldH;
	Char		*recP;
	Err			err;
	HackVar		*ftrtemp;	 	
	Char		*appbuf,*hsbuf;
	Boolean		samadef;
	
	appbuf=(Char*)MemPtrNew(100);
	
	err=FtrGet(MY_CRID,100,(UInt32*)&ftrtemp);

	tfield=(FieldPtr)GetObjectPtr(ControlPanelHotSyncField);
	tpoptrigger=(ControlPtr)GetObjectPtr(ControlPanelAppPopTrigger);

	fieldstr=FldGetTextPtr(tfield);
	popstr=(Char*)CtlGetLabel(tpoptrigger);
	size=StrLen(popstr)+StrLen(fieldstr)+2;

	StrCopy(appbuf,"DEFAULT!");
	DlkGetSyncInfo(NULL, NULL, NULL, appbuf, NULL, NULL);

	samadef=(!StrCompare(appbuf,fieldstr));
	
	recfind=FindRecord(popstr,ftrtemp->dbref);
	
	if (recfind!=65535)
	{
		err=DmRemoveRecord(ftrtemp->dbref,recfind);
		if ((err==errNone) && !samadef)
		{
			recH=DmNewRecord(ftrtemp->dbref, &recfind, size);
			if (recH)
			{
				recP=(Char*)MemHandleLock(recH);
				DmStrCopy(recP,0,popstr);
				DmStrCopy(recP,StrLen(popstr)+1,fieldstr);
				MemHandleUnlock(recH);
			}
			DmReleaseRecord(ftrtemp->dbref, recfind, false);
		}
	}
	else
	{
		recH=DmNewRecord(ftrtemp->dbref, &recfind, size);
		if (recH)
		{
			recP=(Char*)MemHandleLock(recH);
			DmStrCopy(recP,0,popstr);
			DmStrCopy(recP,StrLen(popstr)+1,fieldstr);
			MemHandleUnlock(recH);
		}
		DmReleaseRecord(ftrtemp->dbref, recfind, false);
	}


	MemPtrFree(appbuf);
}


static UInt16 FindRecord(Char *app,DmOpenRef dbref)
{
	UInt16 		ix,numrec;
	MemHandle	recH;
	Char		*recP;
	Boolean		match;
	
	match=false;
	numrec=DmNumRecords(dbref);
	
	for (ix=0;ix<numrec;ix++)
	{
		recH=DmQueryRecord(dbref,ix);
		if (recH)
		{
			recP=(Char*)MemHandleLock(recH);
			if (!StrCompare(app,recP))
				match=true;
			MemHandleUnlock(recH);
		}

		if (match)
			break;
	}

	if (!match)
		ix=65535; // notfound value
		
	return ix;
}

static void GetHSForApplication(Char *app, Char* HS, DmOpenRef dbref)
{
	UInt16		numrec;
	MemHandle	recH;
	Char		*recP;
	
	numrec=FindRecord(app, dbref);
	
	if (numrec!=65535)
	{
		recH=DmQueryRecord(dbref, numrec);
		if (recH)
		{
			recP=(Char*)MemHandleLock(recH);
			StrCopy(HS,StrIdx(recP,1));
			MemHandleUnlock(recH);
		}
	}
	else
	{
		StrCopy(HS,"DEFAULT!"); // set buffer to "DEFAULT!" in order to retrieve original syncinfo
		DlkGetSyncInfo(NULL, NULL, NULL, HS, NULL, NULL);
	}
}


static Err CloseDatabase(DmOpenRef dbref)
{
	Err err;
	
	err=DmCloseDatabase(dbref);
}

static Char* StrIdx(Char* str, UInt16 index) // function to get string from packed-string
{
	Char *dumstr=str;
	UInt16 ix,len;
	
	if (index>0)
	{
		for (ix=0; ix<index; ix++)
		{
			len=StrLen(str);
			str=str+len+1;
		} // end for
	}

	return str;
}

static void * GetObjectPtr(UInt16 objectID)
{
	FormPtr frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}

static void StringSort(Char **src, UInt16 numitem)
{
	UInt16 ix,iy;
	Char *swtemp;
	
	for (ix=0; ix<numitem; ix++)
	{
		for (iy=ix; iy<numitem; iy++)
		{
			if (StrCompare(src[ix],src[iy])>0)
			{
				swtemp=src[ix];
				src[ix]=src[iy];
				src[iy]=swtemp;
			}	
		}
	}
}


static Boolean GetNameFromCrid(UInt32 crid,Char* buffer)
{
	DmOpenRef dref;
	Char *bufftemp, *rP;
	LocalID lid;
	MemHandle rH;

	dref=DmOpenDatabaseByTypeCreator('appl', crid, dmModeReadOnly);
	 
	bufftemp=(Char*)MemPtrNew(32);
	*bufftemp='\0';
	
	DmOpenDatabaseInfo(dref, &lid, NULL, NULL, NULL, NULL);
	DmDatabaseInfo(0, lid, bufftemp, NULL, NULL, NULL, NULL, NULL, NULL, 
				   NULL ,NULL, NULL, NULL);

	rH=DmGet1Resource('tAIN', 1000); // ambil resource utk appname
    if (rH)
	{
		rP=(Char*)MemHandleLock(rH);
		StrCopy(bufftemp,rP);
		MemHandleUnlock(rH);
		DmReleaseResource(rH);
	}

	StrCopy((Char*)buffer, bufftemp);
	DmCloseDatabase(dref);
	MemPtrFree(bufftemp);

	return(true);

}

static void CSetFieldContent(UInt16 FieldID, Char *text)
{
	MemHandle textH;
	int error,length;
	char *str;
	FieldType *field = (FieldType*)GetObjectPtr(FieldID);

	length=StrLen(text)+1;
	textH=FldGetTextHandle(field);
	if (textH)
	{
		FldSetTextHandle(field, NULL);
		error=MemHandleResize(textH, length);
		str = (char*)MemHandleLock(textH);
		StrCopy(str, text);
		MemHandleUnlock(textH);
		FldSetTextHandle(field, textH);
		FldDrawField(field);
	}
	else
	{
		textH=MemHandleNew(length);
		str = (char*)MemHandleLock(textH);
		StrCopy(str, text);
		MemHandleUnlock(textH);
		FldSetTextHandle(field, textH);
		FldDrawField(field);
	}
		
}

