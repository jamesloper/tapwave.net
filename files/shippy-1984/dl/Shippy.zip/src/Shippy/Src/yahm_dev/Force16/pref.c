static Boolean GetBooleanPref( UInt16 id )
{
    UInt16  size;
    Boolean value;

    size = 0;

    if ( noPreferenceFound ==
             PrefGetAppPreferences( MY_CRID, id,
             NULL, &size, true ) || size != 1 )
        return false;

    PrefGetAppPreferences( MY_CRID, id,
                 &value, &size, true );
                 
    return value;
}
