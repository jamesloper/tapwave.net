#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#include "Force16_Res.h"

#include "palmbitmap.h"

#define RESID 1004

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

#define SWAP32( x ) ( ( ( x ) >> 24 ) | ( ( ( x ) & 0x00FF0000l ) >> 8 ) | ( ( ( x ) & 0x0000FF00l ) << 8 ) |  ( ( x ) << 24 ) )

typedef void (*pfnSysAppLauncherDialog)( void );

static Boolean ActivatedForCreator( UInt32 creator );

void MySysAppLauncherDialog( void )
{
    pfnSysAppLauncherDialog oldTrap;
    UInt32    depth;

    FtrGet(MY_CRID, RESID, (UInt32*) &oldTrap );

//        WinDrawChars( "abcdef", 6, 50, 50 );

    if ( ActivatedForCreator( 'lnch' ) ) {
        if ( errNone == WinScreenMode( winScreenModeGet, NULL, NULL, &depth, NULL ) &&
             depth < 16 ) {
            depth = 16;
            WinScreenMode( winScreenModeSet, NULL, NULL, &depth, NULL );
        }
        FtrSet( MY_CRID, FTR_ACTIVE, 1 );
    }
    else {
        FtrUnregister( MY_CRID, FTR_ACTIVE );
    }

    oldTrap();
}



#include "activated.c"
