This is a sample codewarrior 9.2 project writing YAHM's hack (Native ARM hack for OS5).

To prepare it:
- Extract all .zip contents. (with 'use folder' option on) to a folder.
- Copy libarmboot.a and libarmui.a to the folder. 
- ready to build!

Notes:
- The result of the project is a prc file. type: HACK, creator ID: EQhm --> not registered yet.
- Main objective: change SyncName (by patching DlkGetSyncInfo API) for each application.
- Two APIs are patched: DlkGetSyncInfo and SysUIAppSwitch
- Control panel for selecting app and editing SyncName is provided.
- Application-SyncName relation data is stored in a database. (SyncInfoHackData)
- This hack matches by application name. (not by creator id / database name)
  -> if two apps with the same exist. They will be recognized as one.

enjoy.. :-)
cedicaks@yahoo.com



  


