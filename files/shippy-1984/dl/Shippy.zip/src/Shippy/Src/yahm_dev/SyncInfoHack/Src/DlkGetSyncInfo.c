#include <palmos.h>
#include "featuremgr.h"
#include "dlserver.h"
#include "form.h"
#include "SyncInfoHack.h"

static UInt16 FindRecord(Char *app,DmOpenRef dbref);
static void GetHSForApplication(Char *app, Char* HS, DmOpenRef dbref);
static void OpenDatabase(DmOpenRef *dbref);
static Err CloseDatabase(DmOpenRef dbref);
static Char* StrIdx(Char* str, UInt16 index); // function to get string from packed-string

typedef Err (*pfnDlkGetSyncInfo)(UInt32 *succSyncDateP, UInt32 *lastSyncDateP, DlkSyncStateType *syncStateP, 
            Char *nameBufP, Char *logBufP, Int32 *logLenP);

Err ARMlet_Main (UInt32 *succSyncDateP, UInt32 *lastSyncDateP, DlkSyncStateType *syncStateP, 
            Char *nameBufP, UInt32 dummy1, UInt32 dummy2, Char *logBufP, Int32 *logLenP)

{
	pfnDlkGetSyncInfo 	oldTrap;
	Err 				err;
	Char 				*buf;
	UInt16 				prefsize,prefver;
	DmOpenRef			dbref;
	UInt16				getdefault;

	buf=MemPtrNew(50);

	getdefault=0;
	
	if (nameBufP)
		if (!StrCompare(nameBufP,"DEFAULT!"))
		{
			getdefault=65535;
			StrCopy(buf,nameBufP);
		}			
	
	FtrGet(MY_CRID, RES_DLKGETSYNCINFO, (UInt32 *)&oldTrap);
	err=oldTrap(succSyncDateP, lastSyncDateP, syncStateP, nameBufP, logBufP, logLenP);

	prefsize=50;
    prefver=PrefGetAppPreferences(MY_CRID, 1, buf, &prefsize, true);

	if ((getdefault!=65535) && (nameBufP))
	{
		if (prefver==curprefver)
		{
			OpenDatabase(&dbref);
			
			if (dbref)
			{
				GetHSForApplication(buf, nameBufP, dbref);
				err=CloseDatabase(dbref);
				if(err!=errNone)
				{
					StrIToA(buf,err);
					WinDrawChars(buf, StrLen(buf), 50,0);
				}
			}
			else
			{
				err=DmGetLastErr();
				StrIToA(buf,err);

			}
		}
	}
	else
	{
		// DEFAULT atau namebuf = NULL
	}


	MemPtrFree(buf);

	return err;
}

static UInt16 FindRecord(Char *app,DmOpenRef dbref)
{
	UInt16 		ix,numrec;
	MemHandle	recH;
	Char		*recP;
	Boolean		match;
	
	match=false;
	numrec=DmNumRecords(dbref);
	
	for (ix=0;ix<numrec;ix++)
	{
		recH=DmQueryRecord(dbref,ix);
		if (recH)
		{
			recP=(Char*)MemHandleLock(recH);
			if (!StrCompare(app,recP))
				match=true;
			MemHandleUnlock(recH);
		}

		if (match)
			break;
	}

	if (!match)
		ix=65535; // notfound value
		
	return ix;
}

static void GetHSForApplication(Char *app, Char* HS, DmOpenRef dbref)
{
	UInt16		numrec;
	MemHandle	recH;
	Char		*recP;
	UInt32		signature;
	
	numrec=FindRecord(app, dbref);
	
	if (numrec!=65535)
	{
		recH=DmQueryRecord(dbref, numrec);
		if (recH)
		{
			recP=(Char*)MemHandleLock(recH);
			StrCopy(HS,StrIdx(recP,1));
			MemHandleUnlock(recH);
		}
	}
	else
	{
	}
	
}

static void OpenDatabase(DmOpenRef *dbref)
{
	Err err;
	
	*dbref=DmOpenDatabaseByTypeCreator('DATA', MY_CRID, dmModeReadOnly);
}

static Err CloseDatabase(DmOpenRef dbref)
{
	Err err;
	
	err=DmCloseDatabase(dbref);
	return err;
}

static Char* StrIdx(Char* str, UInt16 index) // function to get string from packed-string
{
	Char *dumstr=str;
	UInt16 ix,len;
	
	if (index>0)
	{
		for (ix=0; ix<index; ix++)
		{
			len=StrLen(str);
			str=str+len+1;
		} // end for
	}

	return str;
}
