#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

// included from SonyChars.h
#define vchrJogUp					(0x1700)
#define vchrJogDown				(0x1701)

#define RESID 1000

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

typedef void (*pfnEvtGetEvent)(EventType *event, Int32 timeout);

void MyEvtGetEvent (EventType *event, Int32 timeout){
	pfnEvtGetEvent oldTrap;

	FtrGet(MY_CRID, RESID, (UInt32 *)&oldTrap);
	oldTrap(event, timeout);
	if (event->eType == keyDownEvent){

		if (event->data.keyDown.chr == vchrJogDown){
			event->data.keyDown.chr = vchrPageDown;
		}
		if (event->data.keyDown.chr == vchrJogUp){
			event->data.keyDown.chr = vchrPageUp;
		}
/* Sample
		if (event->data.keyDown.chr == vchrCalc){
			event->data.keyDown.chr = vchrRonamatic;
		}
*/
	}
}
