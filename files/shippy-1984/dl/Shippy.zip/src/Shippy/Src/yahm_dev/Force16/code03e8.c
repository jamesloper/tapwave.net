#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#include "Force16_Res.h"

#define RESID 1000

#define SWAP32( x ) ( ( ( x ) >> 24 ) | ( ( ( x ) & 0x00FF0000l ) >> 8 ) | ( ( ( x ) & 0x0000FF00l ) << 8 ) |  ( ( x ) << 24 ) )

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

typedef Err (*pfnWinScreenMode)( WinScreenModeOperation operation,
    UInt32* widthP, UInt32* heightP, UInt32* depthP, Boolean* enableColorP );

Boolean ActivatedForApp( void );

Err MyWinScreenMode( WinScreenModeOperation operation,
    UInt32* widthP, UInt32* heightP, UInt32* depthP, Boolean* enableColorP )
{
    pfnWinScreenMode oldTrap;
    UInt32 depth2;
    UInt32 value;

    FtrGet(MY_CRID, RESID, (UInt32*) &oldTrap );
    
    switch ( operation ) {
        case winScreenModeSetToDefaults:
            if ( errNone == FtrGet( MY_CRID, FTR_ACTIVE, &value ) ) {
                UInt32 defaultWidth;
                UInt32 defaultHeight;
                Boolean enableColor;
                
                if ( errNone == oldTrap( winScreenModeGetDefaults, &defaultWidth,
                                    &defaultHeight, NULL, &enableColor ) ) {
                    depth2 = 16;
                    return oldTrap( winScreenModeSet, &defaultWidth, &defaultHeight,
                               &depth2, &enableColor );
                }
            }
            break;

        case winScreenModeGetDefaults:
            if ( depthP != NULL &&
                 errNone == FtrGet( MY_CRID, FTR_ACTIVE, &value ) ) {
                Err err;

                err = oldTrap( winScreenModeGetDefaults, widthP, heightP,
                          depthP, enableColorP );

                *depthP = 16;
                
                return err;
            }
            break;

        case winScreenModeSet: {
            if ( errNone == FtrGet( MY_CRID, FTR_ACTIVE, &value )
                 && depthP != NULL
                 && *depthP < 16 ) {

                if ( errNone == oldTrap( winScreenModeGet, NULL, NULL, &depth2, NULL ) ) {
                    if ( depth2 != 16 ) {
                        depth2 = 16;
                        depthP = &depth2;
                    }
                    else if ( widthP != NULL || heightP != NULL || enableColorP ) {
                        depthP = NULL;
                    }
                    else {
                        return errNone;
                    }
                }
            }
            break;
        }
        
        default:
            break;
    }

    return oldTrap( operation, widthP, heightP, depthP, enableColorP );
}

