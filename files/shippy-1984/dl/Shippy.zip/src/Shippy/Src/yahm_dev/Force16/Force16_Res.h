#define btnDone     1000
#define btnDefaults 1001
#define btnAllOn    1002
#define btnAllOff   1003
#define lstApps     1004
#define chkLauncherFix 1005

#define FTR_FORM_VARIABLES  50
#define FTR_LAUNCH_NOTIFICATION_HANDLER_RESOURCE 51
#define FTR_CURRENT_APP                          52
#define FTR_DO_TRANSPARENCY 90
#define FTR_ACTIVE          91

#define PREF_CREATOR_ID_LIST 1
//#define PREF_LAUNCHER_FIX    2
#define PREF_NO_LAUNCHER_FIX 3

#define frmSetup    2000

#define LIST_HEIGHT 99
#define LIST_WIDTH  152
#define LIST_X      2
#define LIST_Y      27

#define FORM_X      2
#define FORM_Y      2

#define ADJ_LIST_X  ( LIST_X+FORM_X )
#define ADJ_LIST_Y  ( LIST_Y+FORM_Y )
