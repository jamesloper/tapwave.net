#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#include "Force16_Res.h"

#include "palmbitmap.h"

#define RESID 1003

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

#define SWAP32( x ) ( ( ( x ) >> 24 ) | ( ( ( x ) & 0x00FF0000l ) >> 8 ) | ( ( ( x ) & 0x0000FF00l ) << 8 ) |  ( ( x ) << 24 ) )

typedef void (*pfnSysAppUISwitch)( LocalID id, UInt16 cmd, MemPtr cmdPBP );

static Boolean ActivatedForCreator( UInt32 creator );

void MySysAppUISwitch( LocalID id, UInt16 cmd, MemPtr cmdPBP )
{
    pfnSysAppUISwitch oldTrap;
    UInt32    creator;
    UInt32    type;
    UInt32    depth;

    FtrGet(MY_CRID, RESID, (UInt32*) &oldTrap );

    DmDatabaseInfo( id, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
        NULL, &type, &creator );
        
//    if ( creator == 'lnch' )
//        WinDrawChars( "abcdef", 6, 50, 50 );

    if ( type == 'appl' && ActivatedForCreator( creator ) ) {
        if ( errNone == WinScreenMode( winScreenModeGet, NULL, NULL, &depth, NULL ) &&
             depth < 16 ) {
            depth = 16;
            WinScreenMode( winScreenModeSet, NULL, NULL, &depth, NULL );
        }
        FtrSet( MY_CRID, FTR_ACTIVE, 1 );
    }
    else {
        FtrUnregister( MY_CRID, FTR_ACTIVE );
    }

    return oldTrap( id, cmd, cmdPBP );
}



#include "activated.c"
