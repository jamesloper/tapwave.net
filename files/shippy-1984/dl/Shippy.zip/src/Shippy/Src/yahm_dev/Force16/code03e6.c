#include <Standalone.h>
#include "../Include/endianutils.h"
#include "../Include/palmos5.h"

#include "Force16_Res.h"

#define RESID 998

STANDALONE_CODE_RESOURCE_TYPESTR_ID("armc", RESID);

static Boolean ActivatedForCreator( UInt32 creator );

Err AppLaunchNotificationHandler( SysNotifyParamType* np )
{
    LocalID   db;
    UInt32    creator;
    Err       err;

    db = ReadUnaligned32( & ( ( ( SysNotifyAppLaunchOrQuitType* )np->notifyDetailsP )->dbID ) );

    err = DmDatabaseInfo( db, NULL, NULL, NULL,
        NULL, NULL, NULL, NULL, NULL, NULL, NULL, &creator );
        
    if ( err != errNone )
        creator = 0;

    FtrSet( MY_CRID, FTR_CURRENT_APP, creator );

    if ( creator && ActivatedForCreator( creator ) ) {
        UInt32 depth;

        if ( errNone == WinScreenMode( winScreenModeGet, NULL, NULL, &depth, NULL ) &&
             depth < 16 ) {
            depth = 16;
            WinScreenMode( winScreenModeSet, NULL, NULL, &depth, NULL );
        }
        FtrSet( MY_CRID, FTR_ACTIVE, 1 );
    }
    else {
        FtrUnregister( MY_CRID, FTR_ACTIVE );
    }

    return errNone;
}

#include "activated.c"
