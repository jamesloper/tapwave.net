
#define MY_CRID 'EQhm'
#define curprefver 1

#define RES_SYSUIAPPSWITCH 1000
#define RES_DLKGETSYNCINFO 1001

