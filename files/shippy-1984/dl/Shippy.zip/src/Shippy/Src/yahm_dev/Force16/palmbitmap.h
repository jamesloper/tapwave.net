/* This header file defines various structures for Palm bitmaps.
   There is no guarantee that OS functions will generate bitmaps
   in these formats, but they accept bitmaps in these formats
   (with the correct version numbers). */

#ifndef PLUCKER_PALMBITMAP_H
#define PLUCKER_PALMBITMAP_H

#define palmNoDitherLE               0x80

#define palmNoDither                 0x01
#define palmDirectColor              0x04
#define palmHasTransparency          0x20
#define palmHasColorTable            0x40  /* constants for bitmap flags */
#define palmCompressed               0x80


#define RED_BITS                     5
#define GREEN_BITS                   6
#define BLUE_BITS                    5
#define MAX_RED                      ( ( 1 << RED_BITS ) - 1 )
#define MAX_GREEN                    ( ( 1 << GREEN_BITS ) - 1 )
#define MAX_BLUE                     ( ( 1 << BLUE_BITS ) - 1 )

typedef enum {
        palmPixelFormatIndexed = 0,
        palmPixelFormat565,
        palmPixelFormat565LE,
        palmPixelFormatIndexedLE,
} PalmPixelFormatType;

typedef struct {
        Int16  width;
        Int16  height;
        UInt16 rowBytes;
        UInt8  flags;
        UInt8  reserved0;
        UInt8  pixelSize;
        UInt8  version;
} PalmBitmapType;

typedef struct {
        Int16  width;
        Int16  height;
        UInt16 rowBytes;
        UInt8  flags;
        UInt8  reserved0;
        UInt16 reserved[4];
} PalmBitmapTypeV0;

#define PalmBitmapTypeV0_sizes  "W8"

typedef struct {
        Int16  width;
        Int16  height;
        UInt16 rowBytes;
        UInt8  flags;
        UInt8  reserved0;
        UInt8  pixelSize;
        UInt8  version;
        UInt16 nextDepthOffset;
        UInt16 reserved[2];
} PalmBitmapTypeV1;

#define PalmBitmapTypeV1_sizes "W4B2W3"

typedef struct {
        Int16  width;
        Int16  height;
        UInt16 rowBytes;
        UInt8  flags;
        UInt8  reserved0;
        UInt8  pixelSize;
        UInt8  version;
        UInt16 nextDepthOffset;
        UInt8  transparentIndex;
        UInt8  compressionType;
        UInt16 reserved;
} PalmBitmapTypeV2;

#define PalmBitmapTypeV2_sizes "W4B2WB2W"

#define SIZE_V0V1V2 16

typedef struct {
       Int16  width;
       Int16  height;
       UInt16 rowBytes;
       UInt8  flags;
       UInt8  reserved0;
       UInt8  pixelSize;
       UInt8  version;
       UInt8  size;
       UInt8  pixelFormat;
       UInt8  unused;
       UInt8  compressionType;
       UInt16 density;
       UInt32 transparentValue;
       UInt32 nextBitmapOffset;
} PalmBitmapTypeV3;

#define PalmBitmapTypeV3_sizes "W3FBB6WDD"

typedef struct {
       UInt8 redBits;
       UInt8 greenBits;
       UInt8 blueBits;
       UInt8 reserved;
       RGBColorType transparentColor;
} PalmDirectInfoType;       

typedef enum {
    palmBitmapCompressionTypeScanLine = 0,
    palmBitmapCompressionTypeRLE,
    palmBitmapCompressionTypePackBits,
    palmBitmapCompressionTypeEnd,
    palmBitmapCompressionTypeBest = 0x64,
    palmBitmapCompressionTypeNone = 0xFF
} PalmBitmapCompressionType;

typedef struct {
        UInt16 numEntries;
        /* RGBColorType entry[]; */
} PalmColorTableType;
#define PalmColorTableType_sizes "W";

typedef struct {
    UInt8 redBits;
    UInt8 greenBits;
    UInt8 blueBits;
    UInt8 reserved;
    RGBColorType transparentColor;
} PalmBitmapDirectInfoType;
#define PalmBitmapDirectInfoType_sizes "B7";

#endif /* PALM_BITMAP_H */

