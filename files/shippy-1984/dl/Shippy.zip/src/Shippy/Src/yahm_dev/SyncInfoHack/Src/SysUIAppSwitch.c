//#include <size_t.h>
//#include <cstddef>
#include "endianutils.h"
#include "os5.h"
#include <palmos.h>
#include "featuremgr.h"
#include "dlserver.h"
#include "form.h"
#include "SyncInfoHack.h"
#include "VFSmgr.h"


static Boolean GetNameFromCrid(UInt32 crid,Char* buffer);

typedef Err (*pfnSysUIAppSwitch) (UInt16 cardNo, LocalID dbID,
			UInt16 cmd, MemPtr cmdPBP);

Err ARMlet_Main (LocalID dbID, UInt32 dmy, UInt32 cmd, MemPtr cmdPBP)

{
	pfnSysUIAppSwitch oldTrap;

	Char *buf;
	UInt16 tcardNo, tcmd;
	UInt16 prefsize,prefver;
	UInt32 crid;
	
	UInt32 voliterator;
	UInt16 volref;

	FtrGet(MY_CRID, RES_SYSUIAPPSWITCH, (UInt32 *)&oldTrap);


	buf=MemPtrNew(50);

	prefsize=50;

    prefver=PrefGetAppPreferences(MY_CRID, 2, buf, &prefsize, true);
    
    if (prefver==curprefver)
		PrefSetAppPreferences(MY_CRID, 3, curprefver, buf, prefsize, true);

	prefsize=50;
	
    prefver=PrefGetAppPreferences(MY_CRID, 1, buf, &prefsize, true);
    
    if (prefver==curprefver)
		PrefSetAppPreferences(MY_CRID, 2, curprefver, buf, prefsize, true);


	DmDatabaseInfo(0, dbID, NULL, NULL, NULL, NULL, NULL,
					NULL, NULL, NULL, NULL, NULL, &crid);
					
	GetNameFromCrid(crid,buf);

	PrefSetAppPreferences(MY_CRID, 1, curprefver, buf, StrLen(buf)+1, true);

	MemPtrFree(buf);

	return oldTrap(dbID, dmy, cmd, cmdPBP);
}

static Boolean GetNameFromCrid(UInt32 crid,Char* buffer)
{
	DmOpenRef dref;
	Char *bufftemp, *rP;
	LocalID lid;
	MemHandle rH;

	dref=DmOpenDatabaseByTypeCreator('appl', crid, dmModeReadOnly);
	
	if (!dref) // tidak berhasil cari 'appl' dengan crid 
	{
		*buffer='\0';
		StrCopy(buffer,"!!!");
		StrNCat(buffer, (Char*)&crid, 8);	
		return false;
	}
		 
	bufftemp=(Char*)MemPtrNew(32);
	*bufftemp='\0';
	
	DmOpenDatabaseInfo(dref, &lid, NULL, NULL, NULL, NULL);
	DmDatabaseInfo(0, lid, bufftemp, NULL, NULL, NULL, NULL, NULL, NULL, 
				   NULL ,NULL, NULL, NULL);

	rH=DmGet1Resource('tAIN', 1000);
    if (rH)
	{
		rP=(Char*)MemHandleLock(rH);
		StrCopy(bufftemp,rP);
		MemHandleUnlock(rH);
		DmReleaseResource(rH);
	}

	StrCopy((Char*)buffer, bufftemp);
	DmCloseDatabase(dref);
	MemPtrFree(bufftemp);

	return(true);

}