#ifndef __EXTERNS_H__
#define __EXTERNS_H__

extern int waitforkey;
extern int jdirx;
extern int jdiry;
extern int jaction;
extern int jsecond;
extern int waitforkey;
extern int done;
extern int gscale;
extern volatile int objectsynch;

#endif
