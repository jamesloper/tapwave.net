#include <PalmOS.h>

#include <SDL.h>
//#include <SDL_mixer.h>
#include "shippy.h"
#include "SoundManager.h"
#include "host.h"

SDL_Surface *screen = NULL;
SDL_Surface *BackBuffer = NULL;
SDL_Surface *Graphics = NULL;
Uint8 key[1337];

Uint32 CLEARCOLOR = 0;
SDL_Rect src;
SDL_Rect dest;

int jdirx=0;
int jdiry=0;
int jaction=0;
int jsecond=0;
int waitforkey=360;

volatile int objectsynch = 0;
Uint32 timing;

#define MAX_SAMPLES 8
SDL_Surface *CreateSurfaceFromBitmap(char *bmpfile,Uint32 flags)
{

    SDL_Surface *junktemp;
    SDL_Surface *junktemp2;

    junktemp=SDL_LoadBMP(bmpfile);
    
    junktemp2=SDL_ConvertSurface(junktemp, junktemp->format,flags);
    SDL_FreeSurface(junktemp);
    
    junktemp=SDL_DisplayFormat(junktemp2);
    SDL_FreeSurface(junktemp2);

    return junktemp;
}

//int audio_op=0;
//Mix_Music *music=NULL;

struct SAMPLEHOLDER
{
    int loaded;
    char samplename[512];
    //Mix_Chunk *sample;
    int voice;
    int counter;
    int istaken;
};

struct SAMPLEHOLDER samples[MAX_SAMPLES];
//int audio_op;
void Start_Audio()
{
    /*int i;
    audio_op=0;
    for(i=0;i<MAX_SAMPLES;++i)
    {
        samples[i].loaded=0;
        samples[i].samplename[0]=0;
        //samples[i].sample=NULL;
        samples[i].voice=-1;
        samples[i].counter=0;
        samples[i].istaken=0;
    }*/
    //music = NULL;
}
    

void audio_start()
{
   initSound();  
}
    
void audio_play(idx)
{
    //check to see if the sample is loaded
    int i;    
    if(useAudio==0) return;
    /*for(i=0;i<MAX_SAMPLES;++i)
    {
        if(samples[i].istaken==0)
        {
            //samples[i].sample = Mix_LoadWAV(wav);
            strcpy(samples[i].samplename,wav);
            //samples[i].voice = Mix_PlayChannel(-1, samples[i].sample, 0);
            samples[i].loaded = 1;
            samples[i].istaken=1;
            ++samples[i].counter;            
            return;
        }
    }*/
    PlayToneOS5(idx);
}

void audio_music(char *mfile)
{
    if(useAudio==0) return;

    stopMusic();
    
    if(!playMusic(mfile))
    {
        //printf("Mix_LoadMUS(%s): %s\n", mfile,Mix_GetError());
        useAudio = 0;
    }
   
    // well, there's no music, but most games don't break without music...
   
}
    
void audio_exec()
{
    /*int i;
    if(useAudio==0) return;
    for(i=0;i<MAX_SAMPLES;++i)
    {
        if(samples[i].istaken)
        {
            if(samples[i].loaded==1)
            {
                if(Mix_Playing(samples[i].voice)==0)
                {
                    --samples[i].counter;   
                    if(samples[i].counter<=0)
                    {
                        //Mix_HaltChannel(samples[i].voice);
                        samples[i].voice = -1;
                        //Mix_FreeChunk(samples[i].sample);
                        //samples[i].sample=NULL;
                        samples[i].istaken=0;
                    }
                    samples[i].loaded=0;
                }
            }
        }
    }*/
    
    //AK - make player loop
    if (useAudio && !Player_Active())
    	Player_SetPosition(0);
}
   
void audio_end()
{
    /*int i;
    useAudio = 0;
    for(i=0;i<MAX_SAMPLES;++i)
    {
        if(samples[i].istaken==1)
        {
            //Mix_HaltChannel(samples[i].voice);
            samples[i].voice = -1;
            //Mix_FreeChunk(samples[i].sample);
        }
    }*/
}
    
    
void End_Audio()
{
    //Mix_HaltMusic();
    //Mix_CloseAudio();
    closeSound();
}

    

int done = 0;
int gscale = 1;


void SYSTEM_CLEANBMP()
{
    if(BackBuffer!=NULL) SDL_FreeSurface(BackBuffer);
    if(Graphics!=NULL) SDL_FreeSurface(Graphics);
    BackBuffer=NULL;
    Graphics=NULL;
}


void SYSTEM_SETVID()
{
    screen = SDL_SetVideoMode(480, 320, 8, SDL_SWSURFACE | SDL_HWPALETTE);
    if ( screen == NULL )
    {
        return;
    }

    SYSTEM_CLEANBMP();

    Graphics = CreateSurfaceFromBitmap("data/graphics.bmp",SDL_SWSURFACE|SDL_SRCCOLORKEY);
    BackBuffer= CreateSurfaceFromBitmap("data/splash.bmp",SDL_SWSURFACE|SDL_SRCCOLORKEY);
    SDL_SetColors(screen, Graphics->format->palette->colors, 0,Graphics->format->palette->ncolors);
    SDL_SetColorKey(Graphics,SDL_SRCCOLORKEY, SDL_MapRGB(Graphics->format, 255, 0, 255));
    SDL_SetColorKey(BackBuffer,SDL_SRCCOLORKEY, SDL_MapRGB(Graphics->format, 255, 0, 255));
    SDL_SetClipRect(screen, NULL);
    SDL_FillRect(BackBuffer, NULL, CLEARCOLOR);
    CLEARCOLOR = SDL_MapRGB(Graphics->format, 0, 0, 0);
}


int SYSTEM_INIT()
{
   
    if((SDL_Init(SDL_INIT_VIDEO)==-1))
    { 
        return 1;
    }
    timing = SDL_GetTicks();

    atexit(SDL_Quit);
    SYSTEM_SETVID();    
    SDL_WM_SetCaption("Shippy1984 by Ryan Broomfield SDL VERSION", NULL);
	SDL_ShowCursor(SDL_DISABLE);
    audio_start();

    return 0;
}

int SYSTEM_CLEAN()
{
    SYSTEM_CLEANBMP();
    End_Audio();
    return 0;
}

int SYSTEM_GETKEY(int scancode)
{
    return 0;

}

int SYSTEM_BG(char *bmp)
{
    if(BackBuffer!=NULL) SDL_FreeSurface(BackBuffer);
    BackBuffer= CreateSurfaceFromBitmap(bmp,SDL_SWSURFACE|SDL_SRCCOLORKEY);
    if(BackBuffer==NULL) done=1;
    else SDL_SetColorKey(BackBuffer,SDL_SRCCOLORKEY, SDL_MapRGB(Graphics->format, 255, 0, 255));

}


/* NEW SYSTEM_FINISHRENDER() BY JONATHAN GILBERT 1-28-2004 */ 
int SYSTEM_FINISHRENDER()
{
  int x, y, w;
  Uint8 *in;
  Uint16 *out;
 
  if (SDL_MUSTLOCK(BackBuffer))
    SDL_LockSurface(BackBuffer);
  if (SDL_MUSTLOCK(screen))
    SDL_LockSurface(screen);
 
  in = BackBuffer->pixels;
  out = (Uint16 *)screen->pixels;
 
  w = BackBuffer->pitch;

  if (screenWidth == 320)
  {
    int xx, k;
    for (y=0; y<160; y++)
    {
      xx = 0;
      k = 0;
      for (x=0; x<w; x += 2)
      {
        Uint16 sample = *(Uint16 *)&in[x];
 
//      sample = ((sample & 0xff00) >> 8) | ((sample & 0x00ff) << 8);//sample >> 8 << 16);
//      sample *= 0x101;
 
        k++;
        if (k == 3)
        {
          Uint16 tmp;
          tmp = (sample & 0x00ff) | ((sample & 0x00ff) << 8); 
          out[xx] = tmp;
          out[xx + 160] = tmp;
          xx++;
          tmp = (sample & 0xff00) | ((sample & 0xff00) >> 8); 
          out[xx] = tmp;
          out[xx + 160] = tmp;
          xx++;
          k = 0;
        }
        else
        {
          out[xx] = sample;
          out[xx + 160] = sample;
          xx++;
        }
      }
 
      in += w;
      out += 320;
    }
  }
  else
  {
    for (y=0; y<160; y++)
    {
      for (x=0; x<w; x += 2)
      {
        Uint32 sample = *(Uint16 *)&in[x];
 
        sample = (sample & 0xFF) | ((sample & 0xFF00) << 8);//sample >> 8 << 16);
        sample *= 0x101;
 
        *(Uint32 *)(&out[x]) = sample;
        *(Uint32 *)(&out[x + w]) = sample;
      }
 
      in += w;
      out += w + w;
    }
  }

  if (SDL_MUSTLOCK(BackBuffer))
    SDL_UnlockSurface(BackBuffer);
  if (SDL_MUSTLOCK(screen))
    SDL_UnlockSurface(screen);
 
  SDL_UpdateRect(screen, 0, 0, 0, 0);

/*
	{
	debugs("BackBuffer->w ");
	debugu32(BackBuffer->w);
	debugs("\n");
	debugs("BackBuffer->h ");
	debugu32(BackBuffer->h);
	debugs("\n");
	debugs("BackBuffer->pitch ");
	debugu32(BackBuffer->pitch);
	debugs("\n");
	debugs("screen->w ");
	debugu32(screen->w);
	debugs("\n");
	debugs("screen->h ");
	debugu32(screen->h);
	debugs("\n");
	debugs("screen->pitch ");
	debugu32(screen->pitch);
	debugs("\n");
	}
*/
}


int SYSTEM_CLEARSCREEN()
{
    if(SDL_FillRect(BackBuffer, NULL, CLEARCOLOR)==-1)
    {
        printf("CLS ERROR! \n");
    }
}

int SYSTEM_BLIT(int sx, int sy, int x, int y, int szx, int szy)
{
    src.x = sx;
    src.y = sy;
    src.w=szx;
    src.h=szy;
    dest.x=x;
    dest.y=y;
    dest.w=szx;
    dest.h=szy;
    if(SDL_BlitSurface(Graphics,&src,BackBuffer,&dest)==-1)
    {
        printf("SYSTEM_BLIT ERROR! \n");
    }
    
}
//Zodiac defines
#define zJoyUP 0x00010002
#define zJoyRT 0x00080010
#define zJoyDN 0x00020004
#define zJoyLT 0x00040008
#define zJoyCT 0x00100000
#define tLT 0x04000000
#define tRT 0x08000000
#define zActUP 0x10000002
#define zActRT 0x20000040
#define zActDN 0x40000004
#define zActLT 0x80000020
#define bFC 0x00008000
#define bLaunch 0x00800000
#define zPower  0x00000001

#define	keyTwBitFunction        0x00008000  // Pause key on Zodiac
#define keyBitRockerUp		    0x00010000  // 5-way rocker up
#define keyBitRockerDown	    0x00020000  // 5-way rocker down
#define keyBitRockerLeft	    0x00040000  // 5-way rocker left
#define keyBitRockerRight	    0x00080000  // 5-way rocker right
#define keyBitRockerCenter	    0x00100000  // 5-way rocker center/press
#define keyBitLaunch            0x00800000
#define keyBitTriggerA          0x04000000
#define keyBitTriggerB          0x08000000
#define keyBitNavLeft			0x01000000	/**< Key state mask to check the five way navigation LEFT button. */
#define keyBitNavRight			0x02000000	/**< Key state mask to check the five way navigation RIGHT button. */
#define keyBitNavSelect			0x04000000	/**< Key state mask to check the five way navigation SELECT button. */

unsigned long keyBitLeft    = keyBitNavLeft | keyBitRockerLeft;
unsigned long keyBitRight   = keyBitNavRight | keyBitRockerRight;
unsigned long keyBitUp      = keyBitPageUp | keyBitRockerUp;
unsigned long keyBitDown    = keyBitPageDown | keyBitRockerDown;
unsigned long keyBitAction1  = keyBitHard1 | keyBitTriggerA;
unsigned long keyBitAction2  = keyBitHard2 | keyBitTriggerB;
unsigned long keyBitQuit    = keyBitHard4 | keyBitLaunch;
unsigned long keyBitDebug   = keyBitNavSelect | keyBitRockerCenter;

void SYSTEM_POLLINPUT()
{
    int tx,ty;
    UInt32 CurrentKey;
    jaction = 0;
    jsecond = 0;
    jdirx = 0;
    jdiry = 0;

	CurrentKey = KeyCurrentState();
	
	if (IsZodiac)
	{
	    if ((CurrentKey & bLaunch) != 0) done = 1;
	    if (waitforkey > 0)
	    {
	        --waitforkey;
	        return;
	    }
	 }
	 else
	 {
	    if ((CurrentKey & keyBitQuit) != 0) done = 1;
	    if (waitforkey > 0)
	    {
	        --waitforkey;
	        return;
	    }
	 }

/*    if(num_joysticks>0)
    {
        poll_joystick();
        jaction = joy[0].button[0].b;
        jsecond = joy[0].button[1].b;
        jdirx = (joy[0].stick[0].axis[0].d1 - joy[0].stick[0].axis[0].d2)*2;
        jdiry = (joy[0].stick[0].axis[1].d1 - joy[0].stick[0].axis[1].d2);
    }
*/

    jdirx = 0;
    jdiry = 0;
    jaction = 0;
    jsecond = 0;

    /*if(jdirx == 0) jdirx=(key[SDLK_RIGHT] - key[SDLK_LEFT]) * 2;
    if(jdiry == 0) jdiry=key[SDLK_DOWN] - key[SDLK_UP];
    if(jaction == 0) jaction = key[SDLK_LCTRL];
    if(jsecond == 0) jsecond = key[SDLK_BACKSPACE];*/
    
    if (IsZodiac)
    {
	    if(jdirx == 0) 
	    	if ((CurrentKey&zJoyRT)==zJoyRT)
	    		jdirx = 2;
	    	if ((CurrentKey&zJoyLT)==zJoyLT)
	    		jdirx = -2;
	    if(jdiry == 0) 
	    	if ((CurrentKey&zJoyDN)==zJoyDN)
	    		jdiry= 1;
	    	if ((CurrentKey&zJoyUP)==zJoyUP)
	    		jdiry = -1;
	    if(jaction == 0) 
	    	if ((CurrentKey&zActDN)==zActDN)
	    		jaction = 1;
	    if(jsecond == 0) 
	    	if ((CurrentKey&zActRT)==zActRT)
	    		jsecond = 1;
    }
    else
    {
	    if(jdirx == 0) 
	    	if ((CurrentKey & keyBitRight)!=0)
	    		jdirx = 2;
	    	if ((CurrentKey & keyBitLeft)!=0)
	    		jdirx = -2;
	    if(jdiry == 0) 
	    	if ((CurrentKey & keyBitDown)!=0)
	    		jdiry= 1;
	    	if ((CurrentKey & keyBitUp)!=0)
	    		jdiry = -1;
	    if(jaction == 0) 
	    	if ((CurrentKey & keyBitAction1)!=0)
	    		jaction = 1;
	    if(jsecond == 0) 
	    	if ((CurrentKey & keyBitAction2)!=0)
	    		jsecond = 1;
    
    }
		

}

void SYSTEM_IDLE()
{
    Uint32 test = SDL_GetTicks();
    while(test>timing)
    {
        timing+=14;
        ++objectsynch;
    }

  SDL_Event event;
  /* Poll for events. SDL_PollEvent() returns 0 when there are no  */
  /* more events on the event queue, our while loop will exit when */
  /* that occurs.                                                  */
    while( SDL_PollEvent( &event ) )
    {
        /* We are only worried about SDL_KEYDOWN and SDL_KEYUP events */
        if(event.type==SDL_QUIT)
        {
            done=1;
        }
        if(event.type==SDL_KEYDOWN)
        {
            key[event.key.keysym.sym]=1;
        }
        else if(event.type==SDL_KEYUP)
        {
            key[event.key.keysym.sym]=0;
        }
    }
    
}

int main(int argc, char*argv[])
{

	SHIPPY_MAIN();

}
