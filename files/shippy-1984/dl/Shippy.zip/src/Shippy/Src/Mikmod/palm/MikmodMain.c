#include "config.h"

#include "dalloc.h"
#include "mikmod.h"
//#include "loader.h" //AK

//AK 
Int32 MikMod_flags;
UInt8 *MikMod_audio_buf;
UInt32 MikMod_game_rom;

/***************************************************************
	various stuff....
***************************************************************/

MODULE *load_module(char *filename)
{
  FILE *F;
  char text[128];
  int pos;
  MODULE *module;
  
//  menu_confirm("call player_load");
//  menu_confirm(filename);
  module = Player_Load(filename, 64, 0);
//  menu_confirm("ok");
					
  if (!module) {			
      sprintf(text,"Error loading module\n%s.",MikMod_strerror(MikMod_errno));
//		menu_confirm(text);
    } 
  return module;	      
}

MODULE *load_moduleRAM(UInt8 *data,UInt32 size)
{
  char text[128];
  int pos;
  MODULE *module;
  
//  menu_confirm("call player_load");
  module = Player_LoadRAM(data,size, 64, 0);
//  menu_confirm("ok");
					
  if (!module) {			
      sprintf(text,"Error loading module\n%s.",MikMod_strerror(MikMod_errno));
//		menu_message(text);menu_waitPen(NULL,NULL,1);
    } 
  return module;	      
}



/****************************************************************************/
/** Main program                                                           **/
/****************************************************************************/

static MODULE *g_module;

UInt32 mStopEmulation;

unsigned long Run()
{
  char text[128];

   if (MikMod_flags&BF_FREEMOD) {   	
    MikMod_Exit();
   }
   else if (MikMod_flags&BF_INITMOD) {
	  MikMod_RegisterAllDrivers();
	  MikMod_RegisterAllLoaders();
	  /* initialize the library */
	  md_mode |= DMODE_16BITS | /*DMODE_HQMIXER*/DMODE_SOFT_MUSIC | DMODE_INTERP | DMODE_STEREO;    
	  if (MikMod_Init("")) {
		    sprintf(text, "Could not initialize sound, reason:\n%s\n",
		    MikMod_strerror(MikMod_errno));
	  }	
   }
   else if (MikMod_flags&BF_PLAYMOD) {
	  g_module=load_moduleRAM((UInt8*)(MikMod_audio_buf),(MikMod_game_rom)/*mikplay_modname*/);	  
	  PALM_SetVolume(32);
	  Player_Start(g_module);
	  g_module->loop=1;	  
   }
   else if (MikMod_flags&BF_STOPMOD) {
	  Player_Stop();
      Player_Free(g_module);
   }  	
   return 0;
}

/*void ClearScreen(void)
{
	/*UInt8 *vr;
	vr=(UInt8*)(g_pnobridge -> vram);
	for (int y=0;y<g_pnobridge -> display_height;y++)
	{
		memset(vr,0,g_pnobridge -> display_width*2);
		vr+=(g_pnobridge -> display_pitch)*2;
	} //AK - removed
}*/