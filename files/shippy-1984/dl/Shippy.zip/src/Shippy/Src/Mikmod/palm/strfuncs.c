#include "config.h"

/*char *strdup(const char *s) {
	char *str;
	str=(char *)malloc(strlen(s)+1);
	strcpy(str,s);
	return str;
}*/

/*int strcasecmp(const char *s1, const char *s2) {
	char *strUP1,*strUP2;

	int result;

	strUP1=strdup(s1);
	strUP2=strdup(s2);
	
	
	result=gp_str_func.compare(strUP1,strUP2);
	
	
	free(strUP1);
	free(strUP2);

}
*/