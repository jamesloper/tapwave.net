/* Dalloc - "Debugging" malloc library for ANSI C.
          - Written by Jeff Hay, jrhay@lanl.gov

  Very simple "debugging" wrapper for malloc, calloc, realloc, and free.
  Keeps track of memory alloc'd and freed by means of a singly-linked list.  
  DMALLOC and DFREE macros auto-switch between debugging wrapper and 
  "standard" malloc/free by testing the "DEBUG" #define.  Allows for nested 
  layers of malloc wrappers.

  Compile with "DEBUG" and "__TEST_DALLOC__" defined to make a demo/test
  executable.

--- */  

#ifndef _DALLOC_H_
#define _DALLOC_H_

/* These #defines allow for nesting malloc/free wrappers.  These are the 
   functions that the dalloc/dfree family of calls will call do perform the 
   actual malloc/free/etc operation.  Must have stdlib malloc/fee syntax. */
#define DNEXT_MALLOC _mm_malloc
#define DNEXT_CALLOC _mm_calloc
#define DNEXT_REALLOC _mm_realloc
#define DNEXT_FREE _mm_free

#ifdef MALLOC_DEBUG
//#include <stdlib.h>

/* Bookkeeping structures */

typedef struct Dmem *DmemPtr;
struct Dmem {
  void *ID;
  char alloc_data[128];
  size_t size;
  DmemPtr Next;
};

/* 
   Function Prototypes 
                       */

/* Wrapper Functions */
void *dalloc(size_t size,char *file,int line);
void *dcalloc(size_t nmemb, size_t size,char *file,int line);
void *drealloc(void *ID, size_t size,char *file,int line);
void dfree(void *ID);
  /* derealloc() and dfree() can be called with memory not allocated by 
     dalloc() or dcalloc() */

/* Debugging Information Functions */
long dcount(long *Units);
  /* Returns the number of bytes of memory that is currently 
     alloc'd (hasn't yet been freed).  If Units is non-NULL,
     it is set to the number of alloc calls made. */

#define DMALLOC(size) dalloc(size,__FILE__,__LINE__)
#define DCALLOC(num,size)  dcalloc(num,size,__FILE__,__LINE__) 
#define DREALLOC(ID,size) drealloc(ID,size,__FILE__,__LINE__) 
#define DFREE dfree
#define DCOUNT dcount

#else /* DEBUG not defined */

#define DMALLOC DNEXT_MALLOC
#define DCALLOC DNEXT_CALLOC
#define DREALLOC DNEXT_REALLOC
#define DFREE DNEXT_FREE
#define DCOUNT (long)0

#endif /* DEBUG */

#endif /* _DALLOC_H_ */
