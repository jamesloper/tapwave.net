/*	MikMod sound library
	(c) 1998, 1999, 2000 Miodrag Vallat and others - see file AUTHORS for
	complete list.

	This library is DFREE software; you can redistribute it and/or modify
	it under the terms of the GNU Library General Public License as
	published by the Free Software Foundation; either version 2 of
	the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Library General Public License for more details.

	You should have received a copy of the GNU Library General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
	02111-1307, USA.
*/

/*==============================================================================

  $Id: drv_win.c,v 1.5 2002/01/08 21:00:53 miod Exp $

  Driver for output on win32 platforms using the multimedia API

==============================================================================*/

/*

	Written by Bjornar Henden <bhenden@online.no>

*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "mikmod_internals.h"

#ifdef __PALM__

#define __PALM_BUFFER_SIZE__ 1024
#define __PALM_FREQUENCY__ 44100

#include "SoundMgr.h"
static SndStreamRef snd_stream=NULL;
Int32 snd_stream_vol;
typedef struct {uint32 __r9;uint32 __r10;} reg_sys_t;
static reg_sys_t reg_sys;


static Err PALM_sndCallBack (void *userData,SndStreamRef stream, void *bufferZ,UInt32 frameCountZ)
{
	__asm 
	{
		stmfd  r13!,{r9,r10}
		ldr	   r9,[r0]
		ldr	   r10,[r0,#4]
	}	
	/*special hack for loop*/
/*	if (!Player_Active()) VC_PlayStart();
	else*/ VC_WriteBytes(bufferZ,frameCountZ<<2);
	__asm 
	{
		ldmfd  r13!,{r9,r10}
	}
	return errNone;
}


static BOOL PALM_IsThere(void)
{
	return 1;
}

static BOOL PALM_Init(void)
{
	BOOL res;
	snd_stream_vol=1024;	
	
	 __asm 
  {
  	ldr  r0, = reg_sys
  	add	 r0,r0,r10
  	str	 r9,[r0]
  	str	 r10,[r0,#4]
  } 


	SndStreamCreate(&snd_stream,sndOutput,__PALM_FREQUENCY__,sndInt16Little,sndStereo,PALM_sndCallBack,&reg_sys,__PALM_BUFFER_SIZE__, true);	
		
	SndStreamSetVolume(snd_stream,snd_stream_vol);	
			
	res=VC_Init();
	return res;
}

void PALM_SetVolume(int vol)
{
	snd_stream_vol=vol*16;
			
	if (snd_stream) SndStreamSetVolume(snd_stream,snd_stream_vol);  
			
}

void PALM_Stop(void) {
	if (snd_stream) 
	{
				
		SndStreamStop(snd_stream);
				
		SndStreamDelete(snd_stream);
				
		snd_stream=NULL;
	}
}

BOOL PALM_PlayStart(void) {    
	BOOL res;
	res=VC_PlayStart();
	if (snd_stream) 
	{
		
		SndStreamStart(snd_stream);	
				
	}
	return res;
}


void PALM_Restart(void) {    
	if (snd_stream) 
	{
			
		SndStreamStop(snd_stream);
				
		SndStreamStart(snd_stream);	
			
	}
}

static void PALM_Exit(void)
{
	int n;
	PALM_Stop();
	
	VC_Exit();

}

static void PALM_PlayStop(void)
{
	if (snd_stream) {
			
		SndStreamStop(snd_stream);
				
	}
	VC_PlayStop();

}

MIKMODAPI MDRIVER drv_palm={
	NULL,
	"PALMOS Audio v1.0",
	"PALMOS Audio driver v1.0",
	0,255,
	"palm",

	NULL,
	PALM_IsThere,
	VC_SampleLoad,
	VC_SampleUnload,
	VC_SampleSpace,
	VC_SampleLength,
	PALM_Init,
	PALM_Exit,
	NULL,
	VC_SetNumVoices,
	PALM_PlayStart,
	PALM_PlayStop,
	NULL,
	NULL,
	VC_VoiceSetVolume,
	VC_VoiceGetVolume,
	VC_VoiceSetFrequency,
	VC_VoiceGetFrequency,
	VC_VoiceSetPanning,
	VC_VoiceGetPanning,
	VC_VoicePlay,
	VC_VoiceStop,
	VC_VoiceStopped,
	VC_VoiceGetPosition,
	VC_VoiceRealVolume
};

#else

MISSING(drv_gp32);

#endif

/* ex:set ts=4: */
