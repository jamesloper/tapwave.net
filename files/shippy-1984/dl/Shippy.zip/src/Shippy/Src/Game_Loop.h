
#ifndef __GAME_LOOP_H__
#define __GAME_LOOP_H__

#include "MessageBox.h"

const int MAPWIDTH=100;
const int MAPHEIGHT=200;

//names of tiles
const int TILEEMPTY=0;
const int TILEBLOCK=1;
const int TILESTART=2;
const int TILEEND=3;
const int TILEPATH=4;
const int TILESELECT=5;


//gamestates
const int GS_IDLE=0;//waits for a keypress
const int GS_STARTMOVE=1;//sets up the move
const int GS_DOMOVE=2;//carries out the move
const int GS_DONEMOVE=3;//finishes the move




extern POINT ptUnit;
extern ISODIRECTION idMoveUnit;//direction of movement
extern int iGameState;
extern CMessageBox MessageBox;

//map location structure
struct MapLocation
{
	bool bTree;//false=no tree; true=tree
	bool bUnit;//false=no unit; true=unit;
};

extern MapLocation mlMap[MAPWIDTH][MAPHEIGHT];//map array

#endif