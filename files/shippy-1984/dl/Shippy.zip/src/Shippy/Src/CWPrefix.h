

#define __int64 long long
#define INLINE static inline

//#pragma fourbyteints
#pragma align_array_members on
#pragma option align = 4

//#define DEV_BUILD

#define MemPtrNew MemGluePtrNewL
#include "Prefix.h"


#define __DEBUG__

//SDL defines
#define DISABLE_JOYSTICK
#define DISABLE_CDROM
#define DISABLE_AUDIO
#define DISABLE_THREADS
#define ENABLE_PALM
#define PALMOS
//#define USE_PALMOS_VIDEO_ALLOC
