
#ifndef __Prefix_H
#define __Prefix_H 

#ifndef INLINE
#define INLINE static __inline
#endif

//AK - Moved from osd_cpu.h
typedef unsigned char		UINT8;
typedef unsigned short		UINT16;
typedef unsigned int		UINT32;
typedef unsigned __int64	UINT64;
typedef signed char 		INT8;
typedef signed short		INT16;
typedef signed int			INT32;
typedef signed __int64	    INT64;

//#define TINY_COMPILE 1
//#define NEOFREE	1
#define MAX_PATH 254	//AK - just something for now

#define CLIB_DECL
#define TCHAR char
#define FALSE 0
#define TRUE (!FALSE)



//#define Z_SCREEN_WIDTH 320
//#define Z_SCREEN_HEIGHT 320


#ifndef min
#define min(x,y) (((x)<(y))?(x):(y))
#endif
#ifndef max
#define max(x,y) (((x)>(y))?(x):(y))
#endif

#define LSB_FIRST 1
#define ALIGN_INTS


#endif