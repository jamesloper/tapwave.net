/*! file
	File:			HostPalm.c

	Description:	This is the host portion of the example.  OS and device specific code to get the input, 
					load graphics, draw specific graphics, save and load games, and so on belongs 
					in here for use by the game.
	
					This file also provides a TapWave look and feel to the game. This code runs like
					a TapWave app, and can override the game's wishes to provide a best handheld
					interpretation of the game.

					This file is in C like most Palm programs.  It interacts with game.cpp to show
					how to work with C++ programs.

	Author:			Roger Flores

	Copyright:		Copyright � 2003 by Tapwave, Inc.

	Disclaimer:		IMPORTANT:  This Tapwave software is provided by Tapwave, Inc. ("Tapwave").  Your 
					use is subject to and governed by terms and conditions of the Software Development 
					Kit Agreement ("SDK Agreement") between you and Tapwave.  If you have not entered 
					into Tapwave�s standard SDK Agreement with Tapwave, you have no right or license 
					to use, reproduce, modify, distribute or otherwise exploit this Tapwave software.  
					You may obtain a copy of Tapwave�s standard SDK Agreement by calling 650-960-1817
					or visiting Tapwave at http://www.tapwave.com/developers/. 

	Change History (most recent first):
				
*/

/*!

Glossary

game cycle:  Everything needed to advance the game one step.  This includes
    taking input, moving all world objects, triggering events, collision 
    detection, and drawing.

offscreen buffer: A set of pixels not used by the screen.  The graphics 
    are composed there and when done, made visible by the screen, by 
    copying them, or sometimes by pointing the screen hardware to them.
    
landscape mode: The screen placed into 480x320 mode.  No status bar is
    visible.  The Palm coordinate system remains 240x160 (low density).
    
game menu: A UI system to control or configure the game.  The method used
    draws over game in the offscreen buffer.  An alternative is to use 
    the Palm Menu system, but if so, be careful not to draw the game 
    which would overwrite the menus.

Palm bitmaps: Bitmaps in a native Palm format.  Typically created from
    BMP files with pilrc or pasted into Constructor and stored in the
    app's PRC.  Bitmaps can have alternate color depths and resolutions and are 
    collectively called a bitmap family.  The most appropriate family
    member is drawn.  The Palm API usually uses the hardware acceleration 
    when possible.
*/
#include <PalmOS.h>
#include <PenInputMgr.h>
#include <math.h>
#include "twlib.h"
#include <PceNativeCall.h>
#include <size_t.h>
#include <VFSMgr.h>
#include <stdio.h>
#include "host.h"
#include "shippy.h"



extern void	*my_emulStateP;
extern Call68KFuncType	*my_call68KFuncP;
static UInt16 prevcs;
static RGBColorType black = {0,0,0,0};
static void MameAppStop();

#pragma option align=4

enum {
  hf_pin_present = 1              // has VG
  // 2, 4, 8, 16 ...
};

Boolean IsZodiac = false;
/* This is the input that we regularly poll for each game cycle.  More
could be added. */
//static Int16 ShowFirstRom = 0;


#define twCreatorID             'Tpwv'
#define twFtrCreator            twCreatorID
#define twFtrAPIVersion         0x0000



    Boolean isInputMasked;
    UInt16 soundAmp;            // default sound amplitude
    Int32 screenWidth;
    Int32 screenHeight;
    Int32 screenPitch;
	// This is the offscreen buffer which is copied to the screen.
    UInt16 * screenBufferP;  // DOLATER - This is really a pointer to the pixels!
    UInt16 * frameBufferP;
    //! Controls when the next cycle starts
    UInt32 cycleNextTime;
    UInt32 cycleDurationTime;


//! Set to true if TapWave support is detected.  This means that those APIs
//! can be used to widen the screen and read the joystick.
Boolean TapWaveSupport;
static Int32 GTimeOut = 00;

WinHandle oldDrawWinH;
WinHandle OffScreenH;
WinHandle OffFrameH;
RectangleType ScreenRect;




/*! \brief  Mask the keys to reduce keyDownEvents from being sent.

This app does not use the events but polls the keys instead.  This also
sets up the joystick for analog polling.

\see HostUnmaskKeys

*/

void
HostMaskKeys()
{
    if (!isInputMasked)
    {
        // Set the keys we poll to not generate events.  This saves cpu cycles
        // by avoiding the events flowing through the event loop which we will 
        // ignore anyways.
        KeySetMask(0);
        
        isInputMasked = true;
    }
    
    return;
}


/*! \brief  Unmask the keys so they can generate events again.

Also, closes the joystick so it can generate events again.

\see HostMaskKeys
*/
void
HostUnmaskKeys()
{
    if (isInputMasked)
    {
        // Set the keys we poll to not generate events.  This saves cpu cycles.
        KeySetMask(keyBitsAll);
        
        isInputMasked = false;
    }
}

void HostFastDrawLive(UInt8 *buffer, int x, int y, int width, int height, UInt16 *pal16, int IAdjustBase)
{

	UInt8 *src;
	UInt16 *dest;
	int row,column;

	src = buffer;
#ifdef DEV_BUILD
  	HostOpenScreenBuffer();
#endif
  	dest = (UInt16 *)screenBufferP;
	if (dest)
	{
	// Draw bitmap quickly.
		//AK The +8 is to skip the safety area in the imagemap
		src+=(width+16)*8;
#ifndef DEV_BUILD
		dest += IAdjustBase;
#endif
		for (row = height; row > 0; row--)
		{
			src+=8;
			for (column = width; column > 0; column--)
			{
			  	*dest++ = pal16[*src++];
			}
			src+=8;
			dest += (screenWidth-width);
			
		}
	}
#ifdef DEV_BUILD
  HostCloseScreenBuffer();
#endif
}

static Int32
TimeUntillNextPeriod(void)
{
    Int32 timeRemaining = evtWaitForever;

        timeRemaining = (Int32) (cycleNextTime - TimGetTicks());
        if (timeRemaining < 0)
        {
            timeRemaining = 0;
        }

    return timeRemaining;
}


UInt32 query_heap_free ( void ) {
  UInt16 heapid = 0;
  UInt32 max, bytes;

  MemHeapFreeBytes ( heapid, &bytes, &max );

  DEBUGS ( "heapfree" );
  DEBUGU32 ( bytes );

  return ( max );
}
Char* SafeStrCat ( Char *dst, const Char *src, UInt16 maxLengthWithNull, char *theFile, long theLine )
{
	UInt16   concatenated_length;
	//long   return_code;

	concatenated_length = StrLen ( dst ) + StrLen ( src );

	// First determine whether or not the concatenated length is greater than the maxLength

	if ( concatenated_length + 1 > maxLengthWithNull )
	{
		
		// Continue with the "safe" concatenation.
            // Note that StrNCat clips the destination string to n bytes including
            // the null character at the end, and it does append the null character.
		
		StrNCat ( dst, src, maxLengthWithNull );
		
	}  // if ( concatenated_length + 1 > maxLengthWithNull )

	// Just do the regular StrCat
	else
		StrCat ( dst, src );
		
	// return the destination
	return dst;
	
}  // SafeStrCat

Char* SafeStrCopy (Char* dst, const Char* src, UInt16 maxLengthWithNull, char *theFile, long theLine) 
{
	UInt16 srcLength;
	static long return_code;
	
	srcLength = StrLen(src);

	// First determine whether or not the source is greater than the maxLength

	if (srcLength + 1 > maxLengthWithNull )
	{
		
		// Continue with the "safe" copy
		
		StrNCopy ( dst, src, maxLengthWithNull - 1 );
		
		// Make sure we null terminate
		
		*(dst + maxLengthWithNull) = '\0';

	}  // if (srcLength + 1 > maxLengthWithNull )

	// Just do the regular StrCopy
	else
		StrCopy(dst, src);
		
	// return the destination
	return dst;
	
}  // SafeStrCopy
Char * SafeStrIToA ( Char *s, Int32 i, UInt16 maxLengthWithNull, char *theFile, long theLine )
{
      char   StrIToA_result [ maxStrIToALen ];
	UInt16   StrIToA_result_length;
	//long   return_code;
	
      // Determine what the actual destination string length WILL be.

	StrIToA ( StrIToA_result, i );

	StrIToA_result_length = StrLen ( StrIToA_result );

	// First determine whether or not the concatenated length is greater than the maxLength

	if ( StrIToA_result_length + 1 > maxLengthWithNull )
	{
		// Continue with the "safe" StrIToA.
		
		StrNCopy ( s, StrIToA_result, maxLengthWithNull - 1 );
		
		// Make sure we null terminate
		
		*(s + maxLengthWithNull) = '\0';
		
	}  // if ( StrIToA_result_length + 1 > maxLengthWithNull )

	// Just do the regular StrIToA 
	else
		StrIToA ( s, i );
		
	// return the destination
	return s;
	
}  // SafeStrIToA



char PALMPREFIXDIR[256] = "";
char PALMVFSDIR[23] = "/PALM/programs/shippy/";
char PALMOPENDIR[23] = "/PALM/programs/shippy";

static UInt16 voliter = 0xFFEE;

UInt16 palm_vfs_vol ( void ) {
  UInt16 volref = 0;
  UInt32 voliter2 = vfsIteratorStart;
  FileRef file;
  UInt16 firstvolref;

  // can we enumerate at all?
  if ( VFSVolumeEnumerate ( &volref,  &voliter2 ) != errNone ) {
    return ( 0 );
  }

  // store first succeeding volume
  firstvolref = volref;

  // can we open our directory? If so, we found our directory :)
  if ( VFSFileOpen ( volref, PALMVFSDIR, vfsModeRead, &file ) == errNone ) {
    VFSFileClose ( file );
    return ( volref );
  }

  // look through other volumes, trying to find our directory
  while ( VFSVolumeEnumerate ( &volref,  &voliter2 ) == errNone ) {

    if ( VFSFileOpen ( volref, PALMVFSDIR, vfsModeRead, &file ) == errNone ) {
      VFSFileClose ( file );
      return ( volref );
    }

  }

  //return ( voliter );
  return ( firstvolref );
}


UInt32 file_size(const char *filename)
{
  Err error;
  FileRef dummy;
  UInt32 fsize;
  unsigned char fname[256]="";
  char *f;
  
  if ( voliter == 0xFFEE ) {
    voliter = palm_vfs_vol();
  }
  
	//SafeStrCopy(fname,PALMVFSDIR,256,__FILE__,__LINE__);
	//SafeStrCat(fname,filename,256,__FILE__,__LINE__);
	if (filename[1] == ':') //Absolute path
	{
		f=(char *)filename;
		f+=3;
		
	}
	else //relative - add prefix
	{
		SafeStrCopy(fname,PALMVFSDIR,256,__FILE__,__LINE__);
		SafeStrCat(fname,filename,256,__FILE__,__LINE__);
		f=fname;
	}
	
  error = VFSFileOpen ( voliter, f, vfsModeRead ,&dummy );
  
  if (!error)
  	error = VFSFileSize(dummy,&fsize);
  	if (!error)
  	{
  		VFSFileClose(dummy);
  		return fsize;
  	}
  
  return 0;

}

UInt8 file_exists ( char *filename ) {
  FILE *f = fopen ( filename, "r" );

  if ( f ) {
    fclose ( f );
    return ( 1 );
  }

  return ( 0 );
}


Err
MameAppStart()
{
    Err error;
    
    char temp[20];
    //TwGfxInfoType screenInfo;
    UInt32 featureValue;
	int MyKeycode=0;
	//TwGfxRectType aRect;
    UInt16 prefsSize;
    UInt16 prefsSize2;
    Int16 version;
    Int16 version2;
	UInt16 TempPrefs = 0;
	UInt32 *drawBitmapP;
	RectangleType screenRect;
	int new_hd_depth = 16;

	FtrGet(appFileCreator,1112,&host_event_handler);
	FtrGet(appFileCreator,1116,&host_event);

	if (file_exists("A:/PALM/Programs/shippy/data/splash.bmp"))
		SafeStrCopy(PALMPREFIXDIR,"A:/PALM/Programs/shippy/",256,__FILE__,__LINE__);
	else if (file_exists("B:/PALM/Programs/shippy/data/splash.bmp"))
		SafeStrCopy(PALMPREFIXDIR,"B:/PALM/Programs/shippy/",256,__FILE__,__LINE__);
	else if (file_exists("C:/PALM/Programs/shippy/data/splash.bmp"))
		SafeStrCopy(PALMPREFIXDIR,"C:/PALM/Programs/shippy/",256,__FILE__,__LINE__);

    isInputMasked = false;

    IsZodiac = (Boolean) (FtrGet(twFtrCreator, twFtrAPIVersion, (UInt32*)&featureValue) == errNone);
	TapWaveSupport = false;

	FtrGet(appFileCreator,1111,&drawBitmapP);
	screenBufferP = (UInt16 *)(drawBitmapP);
	
	/*prevcs = WinSetCoordinateSystem(kCoordinatesNative);

	WinGetDisplayExtent(&screenWidth, &screenHeight);
	
	WinSetCoordinateSystem(prevcs);*/
	
	FtrGet(appFileCreator,1113,&screenWidth);
	FtrGet(appFileCreator,1114,&screenHeight);
	FtrGet(appFileCreator,1115,&screenPitch);
	//hw_set_fullscreen(1);
	//StrIToA(temp,screenWidth);
	//FrmCustomAlert(10024,"width ",temp,"");
	//AK Set screen to black
	//MemSet(screenBufferP,(screenWidth * screenHeight) * sizeof(UInt16), 0);
	screenRect.topLeft.x = 0;
	screenRect.topLeft.y = 0;
	screenRect.extent.x = screenWidth;
	screenRect.extent.y = screenHeight;
	
	prevcs = WinSetCoordinateSystem(kCoordinatesNative);
	WinScreenMode(winScreenModeSet,NULL,NULL,&new_hd_depth,NULL);
	//oldDrawWinH = WinGetDrawWindow();
	//OffScreenH = WinCreateOffscreenWindow(screenWidth,screenHeight, nativeFormat, &error);
	//screenBufferP=(UInt16 *)BmpGetBits(WinGetBitmap(OffScreenH));
	//OffFrameH = WinCreateOffscreenWindow(screenWidth,screenHeight, nativeFormat, &error);
	//frameBufferP=(UInt16 *)BmpGetBits(WinGetBitmap(OffFrameH));

	WinSetForeColorRGB(&black,NULL);
	WinPaintRectangle(&screenRect,0);

    // One goal of the game should be to display something as soon as possible.  If starting
    // the game or loading the graphics takes a noticeable time, it's probably good to display
    // a splash screen first.  This makes the app feel responsive.


	HostMaskKeys();




    
    // Do a frame rate of 33 fps.
    cycleDurationTime = SysTicksPerSecond() / 33;
    
    
    //TwDeviceOpen(&GameApp.rumblerH, "vibrator0", "w");
    
    

    
    // Allocate a screen buffer one tile larger in both directions. 
    // Scrolling can cause part of the tiles on opposite ends to be 
    // visible at once.  Clipping is done when copying from the 
    // screen buffer to the screen.
    cycleNextTime = TimGetTicks() + cycleDurationTime;
    //query_heap_free();
    //if program initialization failed, then return with 0
	//if(!OffScreenH || !OffFrameH ) return(0);

	main();
	
	MameAppStop();
	
    return errNone;                 // no error
    
}


/*! \brief Cleanup the app by releasing and restoring all resources.

Frees the screen buffer.  Releases all graphics.  Restores the keys.
Closes all open forms.
*/
static void MameAppStop()
{
	EventType event;
	// Saving isn't implemented, but this is where it would be done.
	// Save the game automatically and restore to where the player left
	// off when the app returns.  The 90% case when starting the app
	// is to resume, using the Main menu is maybe the 10% case, so optimize
	// accordingly.
    //game_delete();
    
    //TwDeviceClose(GameApp.rumblerH);
    
    // Restore the keys. 
    //HostUnmaskKeys();

    
    
    // Close the library. This frees up the surfaces we loaded too.
#ifdef DEV_BUILD
    TwGfxClose(GFX);
#endif
    
    /*EvtGetEvent(&event,0);
    while(event.eType != nilEvent)
    {
    	EvtGetEvent(&event,0);
    	SysHandleEvent(&event);
    }*/
    EvtFlushKeyQueue();
    EvtResetAutoOffTimer();
    
    FtrUnregister(appFileCreator,1111);
    FtrUnregister(appFileCreator,1112);
    FtrUnregister(appFileCreator,1113);
    FtrUnregister(appFileCreator,1114);
    FtrUnregister(appFileCreator,1115);
    FtrUnregister(appFileCreator,1116);
    
#ifdef DEV_BUILD
	TwAppStop();
#endif

	//WinDeleteWindow(OffScreenH, false);
	//WinDeleteWindow(OffFrameH, false);
	WinSetCoordinateSystem(prevcs);

	
}


    
