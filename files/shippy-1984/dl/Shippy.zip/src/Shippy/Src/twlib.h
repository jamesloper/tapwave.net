
#ifndef h_twlib_h
#define h_twlib_h

#include "endianutils.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DEBUGS(s) debugs(s)
#define DEBUGU8(s) debugu8(s)
#define DEBUGU32(s) debugu32(s)

void debugs ( char *s );
void debugu8 ( unsigned short int x );
void debugu32 ( unsigned int x );
void debugi16 ( int x );

void twlib_init ( void );
void twlib_test ( void ); // just for trying stuff out

void debug_delay ( void );
#ifdef __cplusplus
} // extern "C"
#endif


#endif
