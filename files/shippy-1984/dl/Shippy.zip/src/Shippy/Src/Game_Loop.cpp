/*****************************************************************************
IsoHex18_2.cpp
Ernest S. Pazera
31AUG2000
Start a WIN32 Application Workspace, add in this file
Requires the following libs:
ddraw.lib, dxguid.lib
Requires the following files:
DDFuncs.h.cpp, GDICanvas.h/cpp, IsoMouseMap.h/cpp,
IsoScroller.h/cpp, IsoTilePlotter.h/cpp, IsoTileWalker.h/cpp
TileSet.h/cpp. IsoHexCore.h, IsoHexDefs.h
IsoRenderer.h/cpp
*****************************************************************************/

//////////////////////////////////////////////////////////////////////////////
//INCLUDES
//////////////////////////////////////////////////////////////////////////////
#include <endianUtils.h>
#include <stdlib.h>
//#include <PNOInlineNewDelete.h>
#include "SoundManager.h"


//////////////////////////////////////////////////////////////////////////////
//DEFINES
//////////////////////////////////////////////////////////////////////////////
//Zodiac defines
#define zJoyUP 0x00010002
#define zJoyRT 0x00080010
#define zJoyDN 0x00020004
#define zJoyLT 0x00040008
#define zJoyCT 0x00100000
#define tLT 0x04000000
#define tRT 0x08000000
#define zActUP 0x10000002
#define zActRT 0x20000040
#define zActDN 0x40000004
#define zActLT 0x80000020
#define bFC 0x00008000
#define bLaunch 0x00800000
#define zPower  0x00000001


RECT sRECT;
//////////////////////////////////////////////////////////////////////////////
//PROTOTYPES
//////////////////////////////////////////////////////////////////////////////
bool Prog_Init();//game data initalizer
void Prog_Loop();//main game loop
void Prog_Done();//game clean up
int CallScriptFunction();


//////////////////////////////////////////////////////////////////////////////
//GLOBALS
//////////////////////////////////////////////////////////////////////////////
CGDICanvas lpdd;
static RGBColorType black = {0,0,0,0};
int iDirectionIndex;
int iIntroIndex;	//Intro script ref



//start game customization -- Mobs (Monster Objects)
CCharacter *Mobs[64];

//game state
int iGameState=GS_IDLE;
//tilesets
CTileSet tsBack;//background
CTileSet tsTree;//tree foreground
CTileSet tsUnit;//unit


//isohexcore components
CTilePlotter TilePlotter;//plotter
CTileWalker TileWalker;//walker
CScroller Scroller;//scroller
CMouseMap MouseMap;//mousemap
CRenderer Renderer;//renderer
CPathFinder PathFinder;
CMessageBox MessageBox;
POINT ptScroll={0,0};//keep track of how quickly we scroll

//keep track of unit location
POINT ptUnit;//current position of the unit
POINT ptUnitOld;//last position of the unit
ISODIRECTION idMoveUnit;//direction of movement
//unit offset
POINT ptUnitOffset;
int iUnitFrame=0;

//currently selected tile
int TileSelected=0;
static int playerAnim=0;



//map location structure
/*struct MapLocation
{
	bool bTree;//false=no tree; true=tree
	bool bUnit;//false=no unit; true=unit;
};*/

MapLocation mlMap[MAPWIDTH][MAPHEIGHT] = {0};//map array

//rendering functionprototype
void RenderFunc(void *lpddsDst,RECT* rcClip,int xDst,int yDst,int xMap,int yMap);

Boolean HandleEvent(EventPtr event)
{

	Boolean SafeToHandle = false;
	
	event->eType = (eventsEnum)ByteSwap16(event->eType);
	event->screenX = (Int16)ByteSwap16(event->screenX);
	event->screenY = (Int16)ByteSwap16(event->screenY);
	
	if (event->eType == penUpEvent)
	{
		event->data.penUp.start.x = ByteSwap16(event->data.penUp.start.x);
		event->data.penUp.start.y = ByteSwap16(event->data.penUp.start.y);
		event->data.penUp.end.x = ByteSwap16(event->data.penUp.end.x);
		event->data.penUp.end.y = ByteSwap16(event->data.penUp.end.y);
		SafeToHandle = true;
	}

	// testing and debug code
/*	char temp[20]="";
	StrIToA(temp,event->eType);
	WinDrawChars(temp, sizeof(temp),0,0);
*/
 	
 	if (SafeToHandle)	
 	{
 		SysHandleEvent(event);
 		return false; //Stupid system isn't sending back simple penups.
 	}
 	else
 		return false;


}

//////////////////////////////////////////////////////////////////////////////
//WINDOWPROC
//////////////////////////////////////////////////////////////////////////////
Boolean ProcessEvent()
{
	POINT ptTemp, ptEnd;
	Int16 penx, peny;
	Boolean pDown;

	//which message did we get?
	//EventType event;
	//EvtGetEvent(&event,0);
	//if (!HandleEvent(&event))
	//{


		//event.eType = (eventsEnum)ByteSwap16(event.eType);
		//which message did we get?
		//switch(event.eType)
		//{
		//	case penUpEvent:
		//	{
			EvtFlushPenQueue();
			if (iGameState == GS_IDLE)
			{
				EvtGetPenNative(OffScreenH,&penx, &peny,&pDown);
				
				if (pDown)
				{
					ptTemp.x = penx;
					ptTemp.y = peny;
					
					if (penx < 0 || penx > screenWidth ||
						peny < 0 || peny > screenHeight)
							return true;
					
					ptEnd = MouseMap.MapMouse(ptTemp);
					PathFinder.Calc_Offsets(ptUnit,ptEnd);
					PathFinder.FindPath();
					
					//Test scaffolding
					POINT start, end;
					start.x = -20;
					start.y = -50;
					end.x = 50;
					end.y = 50;
					MessageBox.SetBoxFade(start, 0,128, 5, 4000);
					MessageBox.SetBoxSlide(start, end, 5, 5);
					MessageBox.ShowMessage("Oh no!\nTrouble at the mill!");
					//End TEST
				}
				
				if (!KeyCurrentState())
					return true;
				else 
				{
					//CallEvent();
					return false;
				}
					
			}
			/*}
		
			case keyDownEvent:
			{
				UInt16 chr = ByteSwap16(event.data.keyDown.chr);  //This SHOULD be keydown.chr
	 			if (chr == vchrLaunch || chr == vchrHard1)					//but the struct is buggered
					return false;//handled message

				return true;

			}
			break;
		}*/
	//}

	//pass along any other message to default message handler
	return(true);
}

Boolean Script_Event()
{
	int i;
	POINT ptPlot;
	
	for (i=0;i<64;i++)
	{
	
		if (Mobs[i]->Active)
		{
			ptPlot=TilePlotter.PlotTile(Mobs[i]->MobPos);
			ptPlot=Scroller.WorldToScreen(ptPlot);
			if(Scroller.IsScreenCoord(ptPlot))
			{

				int dir = CallScriptFunction();
			
				if (dir == 1)
				{
					if(Mobs[i]->mGameState==GS_IDLE)
					{
						Mobs[i]->MobMoveDir=ISO_NORTH;
						Mobs[i]->mGameState=GS_STARTMOVE;
					}
				}
				else if (dir == 2)
				{
					if(Mobs[i]->mGameState==GS_IDLE)
					{
						Mobs[i]->MobMoveDir=ISO_SOUTH;
						Mobs[i]->mGameState=GS_STARTMOVE;
					}
				}
				else if (dir == 3)
				{
					if(Mobs[i]->mGameState==GS_IDLE)
					{
						Mobs[i]->MobMoveDir=ISO_WEST;
						Mobs[i]->mGameState=GS_STARTMOVE;
					}
				}
				else if (dir == 4)
				{
					if(Mobs[i]->mGameState==GS_IDLE)
					{
						Mobs[i]->MobMoveDir=ISO_EAST;
						Mobs[i]->mGameState=GS_STARTMOVE;
					}
				}
			}
		}
	}
	return true;
}


bool Host_XS_LoadScript(char *scriptname, int &ThreadID, int priority)
{

        int iErrorCode;
        
        // Load the demo script

        iErrorCode = XS_LoadScript ( scriptname, ThreadID, priority );
        // Check for an error

        if ( iErrorCode != XS_LOAD_OK )
        {
            // Print the error based on the code

            //printf ( "Error: " );

            switch ( iErrorCode )
            {
                case XS_LOAD_ERROR_FILE_IO:
                    //printf ( "File I/O error" );
                    break;

                case XS_LOAD_ERROR_INVALID_XSE:
                    //printf ( "Invalid .XSE file" );
                    break;

                case XS_LOAD_ERROR_UNSUPPORTED_VERS:
                    //printf ( "Unsupported .XSE version" );
                    break;

                case XS_LOAD_ERROR_OUT_OF_MEMORY:
                    //printf ( "Out of memory" );
                    break;

                case XS_LOAD_ERROR_OUT_OF_THREADS:
                    //printf ( "Out of threads" );
                    break;
            }

            //printf ( ".\n" );
            return false;
        }
       /* else
        {
            // Print a success message

            //printf ( "Script loaded successfully.\n" );
         
        }*/
        //printf ( "\n" );
        return true;

}




int CallScriptFunction()
{

		int dir;
        // Call a script function

        //printf ( "Calling DoStuff () asynchronously:\n" );
        //printf ( "\n" );

        XS_CallScriptFunc ( iDirectionIndex, "GetPlayerAction" );

        // Get the return value and print it

        dir = XS_GetReturnValueAsInt ( iDirectionIndex );
        //printf ( "\nReturn value received from script: %f\n", fPi );
        //printf ( "\n" );
		
		return dir;
}

void Host_RunScripts()
{
            XS_RunScripts ( 50 );

        // Free resources and perform general cleanup

}





//////////////////////////////////////////////////////////////////////////////
//WINMAIN
//////////////////////////////////////////////////////////////////////////////
int WinMain()
{


	//if program initialization failed, then return with 0
	if(!Prog_Init()) return(0);



	//run main game loop
	Prog_Loop();
	xvm_main();
	//clean up program data
	Prog_Done();

	//return the wparam from the WM_QUIT message
	return(0);
}

//////////////////////////////////////////////////////////////////////////////
//INITIALIZATION
//////////////////////////////////////////////////////////////////////////////
void Test_Mobs_init()
{
	int i;
	
	for (i=0;i<64;i++)
	{

		Mobs[i] = new CCharacter;
		Mobs[i]->MobPos.x = SysRandom(0)%MAPWIDTH;
		Mobs[i]->MobPos.y = SysRandom(0)%MAPHEIGHT;
		Mobs[i]->MobPath.SetScroller(&Scroller);
		Mobs[i]->MobPath.SetTileWalker(&TileWalker);
		Mobs[i]->MobPath.SetMouseMap(&MouseMap);
		Mobs[i]->numAnimFrames = 2;
		Mobs[i]->Active = true;
	}
		Mobs[0]->MobTiles.Load(lpdd,"BlueChar.bmp");

		Mobs[0]->MobPos.x = ptUnit.x + 2;
		Mobs[0]->MobPos.y = ptUnit.y + 2;
		
		MessageBox.Load("GrayTextBox.bmp");

}


bool Prog_Init()
{
	//create IDirectDraw object
	//lpdd=LPDD_Create(hWndMain,DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT);

	//load in the mousemap

	MouseMap.Load("MouseMap.bmp");

	//set up the tile plotter
	TilePlotter.SetMapType(ISOMAP_STAGGERED);//diamond mode
	TilePlotter.SetTileSize(MouseMap.GetWidth(),MouseMap.GetHeight());//grab width and height from mousemap

	//set up tile walker to diamond mode
	TileWalker.SetMapType(ISOMAP_STAGGERED);



	//set up screeen space
	RECT rcTemp;
	SetRect(&rcTemp,0,0,screenWidth,screenHeight);
	SetRect(&sRECT,0,0,screenWidth,screenHeight);
	Scroller.SetScreenSpace(&rcTemp);

	//load in tiles and cursor
	tsBack.Load(lpdd,"backgroundts.bmp");
	tsTree.Load(lpdd,"treets.bmp");
	tsUnit.Load(lpdd,"BlueChar.bmp");

	//grab tile extent from tileset
	CopyRect(&rcTemp,&tsBack.GetTileList()[0].rcDstExt);

	//calculate the worldspace
	Scroller.CalcWorldSpace(&TilePlotter,&rcTemp,MAPWIDTH,MAPHEIGHT);

	//calculate the mousemap reference point
	MouseMap.CalcReferencePoint(&TilePlotter,&rcTemp);

	//calculate anchor space
	Scroller.CalcAnchorSpace();

	//set wrap modes for scroller
	Scroller.SetHWrapMode(WRAPMODE_CLIP);
	Scroller.SetVWrapMode(WRAPMODE_CLIP);

	//set scroller anchor to (0,0)
	Scroller.GetAnchor()->x=0;
	Scroller.GetAnchor()->y=0;

	//attach scrolelr and tilewalker to mousemap
	MouseMap.SetScroller(&Scroller);
	MouseMap.SetTileWalker(&TileWalker);

	//set up the map to a random tilefield
	for(int x=0;x<MAPWIDTH;x++)
	{
		for(int y=0;y<MAPHEIGHT;y++)
		{
			mlMap[x][y].bTree=((rand()%3)==1);//random tree
			mlMap[x][y].bUnit=false;//no unit
		}
	}

	
	//calculate the extent rect
	RECT rcExtent;
	CopyRect(&rcExtent,&tsBack.GetTileList()[0].rcDstExt);//set to background extent
	UnionRect(&rcExtent,&rcExtent,&tsTree.GetTileList()[0].rcDstExt);//union with tree extent
	UnionRect(&rcExtent,&rcExtent,&tsUnit.GetTileList()[0].rcDstExt);//union with unit extent

	//set up the renderer
	Renderer.SetBackBuffer(screenBufferP);
	Renderer.SetExtentRect(&rcExtent);
	Renderer.SetFrameBuffer(frameBufferP);
	Renderer.SetMapSize(MAPWIDTH,MAPHEIGHT);
	Renderer.SetMouseMap(&MouseMap);
	Renderer.SetPlotter(&TilePlotter);
	Renderer.SetRenderFunction(RenderFunc);
	Renderer.SetScroller(&Scroller);
	Renderer.SetUpdateRectCount(100);
	Renderer.SetWalker(&TileWalker);
	
	PathFinder.SetScroller(&Scroller);
	PathFinder.SetTileWalker(&TileWalker);
	PathFinder.SetMouseMap(&MouseMap);

	//set the position of the unit
	ptUnit.x=rand()%MAPWIDTH;
	ptUnit.y=rand()%MAPHEIGHT;
	ptUnitOld=ptUnit;//set the old position to the same position
	mlMap[ptUnit.x][ptUnit.y].bUnit=true;//set the unit on the map

	//plot the position of the unit
	POINT ptPos=TilePlotter.PlotTile(ptUnit);

	ptPos.x-=(Scroller.GetScreenSpaceWidth()/2);//center the unit horizontally
	ptPos.y-=(Scroller.GetScreenSpaceHeight()/2);//center the unit vertically


	//set the anchor
	Scroller.SetAnchor(&ptPos);
	Scroller.WrapAnchor();

	//update the entire screenspace
	Renderer.AddRect(Scroller.GetScreenSpace());
	
	XS_Init ();
	Host_XS_LoadScript("script.xse", iDirectionIndex, XS_THREAD_PRIORITY_USER);
    XS_RegisterHostAPIFunc ( XS_GLOBAL_FUNC, "GetRandInRange", HAPI_GetRandInRange );
    XS_StartScript ( iDirectionIndex );

	Test_Mobs_init();
	
	FontInit();

	return(true);//return success
}


void Game_Init()
{

	initSound();
	
//Debugger HATES the soundstream
#ifndef __DEBUG__
	playMusic("stal-rem.xm");
#endif
	Host_XS_LoadScript("intro.xse", iIntroIndex, XS_THREAD_PRIORITY_USER);
    XS_RegisterHostAPIFunc ( XS_GLOBAL_FUNC, "BlitDisplayFromSD", HAPI_BlitDisplayFromSD );
    XS_RegisterHostAPIFunc ( XS_GLOBAL_FUNC, "Wait_Clock", HAPI_Wait_Clock );
    XS_RegisterHostAPIFunc ( XS_GLOBAL_FUNC, "Screen_Transitions", HAPI_Screen_Transitions );
    XS_StartScript ( iIntroIndex );
	XS_CallScriptFunc ( iIntroIndex, "StartIntro" );

	//XS_UnloadScript( iIntroIndex );

}

//////////////////////////////////////////////////////////////////////////////
//CLEANUP
//////////////////////////////////////////////////////////////////////////////
void Prog_Done()
{
	closeSound();
	XS_ShutDown ();
	
	for (int i=0;i<64;i++)
		delete Mobs[i];
	
	FontClose();
}



UInt32 query_heap_free ( void ) {
  UInt16 heapid = 0;
  UInt32 max, bytes;

  MemHeapFreeBytes ( heapid, &bytes, &max );

  //DEBUGS ( "heapfree" );
  //DEBUGU32 ( bytes );

  return ( max );
}

void test_Mob_Loop()
{
	RECT rcUpdate1,rcUpdate2;
	POINT ptTest;
	POINT ptPlot;
	int i;
	for (i=0;i<64;i++)
	{
	
		if (Mobs[i]->Active)
		{
			ptPlot=TilePlotter.PlotTile(Mobs[i]->MobPos);
			ptPlot=Scroller.WorldToScreen(ptPlot);
			if(Scroller.IsScreenCoord(ptPlot))
			{
				switch(Mobs[i]->mGameState)
				{
				
					case GS_STARTMOVE:
					{
						ptTest = TileWalker.TileWalk(Mobs[i]->MobPos,Mobs[i]->MobMoveDir);
						if (mlMap[ptTest.x][ptTest.y].bTree || mlMap[ptTest.x][ptTest.y].bUnit)
						{
							//cancel move, tile is unwalkable
							Mobs[i]->mGameState = GS_IDLE;
						//scroll the frame (0,0)
						//flip to show the back buffer
						break;
						}

						//remove the unit from the old position
						//mlMap[Mobs[i]->MobPosOld.x][Mobs[i]->MobPosOld.y].bMob=false;

						//calculate new position(virtual new position)
						switch(Mobs[i]->MobMoveDir)
						{
						case ISO_NORTH:
						case ISO_NORTHEAST:
						case ISO_NORTHWEST:
						case ISO_WEST:
							{
								//move Mobs[i]->MobPos
								Mobs[i]->MobPos=TileWalker.TileWalk(Mobs[i]->MobPos,Mobs[i]->MobMoveDir);
								//set the offset
								Mobs[i]->MobOffset.x=0;
								Mobs[i]->MobOffset.y=0;
								//place unit at old position
								//mlMap[Mobs[i]->MobPosOld.x][Mobs[i]->MobPosOld.y].bMob=true;
								Mobs[i]->MobMapXY.x = Mobs[i]->MobPosOld.x;
								Mobs[i]->MobMapXY.y = Mobs[i]->MobPosOld.y;


							}break;
						case ISO_EAST:
							{
								//move Mobs[i]->MobPos
								Mobs[i]->MobPos=TileWalker.TileWalk(Mobs[i]->MobPos,Mobs[i]->MobMoveDir);
								//set the offset
								Mobs[i]->MobOffset.x=-64;
								Mobs[i]->MobOffset.y=0;
								//place unit at new position
								//mlMap[Mobs[i]->MobPos.x][Mobs[i]->MobPos.y].bMob=true;
								Mobs[i]->MobMapXY.x = Mobs[i]->MobPos.x;
								Mobs[i]->MobMapXY.y = Mobs[i]->MobPos.y;

							}break;
						case ISO_SOUTHEAST:
							{
								//move Mobs[i]->MobPos
								Mobs[i]->MobPos=TileWalker.TileWalk(Mobs[i]->MobPos,Mobs[i]->MobMoveDir);
								//set the offset
								Mobs[i]->MobOffset.x=-32;
								Mobs[i]->MobOffset.y=-16;
								//place unit at new position
								//mlMap[Mobs[i]->MobPos.x][Mobs[i]->MobPos.y].bMob=true;
								Mobs[i]->MobMapXY.x = Mobs[i]->MobPos.x;
								Mobs[i]->MobMapXY.y = Mobs[i]->MobPos.y;
							}break;
						case ISO_SOUTHWEST:
							{
								//move Mobs[i]->MobPos
								Mobs[i]->MobPos=TileWalker.TileWalk(Mobs[i]->MobPos,Mobs[i]->MobMoveDir);
								//set the offset
								Mobs[i]->MobOffset.x=32;
								Mobs[i]->MobOffset.y=-16;
								//place unit at new position
								//mlMap[Mobs[i]->MobPos.x][Mobs[i]->MobPos.y].bMob=true;
								Mobs[i]->MobMapXY.x = Mobs[i]->MobPos.x;
								Mobs[i]->MobMapXY.y = Mobs[i]->MobPos.y;
							}break;
						case ISO_SOUTH:
							{
								//move Mobs[i]->MobPos
								Mobs[i]->MobPos=TileWalker.TileWalk(Mobs[i]->MobPos,Mobs[i]->MobMoveDir);
								//set the offset
								Mobs[i]->MobOffset.x=0;
								Mobs[i]->MobOffset.y=-32;
								//place unit at new position
								//mlMap[Mobs[i]->MobPos.x][Mobs[i]->MobPos.y].bMob=true;
								Mobs[i]->MobMapXY.x = Mobs[i]->MobPos.x;
								Mobs[i]->MobMapXY.y = Mobs[i]->MobPos.y;
							}break;
						}

						//set unit frame to 0
						Mobs[i]->MobUnitFrame=0;

						//set the next gamestate
						Mobs[i]->mGameState=GS_DOMOVE;

					}break;
					
					case GS_DONEMOVE:
					{
						//finish the move, make sure the unit is positioned correctly
						switch(Mobs[i]->MobMoveDir)
						{
							case ISO_NORTH:
							case ISO_NORTHEAST:
							case ISO_NORTHWEST:
							case ISO_WEST:
							{
								//remove from old position
								//mlMap[Mobs[i]->MobPosOld.x][Mobs[i]->MobPosOld.y].bMob=false;
								//place on new position
								//mlMap[Mobs[i]->MobPos.x][Mobs[i]->MobPos.y].bMob=true;
								Mobs[i]->MobMapXY.x = Mobs[i]->MobPos.x;
								Mobs[i]->MobMapXY.y = Mobs[i]->MobPos.y;
							}
							break;
						}
						
						//plot new tile's position
						ptPlot=TilePlotter.PlotTile(Mobs[i]->MobPos);
						ptPlot=Scroller.WorldToScreen(ptPlot);

						//set scrolling to 0,0
						ptScroll.x=0;
						ptScroll.y=0;

						//check for scrolling
						//AK - scrollling is complete


						//scroll the frame
						//Renderer.ScrollFrame(ptScroll.x,ptScroll.y);

						//add update tiles
						Renderer.AddTile(Mobs[i]->MobPosOld.x,Mobs[i]->MobPosOld.y);
						Renderer.AddTile(Mobs[i]->MobPos.x,Mobs[i]->MobPos.y);

						//set Mobs[i]->MobOffset to (0,0)
						Mobs[i]->MobOffset.x=0;
						Mobs[i]->MobOffset.y=0;
						//set the old unit position to the current unit position
						Mobs[i]->MobPosOld=Mobs[i]->MobPos;
						//go to idling gamestate
						Mobs[i]->mGameState=GS_IDLE;

						//update the frame
						//Renderer.UpdateFrame();

						//flip
					}break;
					
					case GS_DOMOVE:
					{
						//set scrolling to 0,0
						
						//move the unit offset
						switch(Mobs[i]->MobMoveDir)
						{
						case ISO_NORTH:
							{
								//change offset
								Mobs[i]->MobOffset.x+=0;
								Mobs[i]->MobOffset.y-=8;
							}break;
						case ISO_NORTHEAST:
							{
								//change offset
								Mobs[i]->MobOffset.x+=8;
								Mobs[i]->MobOffset.y-=4;
							}break;
						case ISO_EAST:
							{
								//change offset
								Mobs[i]->MobOffset.x+=16;
								Mobs[i]->MobOffset.y+=0;
							}break;
						case ISO_SOUTHEAST:
							{
								//change offset
								Mobs[i]->MobOffset.x+=8;
								Mobs[i]->MobOffset.y+=4;
							}break;
						case ISO_SOUTH:
							{
								//change offset
								Mobs[i]->MobOffset.x+=0;
								Mobs[i]->MobOffset.y+=8;
							}break;
						case ISO_SOUTHWEST:
							{
								//change offset
								Mobs[i]->MobOffset.x-=8;
								Mobs[i]->MobOffset.y+=4;
							}break;
						case ISO_WEST:
							{
								//change offset
								Mobs[i]->MobOffset.x-=16;
								Mobs[i]->MobOffset.y+=0;
							}break;
						case ISO_NORTHWEST:
							{
								//change offset
								Mobs[i]->MobOffset.x-=8;
								Mobs[i]->MobOffset.y-=4;
							}break;
						}
						
						Mobs[i]->MobAnim++;

						//grab the update RECTs
						CopyRect(&rcUpdate1,&Renderer.rcExtent);
						CopyRect(&rcUpdate2,&Renderer.rcExtent);

						//plot the position of the units old position
						ptPlot=TilePlotter.PlotTile(Mobs[i]->MobPosOld);
						ptPlot=Scroller.WorldToScreen(ptPlot);
						OffsetRect(&rcUpdate1,ptPlot.x,ptPlot.y);

						//plot the position of the unit's new position
						ptPlot=TilePlotter.PlotTile(Mobs[i]->MobPos);
						ptPlot=Scroller.WorldToScreen(ptPlot);
						OffsetRect(&rcUpdate2,ptPlot.x,ptPlot.y);

						//scroll the frame (0,0)
						//Renderer.ScrollFrame(0,0);
						
								
						//Renderer.ScrollFrame(ptScroll.x,ptScroll.y);

						//add update tiles
						Renderer.AddTile(Mobs[i]->MobPosOld.x,Mobs[i]->MobPosOld.y);
						Renderer.AddTile(Mobs[i]->MobPos.x,Mobs[i]->MobPos.y);


						//merge the two update RECTS
						UnionRect(&rcUpdate1,&rcUpdate1,&rcUpdate2);

						//send update rect to the renderer
						Renderer.AddRect(&rcUpdate1);

						//update the frame
						//Renderer.UpdateFrame();

						//flip to show the back buffer

						//increase the unit frame counter
						Mobs[i]->MobUnitFrame++;

						//check for done with gamestate
						if(Mobs[i]->MobUnitFrame==4)
						{
							//set to the next gamestate
							Mobs[i]->mGameState=GS_DONEMOVE;
						}

					}break;
					
					case GS_IDLE://the game is idling, update the frame, but thats about it.
					{
						if (Mobs[i]->MobPath.iFollowingPath != ISO_INVALID)
							Mobs[i]->MobPath.iFollowingPath = Mobs[i]->MobPath.NextStep();
						
						if (Mobs[i]->MobPath.iFollowingPath != ISO_INVALID)
						{
							Mobs[i]->MobMoveDir=(ISODIRECTION)Mobs[i]->MobPath.iFollowingPath;
							Mobs[i]->mGameState=GS_STARTMOVE;
						}
						//scroll the frame (0,0)
						//Renderer.ScrollFrame(0,0);
						
						//update the frame
						//Renderer.UpdateFrame();
						//flip to show the back buffer
					}break;
				}
			}
		}
	}
	Renderer.ScrollFrame(0,0);
	
	//update the frame
	Renderer.UpdateFrame();


}
void Player_Loop()
{
	RECT rcUpdate1,rcUpdate2;
	POINT ptTest;
	POINT ptPlot;

	switch(iGameState)
	{
	
		case GS_STARTMOVE:
		{
			ptTest = TileWalker.TileWalk(ptUnit,idMoveUnit);
			if (mlMap[ptTest.x][ptTest.y].bTree)
			{
				//cancel move, tile is unwalkable
				iGameState = GS_IDLE;
			//scroll the frame (0,0)
			Renderer.ScrollFrame(0,0);
			
			//update the frame
			Renderer.UpdateFrame();
			//flip to show the back buffer
			break;
			}

			//remove the unit from the old position
			mlMap[ptUnitOld.x][ptUnitOld.y].bUnit=false;

			//calculate new position(virtual new position)
			switch(idMoveUnit)
			{
			case ISO_NORTH:
			case ISO_NORTHEAST:
			case ISO_NORTHWEST:
			case ISO_WEST:
				{
					//move ptUnit
					ptUnit=TileWalker.TileWalk(ptUnit,idMoveUnit);
					//set the offset
					ptUnitOffset.x=0;
					ptUnitOffset.y=0;
					//place unit at old position
					mlMap[ptUnitOld.x][ptUnitOld.y].bUnit=true;
				}break;
			case ISO_EAST:
				{
					//move ptUnit
					ptUnit=TileWalker.TileWalk(ptUnit,idMoveUnit);
					//set the offset
					ptUnitOffset.x=-64;
					ptUnitOffset.y=0;
					//place unit at new position
					mlMap[ptUnit.x][ptUnit.y].bUnit=true;
				}break;
			case ISO_SOUTHEAST:
				{
					//move ptUnit
					ptUnit=TileWalker.TileWalk(ptUnit,idMoveUnit);
					//set the offset
					ptUnitOffset.x=-32;
					ptUnitOffset.y=-16;
					//place unit at new position
					mlMap[ptUnit.x][ptUnit.y].bUnit=true;
				}break;
			case ISO_SOUTHWEST:
				{
					//move ptUnit
					ptUnit=TileWalker.TileWalk(ptUnit,idMoveUnit);
					//set the offset
					ptUnitOffset.x=32;
					ptUnitOffset.y=-16;
					//place unit at new position
					mlMap[ptUnit.x][ptUnit.y].bUnit=true;
				}break;
			case ISO_SOUTH:
				{
					//move ptUnit
					ptUnit=TileWalker.TileWalk(ptUnit,idMoveUnit);
					//set the offset
					ptUnitOffset.x=0;
					ptUnitOffset.y=-32;
					//place unit at new position
					mlMap[ptUnit.x][ptUnit.y].bUnit=true;
				}break;
			}

			//set unit frame to 0
			iUnitFrame=0;

			//set the next gamestate
			iGameState=GS_DOMOVE;

		}break;
		
		case GS_DONEMOVE:
		{
			//finish the move, make sure the unit is positioned correctly
			switch(idMoveUnit)
			{
				case ISO_NORTH:
				case ISO_NORTHEAST:
				case ISO_NORTHWEST:
				case ISO_WEST:
				{
					//remove from old position
					mlMap[ptUnitOld.x][ptUnitOld.y].bUnit=false;
					//place on new position
					mlMap[ptUnit.x][ptUnit.y].bUnit=true;
				}
				break;
			}
			
			//plot new tile's position
			ptPlot=TilePlotter.PlotTile(ptUnit);
			ptPlot=Scroller.WorldToScreen(ptPlot);

			//set scrolling to 0,0
			ptScroll.x=0;
			ptScroll.y=0;

			//check for scrolling
			//AK - scrollling is complete


			//scroll the frame
			Renderer.ScrollFrame(ptScroll.x,ptScroll.y);

			//add update tiles
			Renderer.AddTile(ptUnitOld.x,ptUnitOld.y);
			Renderer.AddTile(ptUnit.x,ptUnit.y);

			//set ptUnitOffset to (0,0)
			ptUnitOffset.x=0;
			ptUnitOffset.y=0;
			//set the old unit position to the current unit position
			ptUnitOld=ptUnit;
			//go to idling gamestate
			iGameState=GS_IDLE;

			//update the frame
			Renderer.UpdateFrame();

			//flip
		}break;
		
		case GS_DOMOVE:
		{
			//set scrolling to 0,0
			ptScroll.x=0;
			ptScroll.y=0;
			
			//move the unit offset
			switch(idMoveUnit)
			{
			case ISO_NORTH:
				{
					//change offset
					ptUnitOffset.x+=0;
					ptUnitOffset.y-=8;
					ptScroll.y=-8;
				}break;
			case ISO_NORTHEAST:
				{
					//change offset
					ptUnitOffset.x+=8;
					ptUnitOffset.y-=4;
					ptScroll.x = 8;
					ptScroll.y =-4;
				}break;
			case ISO_EAST:
				{
					//change offset
					ptUnitOffset.x+=16;
					ptUnitOffset.y+=0;
					ptScroll.x = 16;
				}break;
			case ISO_SOUTHEAST:
				{
					//change offset
					ptUnitOffset.x+=8;
					ptUnitOffset.y+=4;
					ptScroll.x = 8;
					ptScroll.y = 4;
				}break;
			case ISO_SOUTH:
				{
					//change offset
					ptUnitOffset.x+=0;
					ptUnitOffset.y+=8;
					ptScroll.y = 8;
				}break;
			case ISO_SOUTHWEST:
				{
					//change offset
					ptUnitOffset.x-=8;
					ptUnitOffset.y+=4;
					ptScroll.x =-8;
					ptScroll.y = 4;
				}break;
			case ISO_WEST:
				{
					//change offset
					ptUnitOffset.x-=16;
					ptUnitOffset.y+=0;
					ptScroll.x =-16;
				}break;
			case ISO_NORTHWEST:
				{
					//change offset
					ptUnitOffset.x-=8;
					ptUnitOffset.y-=4;
					ptScroll.x =-8;
					ptScroll.y =-4;
				}break;
			}
			
			playerAnim++;

			//grab the update RECTs
			CopyRect(&rcUpdate1,&Renderer.rcExtent);
			CopyRect(&rcUpdate2,&Renderer.rcExtent);

			//plot the position of the units old position
			ptPlot=TilePlotter.PlotTile(ptUnitOld);
			ptPlot=Scroller.WorldToScreen(ptPlot);
			OffsetRect(&rcUpdate1,ptPlot.x,ptPlot.y);

			//plot the position of the unit's new position
			ptPlot=TilePlotter.PlotTile(ptUnit);
			ptPlot=Scroller.WorldToScreen(ptPlot);
			OffsetRect(&rcUpdate2,ptPlot.x,ptPlot.y);

			//scroll the frame (0,0)
			//Renderer.ScrollFrame(0,0);
			
					
			Renderer.ScrollFrame(ptScroll.x,ptScroll.y);

			//add update tiles
			Renderer.AddTile(ptUnitOld.x,ptUnitOld.y);
			Renderer.AddTile(ptUnit.x,ptUnit.y);


			//merge the two update RECTS
			UnionRect(&rcUpdate1,&rcUpdate1,&rcUpdate2);

			//send update rect to the renderer
			Renderer.AddRect(&rcUpdate1);

			//update the frame
			Renderer.UpdateFrame();

			//flip to show the back buffer

			//increase the unit frame counter
			iUnitFrame++;

			//check for done with gamestate
			if(iUnitFrame==4)
			{
				//set to the next gamestate
				iGameState=GS_DONEMOVE;
			}

		}break;
		
		case GS_IDLE://the game is idling, update the frame, but thats about it.
		{
			if (PathFinder.iFollowingPath != ISO_INVALID)
				PathFinder.iFollowingPath = PathFinder.NextStep();
			
			if (PathFinder.iFollowingPath != ISO_INVALID)
			{
				idMoveUnit=(ISODIRECTION)PathFinder.iFollowingPath;
				iGameState=GS_STARTMOVE;
			}
			//scroll the frame (0,0)
			Renderer.ScrollFrame(0,0);
			
			//update the frame
			Renderer.UpdateFrame();
			//flip to show the back buffer
		}break;
	}


}
//////////////////////////////////////////////////////////////////////////////
//MAIN GAME LOOP
//////////////////////////////////////////////////////////////////////////////
void Prog_Loop()
{
	RectangleType Rect;
	
	Rect.topLeft.x = 0;
	Rect.topLeft.y = 0;
	Rect.extent.x = screenWidth;
	Rect.extent.y = screenHeight;
	
	//Check for input
	while(ProcessEvent())
	//while(Script_Event())
	{
		Script_Event(); //Get Mob move
		test_Mob_Loop(); 
		
		//Flip to show the back buffer
	    //WinCopyRectangle(OffScreenH,oldDrawWinH,&Rect,0,0,winPaint);
		//WinSetDrawWindow(oldDrawWinH);

		Player_Loop();
		
		MessageBox.HandleMessageBoxEvents();
		
		//Flip to show the back buffer
	    WinCopyRectangle(OffScreenH,oldDrawWinH,&Rect,0,0,winPaint);
		WinSetDrawWindow(oldDrawWinH);
		
    // Read the parameters in, backwards
	
	}
}


int GetFacingDir(ISODIRECTION dir, int i)
{
		switch (Mobs[i]->MobMoveDir)
		{
			case ISO_NORTH:
				return 4;
				break;
			case ISO_SOUTH:
				return 0;
				break;
			case ISO_NORTHEAST:
			case ISO_EAST:
			case ISO_SOUTHEAST:
				return 6;
				break;
			case ISO_NORTHWEST:
			case ISO_WEST:
			case ISO_SOUTHWEST:
				return 2;
			
		}

		return 0;
}

void RenderFunc(void *lpddsDst,RECT* rcClip,int xDst,int yDst,int xMap,int yMap)
{
	int i;
	//put background tile
	tsBack.ClipTile(lpddsDst,rcClip,xDst,yDst,0);
	//check for a tree
	if(mlMap[xMap][yMap].bTree)
	{
		//put tree
		tsTree.ClipTile(lpddsDst,rcClip,xDst,yDst,0);
	}
	//check for the unit
	if(mlMap[xMap][yMap].bUnit)
	{
		int playerTile=0;
		//put unit
		switch (idMoveUnit)
		{
			case ISO_NORTH:
				playerTile = 4;
				break;
			case ISO_SOUTH:
				playerTile = 0;
				break;
			case ISO_NORTHEAST:
			case ISO_EAST:
			case ISO_SOUTHEAST:
				playerTile = 6;
				break;
			case ISO_NORTHWEST:
			case ISO_WEST:
			case ISO_SOUTHWEST:
				playerTile = 2;
			
		}
		tsUnit.ClipTile(lpddsDst,rcClip,xDst+ptUnitOffset.x,yDst+ptUnitOffset.y,playerTile + playerAnim%2);

	}
	for (i=0;i<64;i++)
	{
		if (Mobs[i]->MobMapXY.x == xMap && Mobs[i]->MobMapXY.y == yMap)
			Mobs[0]->MobTiles.ClipTile(lpddsDst,rcClip,xDst+Mobs[i]->MobOffset.x,yDst+Mobs[i]->MobOffset.y,GetFacingDir(Mobs[i]->MobMoveDir, i) + Mobs[i]->MobAnim%2);
	}
}
