/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2004 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_PalmEvents.c,v 1.11 2004/11/13 17:38:53 fdie Exp $";
#endif

#include <PalmOS.h>
#include <SysEvent.h>
#include "SDL.h"
#include "SDL_sysevents.h"
#include "SDL_events_c.h"
#include "SDL_PalmVideo.h"
#include "SDL_PalmEvents_c.h"
#include "SDL_PalmKeys.h"

/* The translation table from a Palm keysym to a SDL keysym */
static SDLKey VK_keymap[SDLK_LAST];
//static Uint8 prev_shiftstates[2];

// fdie@ not yet complete

static SDL_keysym *TranslateKey(int scancode, SDL_keysym *keysym)
{
   /* Set the keysym information */
   keysym->scancode = scancode;
   keysym->sym = (scancode < SDL_TABLESIZE(VK_keymap)) ? VK_keymap[scancode] : 0;
   keysym->mod = KMOD_NONE;
   return keysym;
}

/**
 * fdie@
 * When enabled PumpEvents could block the thread for a quite long time
 * in the case of continuous mouse moves.
 * May be that we should define a maximum timeslice for events dispatching.
 * Have to check the SDL policy.
 */
#undef MULTIPLE_EVENTS

void PALM_PumpEvents(_THIS)
{   
   UInt16    err;
   EventType event;
   SDL_keysym keysym;
   int posted;
   struct SDL_PrivateVideoData *pvData = _this->hidden;
   if (pvData == 0) return;

#ifdef MULTIPLE_EVENTS
   do
#endif       
   {
      posted = 0;
      
      //EvtGetEvent(&event, 2);
      if (event.eType == nilEvent) return;
                                                                                                                                                                
      if (SysHandleEvent(&event)) 
      {
#ifdef MULTIPLE_EVENTS
         continue;
#else
         return;
#endif            
      }
      //if (MenuHandleEvent((void *)0, &event, &err)) //AK compiler was being bitchy
      if (0) 
      {
#ifdef MULTIPLE_EVENTS
         continue;
#else
         return;
#endif            
      }
                                                                                                                                                                   
      FrmDispatchEvent(&event);
         
      switch (event.eType)
      {
         case penDownEvent:
			   if (pvData->density > kCoordinatesStandard)
	   		{
	   			Boolean pdown;
				   EvtGetPenNative(WinGetDisplayWindow(), &event.screenX, &event.screenY, &pdown);
	   		}         
            posted += SDL_PrivateMouseButton(SDL_PRESSED, SDL_BUTTON_LEFT, event.screenX, event.screenY);
            break;
            
         case penUpEvent:
			   if (pvData->density > kCoordinatesStandard)
	   		{
	   			Boolean pdown;
				   EvtGetPenNative(WinGetDisplayWindow(), &event.screenX, &event.screenY, &pdown);
	   		}         
            posted += SDL_PrivateMouseButton(SDL_RELEASED, SDL_BUTTON_LEFT, event.screenX, event.screenY);
            break;
   
         case penMoveEvent:           
			   if (pvData->density > kCoordinatesStandard)
	   		{
	   			Boolean pdown;
				   EvtGetPenNative(WinGetDisplayWindow(), &event.screenX, &event.screenY, &pdown);
	   		}         
            posted += SDL_PrivateMouseMotion(0, 0, event.screenX, event.screenY);
            break;
               
         case appStopEvent:
            posted += SDL_PrivateQuit();
            break;

         case keyDownEvent:
             posted += SDL_PrivateKeyboard(SDL_PRESSED, TranslateKey(event.data.keyDown.chr, &keysym));
#ifndef PALM_HARDWARE_KEYBOARD
             posted += SDL_PrivateKeyboard(SDL_RELEASED, TranslateKey(event.data.keyDown.chr, &keysym));
#endif             
             break;
         
         /*case keyUpEvent:
             posted += SDL_PrivateKeyboard(SDL_RELEASED, TranslateKey(event.data.keyUp.chr, &keysym));
             break;*/ //AK compiler complaints again...weird one

         default:
            break;
      }      
   } 
#ifdef MULTIPLE_EVENTS
   while(posted > 0);
#endif      
}

void PALM_InitOSKeymap(_THIS)
{
   int i;

   /* Map the VK keysyms */
   for (i=0; i < SDL_TABLESIZE(VK_keymap); ++i) 
   {
      VK_keymap[i] = SDLK_UNKNOWN;
   }
   
                                                      //-- Standard Unicode 2.0 names for the ascii characters. These exist in
                                                      //-- all of the text fonts, no matter what character encoding is being
                                                      //-- used by PalmOS.
                                                      //   chrNull                    0x0000
                                                      //   chrStartOfHeading          0x0001
                                                      //   chrStartOfText             0x0002
                                                      //   chrEndOfText               0x0003
                                                      //   chrEndOfTransmission       0x0004
                                                      //   chrEnquiry                 0x0005
                                                      //   chrAcknowledge             0x0006
                                                      //   chrBell                    0x0007
   VK_keymap[chrBackspace] = SDLK_BACKSPACE;          //   chrBackspace               0x0008
   VK_keymap[chrHorizontalTabulation] = SDLK_TAB;     //   chrHorizontalTabulation    0x0009
                                                      //   chrLineFeed                0x000A
                                                      //   chrVerticalTabulation      0x000B
                                                      //   chrFormFeed                0x000C
   VK_keymap[chrCarriageReturn] = SDLK_RETURN;        //   chrCarriageReturn          0x000D
                                                      //   chrShiftOut                0x000E
                                                      //   chrShiftIn                 0x000F
                                                      //   chrDataLinkEscape          0x0010
                                                      //   chrDeviceControlOne        0x0011
                                                      //   chrDeviceControlTwo        0x0012
                                                      //   chrDeviceControlThree      0x0013
                                                      //   chrDeviceControlFour       0x0014
                                                      //   chrNegativeAcknowledge     0x0015
                                                      //   chrSynchronousIdle         0x0016
                                                      //   chrEndOfTransmissionBlock  0x0017
                                                      //   chrCancel                  0x0018
                                                      //   chrEndOfMedium             0x0019
                                                      //   chrSubstitute              0x001A
   VK_keymap[chrEscape] = SDLK_ESCAPE;                //   chrEscape                  0x001B
                                                      //   chrFileSeparator           0x001C
                                                      //   chrGroupSeparator          0x001D
                                                      //   chrRecordSeparator         0x001E
                                                      //   chrUnitSeparator           0x001F
   VK_keymap[chrSpace] = SDLK_SPACE;                  //   chrSpace                   0x0020
   VK_keymap[chrExclamationMark] = SDLK_EXCLAIM;      //   chrExclamationMark         0x0021
   VK_keymap[chrQuotationMark] = SDLK_QUOTEDBL;       //   chrQuotationMark           0x0022
   VK_keymap[chrNumberSign] = SDLK_HASH;              //   chrNumberSign              0x0023
   VK_keymap[chrDollarSign] = SDLK_DOLLAR;            //   chrDollarSign              0x0024
                                                      //   chrPercentSign             0x0025
   VK_keymap[chrAmpersand] = SDLK_AMPERSAND;          //   chrAmpersand               0x0026
                                                      //   chrApostrophe              0x0027
   VK_keymap[chrLeftParenthesis] = SDLK_LEFTPAREN;    //   chrLeftParenthesis         0x0028
   VK_keymap[chrRightParenthesis] = SDLK_RIGHTPAREN;  //   chrRightParenthesis        0x0029
   VK_keymap[chrAsterisk] = SDLK_ASTERISK;            //   chrAsterisk                0x002A
   VK_keymap[chrPlusSign] = SDLK_PLUS;                //   chrPlusSign                0x002B
   VK_keymap[chrComma] = SDLK_COMMA;                  //   chrComma                   0x002C
                                                      //   chrHyphenMinus             0x002D
                                                      //   chrFullStop                0x002E
                                                      //   chrSolidus                 0x002F
   for (i = chrDigitZero; i <= chrDigitNine; i++)
   {
      VK_keymap[i] = SDLK_0 - chrDigitZero + i;
   }   
                                                      //   chrDigitZero               0x0030
                                                      //   chrDigitOne                0x0031
                                                      //   chrDigitTwo                0x0032
                                                      //   chrDigitThree              0x0033
                                                      //   chrDigitFour               0x0034
                                                      //   chrDigitFive               0x0035
                                                      //   chrDigitSix                0x0036
                                                      //   chrDigitSeven              0x0037
                                                      //   chrDigitEight              0x0038
                                                      //   chrDigitNine               0x0039
                                                
   VK_keymap[chrColon] = SDLK_COLON;                  //   chrColon                   0x003A
   VK_keymap[chrSemicolon] = SDLK_SEMICOLON;          //   chrSemicolon               0x003B
   VK_keymap[chrLessThanSign] = SDLK_LESS;            //   chrLessThanSign            0x003C
   VK_keymap[chrEqualsSign] = SDLK_EQUALS;            //   chrEqualsSign              0x003D
   VK_keymap[chrGreaterThanSign] = SDLK_GREATER;      //   chrGreaterThanSign         0x003E
   VK_keymap[chrQuestionMark] = SDLK_QUESTION;        //   chrQuestionMark            0x003F
   VK_keymap[chrCommercialAt] = SDLK_AT;              //   chrCommercialAt            0x0040
   
   for (i = chrCapital_A; i <= chrCapital_Z; i++)
   {
      VK_keymap[i] = SDLK_a - 32 - chrCapital_A + i;
   }                                     
                                                      //   chrCapital_A               0x0041
                                                      //   chrCapital_B               0x0042
                                                      //   chrCapital_C               0x0043
                                                      //   chrCapital_D               0x0044
                                                      //   chrCapital_E               0x0045
                                                      //   chrCapital_F               0x0046
                                                      //   chrCapital_G               0x0047
                                                      //   chrCapital_H               0x0048
                                                      //   chrCapital_I               0x0049
                                                      //   chrCapital_J               0x004A
                                                      //   chrCapital_K               0x004B
                                                      //   chrCapital_L               0x004C
                                                      //   chrCapital_M               0x004D
                                                      //   chrCapital_N               0x004E
                                                      //   chrCapital_O               0x004F
                                                      //   chrCapital_P               0x0050
                                                      //   chrCapital_Q               0x0051
                                                      //   chrCapital_R               0x0052
                                                      //   chrCapital_S               0x0053
                                                      //   chrCapital_T               0x0054
                                                      //   chrCapital_U               0x0055
                                                      //   chrCapital_V               0x0056
                                                      //   chrCapital_W               0x0057
                                                      //   chrCapital_X               0x0058
                                                      //   chrCapital_Y               0x0059
                                                      //   chrCapital_Z               0x005A
                                                
   VK_keymap[chrLeftSquareBracket] = SDLK_LEFTBRACKET;   //   chrLeftSquareBracket       0x005B
                                                         // //   chrReverseSolidus       0x005C (not in Japanese fonts)
   VK_keymap[chrRightSquareBracket] = SDLK_RIGHTBRACKET; //   chrRightSquareBracket      0x005D
                                                         //   chrCircumflexAccent        0x005E
                                                         //   chrLowLine                 0x005F
                                                         //   chrGraveAccent             0x0060
   for (i = chrSmall_A; i <= chrSmall_Z; i++)
   {
      VK_keymap[i] = SDLK_a - chrSmall_A + i;
   }                                     
                                                      //   chrSmall_A                 0x0061
                                                      //   chrSmall_B                 0x0062
                                                      //   chrSmall_C                 0x0063
                                                      //   chrSmall_D                 0x0064
                                                      //   chrSmall_E                 0x0065
                                                      //   chrSmall_F                 0x0066
                                                      //   chrSmall_G                 0x0067
                                                      //   chrSmall_H                 0x0068
                                                      //   chrSmall_I                 0x0069
                                                      //   chrSmall_J                 0x006A
                                                      //   chrSmall_K                 0x006B
                                                      //   chrSmall_L                 0x006C
                                                      //   chrSmall_M                 0x006D
                                                      //   chrSmall_N                 0x006E
                                                      //   chrSmall_O                 0x006F
                                                      //   chrSmall_P                 0x0070
                                                      //   chrSmall_Q                 0x0071
                                                      //   chrSmall_R                 0x0072
                                                      //   chrSmall_S                 0x0073
                                                      //   chrSmall_T                 0x0074
                                                      //   chrSmall_U                 0x0075
                                                      //   chrSmall_V                 0x0076
                                                      //   chrSmall_W                 0x0077
                                                      //   chrSmall_X                 0x0078
                                                      //   chrSmall_Y                 0x0079
                                                      //   chrSmall_Z                 0x007A
                                                      //   chrLeftCurlyBracket        0x007B
                                                      //   chrVerticalLine            0x007C
                                                      //   chrRightCurlyBracket       0x007D
                                                      //   chrTilde                   0x007E
                                                      //   chrDelete                  0x007F

                                                      //-- Special meanings given to characters by the PalmOS
   VK_keymap[chrTab] = SDLK_TAB;                      //   chrTab                  chrHorizontalTabulation       // 0x0009
   VK_keymap[vchrPageUp] = SDLK_PAGEUP;               //   vchrPageUp              chrVerticalTabulation         // 0x000B
   VK_keymap[vchrPageDown] = SDLK_PAGEDOWN;           //   vchrPageDown            chrFormFeed                // 0x000C
                                                      //   chrOtaSecure            chrDeviceControlFour       // 0x0014
                                                      //   chrOta                  chrNegativeAcknowledge        // 0x0015
                                                      //   chrCommandStroke        chrSynchronousIdle            // 0x0016
                                                      //   chrShortcutStroke       chrEndOfTransmissionBlock     // 0x0017
                                                      //   chrEllipsis             chrCancel                  // 0x0018
                                                      //   chrNumericSpace            chrEndOfMedium             // 0x0019
                                                      //   chrCardIcon             chrSubstitute              // 0x001A   Card Icon glyph, added in PalmOS 4.0
   VK_keymap[chrLeftArrow] = SDLK_LEFT;               //   chrLeftArrow            chrFileSeparator           // 0x001C
   VK_keymap[chrRightArrow] = SDLK_RIGHT;             //   chrRightArrow           chrGroupSeparator          // 0x001D
   VK_keymap[chrUpArrow] = SDLK_UP;                   //   chrUpArrow              chrRecordSeparator            // 0x001E
   VK_keymap[chrDownArrow] = SDLK_DOWN;               //   chrDownArrow            chrUnitSeparator           // 0x001F

//   prev_shiftstates[0] = 0;
//   prev_shiftstates[1] = 0;
}

/*===========================================================================*/
