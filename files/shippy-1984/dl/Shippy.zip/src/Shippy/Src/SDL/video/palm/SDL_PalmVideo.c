/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2004 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_PalmVideo.c,v 1.23 2004/12/06 00:10:36 fdie Exp $";
#endif

#include <PalmOS.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "SDL.h"
#include "SDL_error.h"
#include "SDL_video.h"
#include "SDL_mouse.h"
#include "SDL_sysvideo.h"
#include "SDL_pixels_c.h"
#include "SDL_events_c.h"

#include "SDL_PalmVideo.h"
#include "SDL_PalmEvents_c.h"
#include "SDL_PalmMouse_c.h"

/* Initialization/Query functions */
static int PALM_VideoInit(_THIS, SDL_PixelFormat *vformat);
static SDL_Rect **PALM_ListModes(_THIS, SDL_PixelFormat *format, Uint32 flags);
static SDL_Surface *PALM_SetVideoMode(_THIS, SDL_Surface *current, int width, int height, int bpp, Uint32 flags);
static int PALM_SetColors(_THIS, int firstcolor, int ncolors, SDL_Color *colors);
static void PALM_VideoQuit(_THIS);

/* Hardware surface functions */
static int PALM_AllocHWSurface(_THIS, SDL_Surface *surface);
static int PALM_LockHWSurface(_THIS, SDL_Surface *surface);
static void PALM_UnlockHWSurface(_THIS, SDL_Surface *surface);
static void PALM_FreeHWSurface(_THIS, SDL_Surface *surface);

/* others */
static void PALM_UpdateRects(_THIS, int numrects, SDL_Rect *rects);
static int PALM_Available(void);
static SDL_VideoDevice * PALM_CreateDevice(int devindex);
static void PALM_DeleteDevice(SDL_VideoDevice *device);

/* PALM driver bootstrap functions */

VideoBootStrap PALM_bootstrap = 
{
   "Palm GDI",
   "Palm GDI",
   PALM_Available,
   PALM_CreateDevice
};

#define UNDEFINED_CS 0xFFFF

#if defined PALMOS && defined USE_PALMOS_VIDEO_ALLOC

/**
 * Free video memory.
 */
void videofree(SDL_Surface *surface)
{
   if (surface->bmType != 0)
   {
      BmpDelete(surface->bmType);
   }
   else
   {
      free(surface->pixels);
   }
}

/**
 * Allocate video memory.
 */
char *videomalloc(SDL_Surface *surface)
{
   UInt16 error;
   Coord w = surface->w;
   char *mem = 0;

   // adjust the size to prevent SDL out of bound writes!
   switch (surface->format->BitsPerPixel)
   {
      case 16:
         w = surface->pitch >> 1;
         break;
      case 8:
         w = surface->pitch;
         break;
      case 4:
         w = surface->pitch << 1;
         break;
      case 2:
         w = surface->pitch << 2;
         break;
      case 1:
         w = surface->pitch << 4;
         break;
   }
   
   if (surface->format->BitsPerPixel <= 16)
   {
      surface->bmType = BmpCreate(w, surface->h, surface->format->BitsPerPixel, 0, &error);
      if (surface->bmType != 0 && error == 0)
      {
         mem = (char *)BmpGetBits(surface->bmType);
      }
   }
   
   if (mem == 0)
   {
      // fallback to dynamic storage
      mem = (char *)malloc(surface->h * surface->pitch);
      surface->bmType = 0;
   }
   
   ErrFatalDisplayIf(!mem, "No video mem"); // fdie@ until the VM has a fatalError()
      
   return mem;
}

#endif // defined PALMOS && defined USE_PALMOS_VIDEO_ALLOC

/**
 * Build the list of supported modes.
 * In PalmOS, all supported depth levels are supported in all resolutions.
 */
static SDL_Rect **buildModes(struct SDL_PrivateVideoData *pvData)
{
   Err error;
   SDL_Rect *pRect;
   SDL_Rect **ppRect;
   int numModes = 0;
   UInt16 density;

   /* Count the supported densities, see DensityType at
    * http://www.palmos.com/dev/support/docs/palmos/Bitmap.html#998172
    */

   if (!pvData->densitySupport)
   {
      numModes = 1;
   }
   else
   {
      // For "highres" devices, get all supported densities
      density = 0;
      do
      {
         error = WinGetSupportedDensity(&density);
         if (error || density == 0) break;
         numModes++;
      }
      while (true);
   }
    
   /* allocate a list of modes + 1 for the NULL terminator */
   ppRect = (SDL_Rect **)malloc(sizeof(ppRect[0]) * (1 + numModes));
   if (!ppRect) 
   {
      SDL_OutOfMemory();
      return 0;
   }
   ppRect[numModes--] = 0;  // sentinell;
   
   density = 0;
   do
   {
      Coord cx,cy;
      UInt16 cs;
      
      if (pvData->densitySupport)
      {
         error = WinGetSupportedDensity(&density);
         if (error || density == 0) break;
   
         cs = WinSetCoordinateSystem(density); 
         //WinGetDisplayExtent(&cx,&cy);
         cx = 480;
         cy = 320; //TW constants
         WinSetCoordinateSystem(cs); 
      }
      else
      {
         //WinGetDisplayExtent(&cx,&cy);
         cx = 480;
         cy = 320; //TW constants
         
      }

      /* add a new mode to the list */
      pRect = (SDL_Rect *)malloc(sizeof(SDL_Rect));
      if (!pRect) 
      {
         while (ppRect[++numModes] != 0)
         {
            free(ppRect[numModes]);
         }
         free(ppRect);
         SDL_OutOfMemory();
         return 0;
      }
      pRect->x = 0;
      pRect->y = 0;
      pRect->w = cx;
      pRect->h = cy;
            
      ppRect[numModes--] = pRect;
   }
   while (pvData->densitySupport);
   
   return ppRect;
}  

/*----------------------------------------------------------PALM_CreateDevice-+
|                                                                             |
+----------------------------------------------------------------------------*/
static SDL_VideoDevice * PALM_CreateDevice(int devindex)
{
   SDL_VideoDevice *device;

   /* Initialize all variables that we clean on shutdown */
   device = (SDL_VideoDevice *)malloc(sizeof(SDL_VideoDevice));
   if (device) 
   {
      memset(device, 0, (sizeof *device));
      device->hidden = (struct SDL_PrivateVideoData *)malloc(sizeof(*device->hidden));
      device->gl_data = 0;
   }
   if (device == 0 || device->hidden == 0) 
   {
      SDL_OutOfMemory();
      PALM_DeleteDevice(device);
      return 0;
   }
   memset(device->hidden, 0, (sizeof *device->hidden));

   /* Set the function pointers */
   device->VideoInit = PALM_VideoInit;
   device->ListModes = PALM_ListModes;
   device->SetVideoMode = PALM_SetVideoMode;
   device->CreateYUVOverlay = NULL;
   device->SetColors = PALM_SetColors;
   device->UpdateRects = PALM_UpdateRects;
   device->VideoQuit = PALM_VideoQuit;
   device->AllocHWSurface = PALM_AllocHWSurface;
   device->CheckHWBlit = NULL;
   device->FillHWRect = NULL;
   device->SetHWColorKey = NULL;
   device->SetHWAlpha = NULL;
   device->LockHWSurface = PALM_LockHWSurface;
   device->UnlockHWSurface = PALM_UnlockHWSurface;
   device->FlipHWSurface = NULL;
   device->FreeHWSurface = PALM_FreeHWSurface;
   device->SetCaption = NULL;
   device->SetIcon = NULL;
   device->IconifyWindow = NULL;
   device->GrabInput = NULL;
   device->GetWMInfo = NULL;
   device->InitOSKeymap = PALM_InitOSKeymap;
   device->PumpEvents = PALM_PumpEvents;
   device->free = PALM_DeleteDevice;

   return device;
}

/*----------------------------------------------------------PALM_DeleteDevice-+
|                                                                             |
+----------------------------------------------------------------------------*/
static void PALM_DeleteDevice(SDL_VideoDevice *device)
{
   if (device) 
   {
      if (device->hidden) 
      {
         free(device->hidden);
      }
      free(device);
   }
}

/*-------------------------------------------------------------PALM_Available-+
|                                                                             |
+----------------------------------------------------------------------------*/
static int PALM_Available(void) 
{
   return 1;
}

/**********************************************************************
 * Initialize the native video subsystem, filling 'vformat' with the 
 * "best" display pixel format, returning 0 or -1 if there's an error.
 */
int PALM_VideoInit(_THIS, SDL_PixelFormat *vformat)
{
   Err err;
   UInt32 depth;
   UInt32 version;
   struct SDL_PrivateVideoData *pvData = _this->hidden;

   err = FtrGet(sysFtrCreator, sysFtrNumWinVersion, &version);
   if (!err && version >= 4)
   {
      pvData->densitySupport = true;
   }

#if !SCREEN_DIRECT_ACCESS
   /**
    * Save the current video mode, to restore it when SDL quits.
    */
   pvData->old_density = (pvData->densitySupport) ? WinGetCoordinateSystem() : kCoordinatesStandard;
   err = WinScreenMode(winScreenModeGet, &pvData->old_width, &pvData->old_height, &pvData->old_bpp, 0);
   if (err)
   {
      SDL_SetError("Unable to get the graphics mode");
      ErrFatalDisplayIf(err, "Unable to get the graphics mode"); // fdie@ until the VM has a fatalError()
      return 0;
   }
   pvData->density = (DensityType)pvData->old_density;
#endif
    
   /* 
    * retrieve a field of bits indicating the supported Bits Per Pixel
    */
   err = WinScreenMode(winScreenModeGetSupportedDepths,0,0,&depth,0);
   if (err)
   {
      SDL_SetError("Unable to determine the supported depths");
      return -1;
   }
   
   /*
    * currently, choose the best available
    */
   if (depth & 0x80000000)
   {
      depth = 32;
   }
   else if (depth & 0x8000)
   {
      depth = 16;
      vformat->Rmask = 0x0000F800;  // 5
      vformat->Gmask = 0x000007E0;  // 6
      vformat->Bmask = 0x0000001F;  // 5
   }
   else if (depth & 0x80) 
   {
      depth = 8;
   }
   else if (depth & 0x08) 
   {
      depth = 4;
   }
   else if (depth & 0x2)
   {
      depth = 2;
   }
   else 
   {
      depth = 1;
   }

   /**
    * Build a complete list of available modes.
    */     
   pvData->SDL_modelist = buildModes(pvData);
   
   vformat->BitsPerPixel = depth;
   vformat->BytesPerPixel = depth >> 3;
   if (depth & 7) vformat->BytesPerPixel++;
   
   return 0;
}

/**********************************************************************
 * Reverse the effects VideoInit() -- called if VideoInit() fails
 * or if the application is shutting down the video subsystem.
 */
void PALM_VideoQuit(_THIS)
{
   struct SDL_PrivateVideoData *pvData = _this->hidden;
   if (pvData == 0) return;

#if SCREEN_DIRECT_ACCESS

#else //SCREEN_DIRECT_ACCESS

   WinDeleteWindow(pvData->offScreen, false);

   /**
    * Restore the initial video mode.
    */
   if (pvData->densitySupport)
   {
      WinSetCoordinateSystem(pvData->old_density);
   }
   WinScreenMode(winScreenModeSet, &pvData->old_width, &pvData->old_height, &pvData->old_bpp, 0);
   
#endif //SCREEN_DIRECT_ACCESS

   /* Free the modes list allocated memory */
   if (pvData->SDL_modelist != 0)
   {
		int i;
      for (i=0; pvData->SDL_modelist[i] != 0; ++i) 
      {
         free(pvData->SDL_modelist[i]);
      }
      free(pvData->SDL_modelist);
   }
}

/**********************************************************************
 * Set the requested video mode, returning a surface which will be
 * set to the SDL_VideoSurface.  The width and height will already
 * be verified by ListModes(), and the video subsystem is free to
 * set the mode to a supported bit depth different from the one
 * specified -- the desired bpp will be emulated with a shadow
 * surface if necessary.  If a new mode is returned, this function
 * should take care of cleaning up the current mode.
 */
SDL_Surface * PALM_SetVideoMode(_THIS, SDL_Surface *current, int width, int height,
                                 int bpp, Uint32 flags) 
{
   Err error;
   UInt32 Rmask = 0;
   UInt32 Gmask = 0;
   UInt32 Bmask = 0;
   UInt32 w = width;
   UInt32 h = height;
   UInt32 _bpp = bpp;
   struct SDL_PrivateVideoData *pvData = _this->hidden;

   /**
    * Get the current screen mode.
    */
   error = WinScreenMode(winScreenModeGet, &w, &h, &_bpp, 0);
   if (error)
   {
      SDL_SetError("Unable to get the graphics mode");
      ErrFatalDisplayIf(error, "Unable to get the graphics mode"); // fdie@ until the VM has a fatalError()
      return 0;
   }
   
   // change the screen mode only if required, fails otherwise ?!
   if (width != w || height != h || _bpp != bpp)
   {
      w = width;
      h = height;
      _bpp = bpp;

#if !SCREEN_DIRECT_ACCESS
      if (pvData->densitySupport)
      {
         pvData->density = (DensityType)(72 * (UInt32)width / 160);
         WinSetCoordinateSystem(pvData->density);
      }
#endif

      error = WinScreenMode(winScreenModeSet, &w, &h, &_bpp, 0);
      if (error)
      {
         SDL_SetError("Unable to set the graphics mode");
            ErrFatalDisplayIf(error, "Unable to set the graphics mode"); // fdie@ until the VM has a fatalError()
         return 0;
      }   
   }
   
   if (bpp == 16)
   {
      Rmask = 0x0000F800;  // 5
      Gmask = 0x000007E0;  // 6
      Bmask = 0x0000001F;  // 5
   }

   /* Allocate the new pixel format for the screen */
   if (!SDL_ReallocFormat(current, bpp, Rmask, Gmask, Bmask, 0)) 
   {
      pvData->screenBits = 0;
      SDL_SetError("Couldn't allocate new pixel format for requested mode");
      return 0;
   }

#if SCREEN_DIRECT_ACCESS

   current->flags = (flags | SDL_FULLSCREEN | SDL_HWSURFACE | SDL_PREALLOC);

   /* fdie@ 
    * check if OS < 3.5, have to enable opaque members access mode or displayAddrV20 is unaccessible
    */
   if (0)
   {
      //pvData->screenBuffer = (unsigned char*) pvData->win->displayAddrV20;
   } 
   else 
   {
      pvData->screenBits = (unsigned char*) BmpGetBits(WinGetBitmap(WinGetDrawWindow()));
      //TwGfxLockSurface(pvData->screenBufferH, (void**)&pvData->screenBits);
   }
   
#else //SCREEN_DIRECT_ACCESS

   current->flags = (flags | SDL_FULLSCREEN) & ~(SDL_HWSURFACE & SDL_PREALLOC);

   /*
    * Once we switch to the desired mode, we may delete a previous
    * offScreen window and create a new one in the new mode.
    */
   if (pvData->offScreen != 0)
   {
      WinDeleteWindow(pvData->offScreen, false);
   }
  
	current->bmType = BmpCreate(w, h, _bpp, 0, &error);
   if (current->bmType == 0 || error)
   {
      SDL_SetError("Cannot create offScreen bitmap");
      return 0;
   }

	if (pvData->density > kCoordinatesStandard)
	{
	   BitmapTypeV3 *bmTypeV3 = BmpCreateBitmapV3(current->bmType, kDensityDouble, BmpGetBits(current->bmType), 0);
	   if (bmTypeV3 == 0 || error)
	   {
	      SDL_SetError("Cannot create offScreen bitmapV3");
	      return 0;
	   }
	   current->bmType = (BitmapType *)bmTypeV3;
	}

   pvData->screenBits = (UInt8 *)BmpGetBits(current->bmType);
	 
   pvData->offScreen = WinCreateBitmapWindow (current->bmType, &error);
   if (pvData->offScreen == 0 || error)
   {
      SDL_SetError("Cannot create offScreen window");
      return 0;
   }
   
//   ErrFatalDisplayIf(error, "Could Not Create Offscreen Window");

#endif //SCREEN_DIRECT_ACCESS

   pvData->maxWidth = current->w = width;
   pvData->maxHeight = current->h = height;
   current->pitch = current->w * (bpp / 8);
   current->pixels = pvData->screenBits;
   _this->screen = current;

   /* We're done */
   return current;
}

/**********************************************************************
 * Appropriate update function for the current video mode
 */
static void PALM_UpdateRects(_THIS, int numrects, SDL_Rect *rects)
{
/*
 * Not usefull in direct video memory access mode.
 */
#if !SCREEN_DIRECT_ACCESS

   int r;
   struct SDL_PrivateVideoData *pvData = _this->hidden;
   
   /* Render each rectangle in the list */
   for (r =0 ; r < numrects; ++r) 
   {
      int maxX, maxY;
      const SDL_Rect *rect = &rects[r];

      if ((rect->w <= 0) || (rect->h <= 0)) 
      { /* sanity check */
          continue;
      }

      /* Check rects validity, i.e. upper and lower bounds */
      maxX = rect->x + rect->w;
      maxY = rect->y + rect->h;
      if (maxX <= 0 || maxY <= 0) 
      { /* sanity check */
         continue;
      }
      
      {
         RectangleType bounds;
         bounds.topLeft.x = rect->x;
         bounds.topLeft.y = rect->y;
         bounds.extent.x = rect->w;
         bounds.extent.y = rect->h;
		   if (pvData->density > kCoordinatesStandard)
		   {
		      UInt16 cs = WinSetCoordinateSystem(pvData->density);
	         WinCopyRectangle(pvData->offScreen, WinGetDisplayWindow(), &bounds, rect->x, rect->y, winPaint);
		      WinSetCoordinateSystem(cs);
		   }
		   else
		   {
	         WinCopyRectangle(pvData->offScreen, WinGetDisplayWindow(), &bounds, rect->x, rect->y, winPaint);
		   }
		    
      }
   }
#endif  
}

/**********************************************************************
 * List the available video modes for the given pixel format, sorted
 * from largest to smallest.
 */
SDL_Rect **PALM_ListModes(_THIS, SDL_PixelFormat *format, Uint32 flags) 
{
#ifdef SUPPORT_ALL_MODES
   return (SDL_Rect **)-1;
#else

   Err err;
   UInt32 depth;
   struct SDL_PrivateVideoData *pvData = _this->hidden;

   /*
    * Any screen depth is suitable.
    */
   if (format == 0)
   {
      return pvData->SDL_modelist;
   }

   /* 
    * retrieve a field of bits indicating the supported Bits Per Pixel
    */
   err = WinScreenMode(winScreenModeGetSupportedDepths,0,0,&depth,0);
   if (err)
   {
      SDL_SetError("Unable to determine the supported depths");
      return (SDL_Rect **)0;
   }   

   /*
    * Check if the corresponding bit is set.
    */
   if (((depth >> (format->BitsPerPixel - 1)) & 1) != 0)
   {
      return pvData->SDL_modelist;
   }
   return (SDL_Rect **)0;
#endif
}

/**********************************************************************
 * Allocates a surface in video memory
 */
static int PALM_AllocHWSurface(_THIS, SDL_Surface *surface)
{
   return -1;
}

/**********************************************************************
 * Frees a previously allocated video surface
 */
static void PALM_FreeHWSurface(_THIS, SDL_Surface *surface)
{
}

/**********************************************************************
 * Locks a video surface
 */
static int PALM_LockHWSurface(_THIS, SDL_Surface *surface)
{
   return 0;
}

/**********************************************************************
 * Unlocks a video surface
 */
static void PALM_UnlockHWSurface(_THIS, SDL_Surface *surface)
{
}

/**********************************************************************
 * Sets the color entries { firstcolor .. (firstcolor+ncolors-1) }
 * of the physical palette to those in 'colors'. If the device is
 * using a software palette (SDL_HWPALETTE not set), then the
 * changes are reflected in the logical palette of the screen as well.
 * The return value is 1 if all entries could be set properly
 * or 0 otherwise.
 */
int PALM_SetColors(_THIS, int firstcolor, int ncolors, SDL_Color *colors)
{
   int i;
   RGBColorType pal[256];

   if (ncolors < 0 || ncolors > 256)
   {
      SDL_SetError("Palettes with more than 256 colors are not supported");
      return 0;
   }
   for(i = 0; i < ncolors; i++) 
   {
      RGBColorType *entry = &pal[i];
      entry->r = colors[i].r;
      entry->g = colors[i].g;
      entry->b = colors[i].b;      
   }
   WinSetDrawWindow(WinGetDrawWindow());      

   if (WinPalette(winPaletteSet, firstcolor, ncolors, pal) != 0)
   {
      SDL_SetError("Cannot apply palette");
      return 0;
   }

   return 1;
}

/*===========================================================================*/
