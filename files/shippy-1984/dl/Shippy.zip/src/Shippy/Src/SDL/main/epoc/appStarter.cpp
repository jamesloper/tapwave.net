/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002  Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org
*/
/* $Id: appStarter.cpp,v 1.9 2004/11/08 17:22:07 petrus Exp $ */

#include <eikappui.h>
#include <eikapp.h>
#include <eikdoc.h>
#include <f32file.h>
#include <apgtask.h>
#include <eikenv.h>

#if defined __WINS__
#include <eikdll.h>
_LIT(KGlobalSharedName, "Global-0x1020424B");
#endif

const TUid KUidStarterApp = { MY_APPLICATION_UID };
const TUid KUidLaunchees = { 0x1020424B };  // SuperWaba UID

// MY_APPLICATION_XXXX are defined in the application mmp file */

#if defined __WINS__
#define EXEDLL_EXTENSION dll
#else
#define EXEDLL_EXTENSION exe
#endif

// if you enjoy macros, please, be my guest!
#define MAKE_LAUNCHEEFILENAME_1(a, b) MAKE_LAUNCHEEFILENAME_2(a,b)
#if defined(_UNICODE)
#define MAKE_LAUNCHEEFILENAME_2(a, b) L ## #a L ## "." L ## #b
static const TLitC<sizeof(MAKE_LAUNCHEEFILENAME_1(MY_APPLICATION_NAME, EXEDLL_EXTENSION))/2> KLauncheeFileName = {
   sizeof(MAKE_LAUNCHEEFILENAME_1(MY_APPLICATION_NAME, EXEDLL_EXTENSION))/2 - 1,
   MAKE_LAUNCHEEFILENAME_1(MY_APPLICATION_NAME, EXEDLL_EXTENSION)
};
#else
#define MAKE_LAUNCHEEFILENAME_2(a, b) #a "." #b
static const TLitC<sizeof(MAKE_LAUNCHEEFILENAME_1(MY_APPLICATION_NAME, EXEDLL_EXTENSION))> KLauncheeFileName = {
   sizeof(MAKE_LAUNCHEEFILENAME_1(MY_APPLICATION_NAME, EXEDLL_EXTENSION)) - 1,
   MAKE_LAUNCHEEFILENAME_1(MY_APPLICATION_NAME, EXEDLL_EXTENSION)
};
#endif

#define MAKE_LAUNCHEEFILEPATH_1(b) MAKE_LAUNCHEEFILEPATH_2(b)
#if defined(_UNICODE)
#define MAKE_LAUNCHEEFILEPATH_2(b) L ## "\\System\\Apps\\" L ## #b L ## "\\"
static const TLitC<sizeof(MAKE_LAUNCHEEFILEPATH_1(MY_APPLICATION_NAME))/2> KLauncheeFilePath = {
   sizeof(MAKE_LAUNCHEEFILEPATH_1(MY_APPLICATION_NAME))/2 - 1,
   MAKE_LAUNCHEEFILEPATH_1(MY_APPLICATION_NAME)
};
#else
#define MAKE_LAUNCHEEFILEPATH_2(b) "\\System\\Apps\\" #b "\\"
static const TLitC<sizeof(MAKE_LAUNCHEEFILEPATH_1(MY_APPLICATION_NAME))> KLauncheeFilePath = {
   sizeof(MAKE_LAUNCHEEFILEPATH_1(MY_APPLICATION_NAME)) - 1,
   MAKE_LAUNCHEEFILEPATH_1(MY_APPLICATION_NAME)
};
#endif

#ifdef MY_APPLICATION_ARG
  #define MAKE_CMDLINE_1(a, b, c) MAKE_CMDLINE_2(a, b, c)
  #if defined(_UNICODE)
    #define MAKE_CMDLINE_2(a, b, c) L## #a L ## "~" L ## #b L ## "~" L ## #c
    static const TLitC<sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID, MY_APPLICATION_ARG))/2> KCmdLine = {
       sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID, MY_APPLICATION_ARG))/2 - 1,
       MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID, MY_APPLICATION_ARG)
    };
  #else
    #define MAKE_CMDLINE_2(a, b, c) #a "~" #b "~" #c
    static const TLitC<sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID, MY_APPLICATION_ARG))> KCmdLine = {
       sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID, MY_APPLICATION_ARG)) - 1,
       MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID, MY_APPLICATION_ARG)
    };
  #endif
#else
  #define MAKE_CMDLINE_1(a, b) MAKE_CMDLINE_2(a, b)
  #if defined(_UNICODE)
    #define MAKE_CMDLINE_2(a, b) L## #a L ## "~" L ## #b
    static const TLitC<sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID))/2> KCmdLine = {
       sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID))/2 - 1,
       MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID)
    };
  #else
    #define MAKE_CMDLINE_2(a, b) #a "~" #b
    static const TLitC<sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID))> KCmdLine = {
       sizeof(MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID)) - 1,
       MAKE_CMDLINE_1(MY_APPLICATION_NAME, MY_APPLICATION_UID)
    };
  #endif
#endif

#define MAKE_LAUNCHEENAME_1(a, b) MAKE_LAUNCHEENAME_2(a, b)
#if defined(_UNICODE)
#define MAKE_LAUNCHEENAME_2(a, b) L## #a L ## "~" L ## #b
static const TLitC<sizeof(MAKE_LAUNCHEENAME_1(MY_APPLICATION_NAME, MY_APPLICATION_UID))/2> KLauncheeName = {
   sizeof(MAKE_LAUNCHEENAME_1(MY_APPLICATION_NAME, MY_APPLICATION_UID))/2 - 1,
   MAKE_LAUNCHEENAME_1(MY_APPLICATION_NAME, MY_APPLICATION_UID)
};
#else
#define MAKE_LAUNCHEENAME_2(a, b) #a "~" #b
static const TLitC<sizeof(MAKE_LAUNCHEENAME_1(MY_APPLICATION_NAME, MY_APPLICATION_UID))> KLauncheeName = {
   sizeof(MAKE_LAUNCHEENAME_1(MY_APPLICATION_NAME, MY_APPLICATION_UID)) - 1,
   MAKE_LAUNCHEENAME_1(MY_APPLICATION_NAME, MY_APPLICATION_UID)
};
#endif

/*------------------------------------------------------- class StarterAppUi -+
|                                                                             |
+----------------------------------------------------------------------------*/
class StarterAppUi : public CEikAppUi
{
public:
   #if defined __WINS__
   void ConstructL()
   {
      BaseConstructL();
      RChunk chunk;
      TInt cmdLineLen = KCmdLine().Length() * sizeof(TText);

      if (KErrNone == chunk.CreateGlobal(KGlobalSharedName, cmdLineLen + sizeof(TText), cmdLineLen + sizeof(TText))) {
         RSemaphore semReady;
         unsigned char const * src = (unsigned char const *)KCmdLine().Ptr();
         unsigned char * tgt;
         tgt = chunk.Base();
         while (cmdLineLen--) {
            *tgt++ = *src++;
         }
         *((TText *)tgt) = (TText)0;
         if (KErrNone == semReady.CreateGlobal(KGlobalSharedName, 0)) {
            RFs fileServer;            // File server session
            if (KErrNone == fileServer.Connect()) {
               TFindFile fileFinder(fileServer);
               if (KErrNone == fileFinder.FindByDir(KLauncheeFileName, KLauncheeFilePath)) {
                  EikDll::StartExeL(fileFinder.File());
                  fileServer.Close();
                  semReady.Wait();     // wait until done
               }else {
                  fileServer.Close();  // do not collapse with previous one!
               }
            }
            semReady.Close();
         }
         chunk.Close();
      }
   }

   #else
   TInt createProcess(RProcess & server)
   {
      TInt err;
      RFs fileServer; // File server session

      err = fileServer.Connect();
      if (KErrNone == err) {
         TFindFile fileFinder(fileServer);
         err = fileFinder.FindByDir(KLauncheeFileName, KLauncheeFilePath);
         if (err == KErrNone) {
            err = server.Create(
               fileFinder.File(),
               KCmdLine(),
               TUidType(KNullUid, KNullUid, KNullUid),
               EOwnerThread
            );
         }
         fileServer.Close();
      }
      return err;
   }

   void ConstructL()
   {
      RProcess server;
      BaseConstructL();
      if (KErrNone == createProcess(server)) {
         server.Resume();
         server.Close();
      }
   }
   #endif

private:
   void HandleWsEventL(TWsEvent const & ev, CCoeControl * ctrl)
   {
      switch (ev.Type()) {
      case EEventKey:
         if (ev.Key()->iCode == 0xABCD) {
            // the Launchee has ended.
            Exit();
         }
         break;
      case EEventFocusGained:
         // if the launchee exe is running, bring it to foreground
         {
            TApaTaskList taskList(iEikonEnv->WsSession());
            TApaTask launchee = taskList.FindApp(KLauncheeName);
            if (launchee.Exists()) {
               // should I check the AppUid is KUidLaunchees?
               launchee.BringToForeground();
            }
         }
         break;
      default:
         break;
      }
      CEikAppUi::HandleWsEventL(ev, ctrl);
   }
};

/*---------------------------------------------------- class StarterDocument -+
|                                                                             |
+----------------------------------------------------------------------------*/
class StarterDocument : public CEikDocument
{
public:
   StarterDocument(CEikApplication& aApp) : CEikDocument(aApp) {}
private:
   CEikAppUi* CreateAppUiL() {
      return new (ELeave) StarterAppUi;
   }
};

/*------------------------------------------------- class StarterApplication -+
|                                                                             |
+----------------------------------------------------------------------------*/
class StarterApplication : public CEikApplication
{
   CApaDocument* CreateDocumentL() {
      return new (ELeave) StarterDocument(*this);
   }
   TUid AppDllUid() const {
      return KUidStarterApp;
   }
};

/*-------------------------------------------------------------NewApplication-+
|                                                                             |
+----------------------------------------------------------------------------*/
EXPORT_C CApaApplication * NewApplication() {
   return new StarterApplication;
}

/*---------------------------------------------------------------------E32Dll-+
|                                                                             |
+----------------------------------------------------------------------------*/
GLDEF_C TInt E32Dll(TDllReason) {
   return KErrNone;
}

/*===========================================================================*/
