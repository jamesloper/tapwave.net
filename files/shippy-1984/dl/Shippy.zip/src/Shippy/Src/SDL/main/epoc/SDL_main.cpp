/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002  Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org
*/
/* $Id: SDL_main.cpp,v 1.14 2004/11/29 08:28:59 petrus Exp $ */
/*
    SDL_main.cpp
    The Epoc executable startup functions

    Based on Epoc version by Hannu Viitala (hannu.j.viitala@mbnet.fi)
    Rewritten for Symbian UIQ
    Sep. 30th, 2004  Pierre G. Richard (petrus@superwaba.com)
*/

#include <e32std.h>
#include <e32def.h>
#include <e32svr.h>
#include <e32base.h>
#include <estlib.h>
#include <stdlib.h>
#include <stdio.h>
#include <w32std.h>
#include <apgtask.h>

#if defined __WINS__
#include <estw32.h>
_LIT(KGlobalSharedName, "Global-0x1020424B");
#endif

#ifndef EXPORT_C
 #ifdef __VC32__
  #define IMPORT_C __declspec(dllexport)
  #define EXPORT_C __declspec(dllexport)
 #endif
 #ifdef __GCC32__
  #define IMPORT_C
  #define EXPORT_C __declspec(dllexport)
 #endif
#endif

#define main   SDL_main
extern "C" int main (int argc, char *argv[], char *envp[]);
extern "C" void SDL_Quit(void);

static void mainL();
static TInt32 processParams(char *& cmdLine);
static TInt32 hex2int(TDes & src);
static int parseCommandLine(char * cmdline, char ** argv);
static void floatExceptionHandler(TExcType /*type*/);

/*--------------------------------------------------------------------E32Main-+
| Called at startup                                                           |
| - running on the device, either using the appStarter or not                 |
| - running on the emulator; if the appStarter was used, then WinsMain was    |
|   called first.                                                             |
+----------------------------------------------------------------------------*/
GLDEF_C int E32Main()     // when entering directly.
{
   TInt error;
   TTrap trap;
   CTrapCleanup * cleanup = CTrapCleanup::New();
   if (trap.Trap(error)==0) {
      mainL();
      TTrap::UnTrap();
   }
   delete cleanup;
   return error;
}

#ifdef __WINS__
/*-------------------------------------------------------------------WinsMain-+
| called by the appStarter on the Emulator                                    |
+----------------------------------------------------------------------------*/
EXPORT_C TInt WinsMain()  // entering through a starter app on WINS
{
   return E32Main();
}

/*---------------------------------------------------------------------E32Dll-+
| Emulator only: DLL entry point                                              |
+----------------------------------------------------------------------------*/
GLDEF_C TInt E32Dll(TDllReason /*aReason*/) {
   return KErrNone;
}
#endif

/*----------------------------------------------------------------------mainL-+
|                                                                             |
+----------------------------------------------------------------------------*/
static void mainL()
{
   char * cmdLine = 0;
   int argc = 0;
   char ** argv = 0;
   char ** envp = 0;
   TInt32 iUidStarter;

   #if defined __WINS__
   RWin32Stream::StartServer();    // access to stdin/stdout/stderr
   #endif

   SpawnPosixServerThread();       // Posix multi-thread
   _REENT;                         // open stdlib

   iUidStarter = processParams(cmdLine); // set the command line, get the appUid

   if (cmdLine) {                  // called via the starter
      argc = parseCommandLine(cmdLine, 0);  // 1st pass: get the count
      argv = (char **) new (ELeave) char *[argc];
      parseCommandLine(cmdLine, argv);      // 2nd pass: get the data
      argv[1] = argv[0];           // no need for the AppUid:
      ++argv, --argc;              // point at 2nd arg
   }else {
      __crt0(argc, argv, envp);
   }

   /* Start the main (main is #defined as SDL_main) */
   TRAPD(err, main(argc, argv, envp));
   if (cmdLine) {
      delete [] --argv;
      delete [] cmdLine;
   }
   SDL_Quit();                     // harmless, if already done.

   /* clean up and tell starter that we ended */
   CloseSTDLIB();                  // Close stdlib
   if (iUidStarter) {
      RWsSession session;
      if (session.Connect() == KErrNone) {
         TApaTaskList taskList(session);
         TApaTask starter = taskList.FindApp(TUid::Uid(iUidStarter));
         if (starter.Exists()) {
            starter.SendKey(0xABCD, 0);
         }
         session.Close();
      }
   }
}

/*--------------------------------------------------------------processParams-+
| Allocate and set the command line.                                          |
| Return the app uid                                                          |
+----------------------------------------------------------------------------*/
static TInt32 processParams(char *& cmdLine)
{
   TInt32 iUidStarter = 0;
   TText const * ucCmdLine;
   TText const * pc;
   TInt size;

   /* Get the parameter string associated to this SDL app */
   #if defined __WINS__
      RChunk chunkFound;
      RSemaphore semReady;
      TFullName chunkFoundName;
      TFindChunk chunkFinder(KGlobalSharedName);

      if (
         (semReady.OpenGlobal(KGlobalSharedName) != KErrNone) ||
         (chunkFinder.Next(chunkFoundName) != KErrNone) ||
         (chunkFound.Open(chunkFinder) != KErrNone)
      ) {
         return 0;     // unknown
      }
      ucCmdLine = (TText const *)chunkFound.Base();
   #else
      TBuf<300> buf;
      RProcess self;
      self.CommandLine(buf);
      buf.ZeroTerminate();
      ucCmdLine = (TText const *)buf.Ptr();
   #endif

   /* Get the 2nd param: starter Uid */
   for (pc = ucCmdLine; *pc && (*pc != '~'); ++pc);
   if (*pc == '~') ++pc;
   if ((*pc++ == '0') && (*pc++ == 'x')) {
      TBuf<8> temp;
      int i = temp.MaxLength();
      while (i--) {
         if (!*pc || (*pc == '~')) {
            iUidStarter = hex2int(temp);
            break;
         }
         temp.Append(*pc++);
      }
   }

   /* make a multibyte string: this is what SDL_main expects */
   #if defined _UNICODE
      size = wcstombs(0, (wchar_t const *)ucCmdLine, 0);
      cmdLine = new (ELeave) char[size+1];
      wcstombs(cmdLine, (wchar_t const *)ucCmdLine, size);
   #else
      size = strlen(ucCmdLine);
      cmdLine = new (ELeave) char[size+1];
      memcpy(cmdLine, ucCmdLine, size);
   #endif
   cmdLine[size] = 0;

   /* Set the thread sprecs */
   RThread currentThread;
   TBuf<KMaxName> temp;
   temp.Copy(ucCmdLine, pc-ucCmdLine);  // pgmName + '~' + starterUid
   currentThread.Rename(temp);
   currentThread.SetExceptionHandler(floatExceptionHandler, KExceptionFpe);

   /* Under WINS, tell starter we are done at processing the parameters */
   #if defined __WINS__
      chunkFound.Close();
      semReady.Signal();
      semReady.Close();
   #endif

   return iUidStarter;
}

/*--------------------------------------------------------------------hex2int-+
|                                                                             |
+----------------------------------------------------------------------------*/
static TInt32 hex2int(TDes & src)
{
   TInt32 res = 0;
   int count = src.Length();
   int offset = 0;
   TText const * p = src.Ptr();
   if ((count > 0) && (count <= 8)) {
      for (;;) {
         TText c = p[offset++];
         if (c <= '9') {
            if (c < '0') break;
            res += (c & 0xF);
         }else {
            if ((c = (TText)((c & ~('a'-'A'))-'A')) >= (TText)(16-10)) break;
            res += (c + 10);
         }
         if (--count == 0) return res;
         res <<= 4;
      }
   }
   return res;
}

/*-----------------------------------------------------------parseCommandLine-+
| Parse a command line buffer into arguments                                  |
| If argv is null, it just counts the number of arguments.                    |
|                                                                             |
| Warning!  Due to ABLD restritions, the command line cannot have any space,  |
| nor quotes.  These have been replaced (respectfully) by tilda ('~') and     |
| carrets ('^')                                                               |
+----------------------------------------------------------------------------*/
static int parseCommandLine(char * cmdline, char ** argv)
{
   char * bufp = cmdline;
   int argc = 0;
   int isQuoted;

   while (*bufp) {
      while (*bufp == '~') ++bufp;               /* Skip whitespaces */
      isQuoted = *bufp == '^';
      if (isQuoted) ++bufp;
      if (*bufp) {
         if (argv) argv[argc] = bufp;
         ++argc;
      }
      if (isQuoted) {
         while (*bufp && (*bufp != '^')) {       /* Skip over quoted */
            if (argv && (*bufp == '~')) *bufp = ' ';
            ++bufp;
         }
      }else {
         while (*bufp && (*bufp != '~')) ++bufp; /* Skip over word */
      }
      if (*bufp) {
         if (argv) *bufp = '\0';
         ++bufp;
      }
   }
   return argc;
}

/*------------------------------------------------------floatExceptionHandler-+
|                                                                             |
+----------------------------------------------------------------------------*/
static void floatExceptionHandler(TExcType /*type*/)
{
   // do nothing
// switch (type) {
// case EExcFloatDenormal:
//    break;
// case EExcFloatDivideByZero:
//    break;
// case EExcFloatInexactResult:
//    break;
// case EExcFloatInvalidOperation:
//    break;
// case EExcFloatOverflow:
//    break;
// case EExcFloatStackCheck:
//    break;
// case EExcFloatUnderflow:
//    break;
// default:
//    showError(16000 + (int)type);
// }
}

/*===========================================================================*/
