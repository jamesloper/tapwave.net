/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2004 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_PalmVideo.h,v 1.9 2004/11/13 13:05:51 fdie Exp $";
#endif

#ifndef _SDL_PalmVideo_h
#define _SDL_PalmVideo_h

#include "SDL_mouse.h"
#include "SDL_sysvideo.h"
#include "SDL_mutex.h"

#include <PalmOS.h>

/* Hidden "this" pointer for the video functions */
#define _THIS  SDL_VideoDevice *_this

/*
 * SCREEN_DIRECT_ACCESS = 1
 * works for palmOS < 5 non highres devices having linear video memory
 * 
 * SCREEN_DIRECT_ACCESS = 0
 * for newer versions, video memory direct access is NOT recommanded
 */
#define SCREEN_DIRECT_ACCESS 1

/**
 * Supports all resolutions.
 * This mode could be enabled theoritically if we allow all density values between 
 * the canonical One, OneAndAHalf, Double, Triple and Quadruple density values.
 */
#undef SUPPORT_ALL_MODES

/* Private display data -- access to it thru: this->hidden->(field name) */
struct SDL_PrivateVideoData 
{
   SDL_Rect **SDL_modelist;

   /**
    * Cache the initial settings to restore the screen mode when SDL quits.
    */
   UInt32 old_width;
   UInt32 old_height;
   UInt32 old_bpp;
   UInt16 old_density;
   DensityType density;
   Boolean densitySupport;

#if SCREEN_DIRECT_ACCESS
#else
   WinHandle offScreen;
#endif
   int maxWidth;
   int maxHeight;
   //TwGfxSurfaceType *screenBufferH;
   unsigned char *screenBits;
};

#endif
/*===========================================================================*/
