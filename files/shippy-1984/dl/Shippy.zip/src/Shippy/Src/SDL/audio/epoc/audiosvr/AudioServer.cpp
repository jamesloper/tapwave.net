/* $Id: AudioServer.cpp,v 1.13 2004/11/30 09:20:11 petrus Exp $ */

#include "AudioServer.h"
#include <e32svr.h>
#include <e32math.h>
#include <e32uid.h>
#include <mda\common\audio.h>
#include <MdaAudioOutputStream.h>

_LIT(KMsgFlushed, "Audio Flushed");

/*---------------------------------- DEBUG ----------------------------------*/
#ifdef USE_EPOC_DEBUG
#include <flogger.h>

_LIT(SDL_Logdir, "SDL");
_LIT(SDL_Logfile, "debug.log");

static void lprintf(char * fmt, ...)
{
   #if defined _UNICODE
   int len = User::StringLength((TUint8 *)fmt);
   unsigned short * p;
   unsigned short * tmpBuf = new unsigned short [2+len+1];
   p = tmpBuf;
   *(int *)p = len;
   p += 2;
   while (len--) *p++ = (unsigned short)(*(unsigned char *)fmt++);
   *p = 0;
   TDesC & tmpDes = *((TDesC *)tmpBuf);
   #endif

   VA_LIST argl;
   VA_START(argl, fmt);

   RFileLogger::WriteFormat(
      SDL_Logdir,
      SDL_Logfile,
      EFileLoggingModeAppend,
      #if defined _UNICODE
      tmpDes,
      #else
      fmt,
      #endif
      argl
   );
   VA_END(argl);

   #if defined _UNICODE
   delete [] tmpBuf;
   #endif
}
#define EPOC_DEBUG(x) x   // EPOC_DEBUG(lprintf("abc %d", 123));

#else // no debug
#define EPOC_DEBUG(x)
#endif


/*---------------------------------------------------------------------E32Dll-+
| DLL entry point                                                             |
+----------------------------------------------------------------------------*/
GLDEF_C TInt E32Dll(TDllReason /*reason*/)
{
   return KErrNone;
}

/*-------------------------------------------------------- class AudioServer -+
|                                                                             |
+----------------------------------------------------------------------------*/
class AudioServer : public CServer, public MMdaAudioOutputStreamCallback
{
public:
   static TInt startServer(TAny * pSem);
   TInt open(
      TMdaAudioDataSettings::TAudioCaps freq,
      TMdaAudioDataSettings::TAudioCaps channels
   );
   void play(char * buffer);
   void close();

private:
   enum {
      ST_CLOSED,
      ST_OPEN_IN_PROGRESS,
      ST_OPEN_FAILED,
      ST_OPEN_SUCCESSFUL,
      ST_PLAYING,
      ST_PLAY_ENDED
   }m_status;

   static void startServerL(RSemaphore & sem);
   static AudioServer * NewL(RSemaphore & sem);

   AudioServer(RSemaphore & sem);
   virtual ~AudioServer();
   void ConstructL();
   CSharableSession * NewSessionL(TVersion const & version) const;

   CMdaAudioOutputStream * m_sound;
   RSemaphore m_semOpenComplete;
   TMdaAudioDataSettings::TAudioCaps m_freq;
   TMdaAudioDataSettings::TAudioCaps m_channels;
   RSemaphore & m_semBufferAvailable;
   void MaoscPlayComplete(TInt error);
   void MaoscBufferCopied(TInt error, TDesC8 const & buffer);
   void MaoscOpenComplete(TInt error);
};

/*------------------------------------------------------- class AudioSession -+
|                                                                             |
+----------------------------------------------------------------------------*/
class AudioSession : public CSession
{
public:
   static AudioSession * NewL(
      RThread & client,
      AudioServer /*const*/ * server
   );
   virtual ~AudioSession();
   void ServiceL(RMessage const & message);

private:
   AudioServer * m_audioServer; // pointer to owning server
   AudioSession(RThread & client);
   void ConstructL(AudioServer * server);
   void dispatchMessage(RMessage const & message);
   void panicClient(TInt panicCode) const;
};


/*---------------------------------------------------AudioServer::AudioServer-+
|                                                                             |
+----------------------------------------------------------------------------*/
AudioServer::AudioServer(
   RSemaphore & sem
) :
   CServer(
      EPriorityAbsoluteForeground,    /*EPriorityRealTime*/
      ESharableSessions
   ),
   m_semBufferAvailable(sem)
{}

/*---------------------------------------------------------------~AudioServer-+
|                                                                             |
+----------------------------------------------------------------------------*/
AudioServer::~AudioServer()
{
   close();
   m_semOpenComplete.Close();
}

/*----------------------------------------------------------AudioServer::NewL-+
|                                                                             |
+----------------------------------------------------------------------------*/
AudioServer * AudioServer::NewL(RSemaphore & sem)
{
   AudioServer * self = new (ELeave) AudioServer(sem);
   self->m_status = ST_CLOSED;
   CleanupStack::PushL(self);
   self->ConstructL();
   CleanupStack::Pop();
   return self;
}

/*----------------------------------------------------AudioServer::ConstructL-+
|                                                                             |
+----------------------------------------------------------------------------*/
void AudioServer::ConstructL()
{
   User::LeaveIfError(m_semOpenComplete.CreateLocal(0));
   StartL(KAudioServerName);   // start the CServer
}


/*---------------------------------------------------AudioServer::NewSessionL-+
| Create a new client session for this server.                                |
+----------------------------------------------------------------------------*/
CSharableSession * AudioServer::NewSessionL(
   TVersion const & version
) const {
   // check version is ok
   if (!User::QueryVersionSupported(
         TVersion(
            KAudioServerMajorVersionNumber,
            KAudioServerMinorVersionNumber,
            KAudioServerBuildVersionNumber
         ),
         version
      )
   ) {
      User::Leave(KErrNotSupported);  // -5
   }
   // make new session
   RThread client = Message().Client();
   return AudioSession::NewL(client, (AudioServer *)this);
}

/*---------------------------------------------------AudioServer::startServer-+
|                                                                             |
+----------------------------------------------------------------------------*/
TInt AudioServer::startServer(TAny * pSem)
{
   TTrap trap;
   TInt error;
   CTrapCleanup * cleanup = CTrapCleanup::New();
   if (!cleanup) {
      User::Panic(KAudioServerName, KErrNoMemory);  // -4
   }
   if (trap.Trap(error) == 0) {
      startServerL(*(RSemaphore *)pSem);
      TTrap::UnTrap();
   }
   if (error != KErrNone) {
      ((RSemaphore *)pSem)->Signal(10); // signal we started, anyway
      User::Panic(KAudioServerName, error);
   }
   delete cleanup;
   return KErrNone;
}

/*--------------------------------------------------AudioServer::startServerL-+
|                                                                             |
+----------------------------------------------------------------------------*/
void AudioServer::startServerL(RSemaphore & sem)
{
   CServer * server = NULL;

   // construct and install active scheduler
   CActiveScheduler * scheduler = CActiveScheduler::Current();
   if (!scheduler)  {
      scheduler = new (ELeave) CActiveScheduler();
      CleanupStack::PushL(scheduler) ;
      CActiveScheduler::Install(scheduler);
   }

   // construct server, an active object
   server = AudioServer::NewL(sem);
   CleanupStack::PushL(server);

   sem.Signal();                 // signal we started
   CActiveScheduler::Start();    // start the RunL loop

   // arrives here when either the scheduler is stopped, or RunL errored
   User::InfoPrint(KMsgFlushed);   // Debug
   CleanupStack::PopAndDestroy(2); // server, scheduler
}

/*----------------------------------------------------------AudioServer::open-+
|                                                                             |
+----------------------------------------------------------------------------*/
TInt AudioServer::open(
   TMdaAudioDataSettings::TAudioCaps freq,
   TMdaAudioDataSettings::TAudioCaps channels
) {
   if (m_status == ST_CLOSED) {
      TMdaAudioDataSettings waveFmt; /* uninitialized */
      m_freq = freq;
      m_channels = channels;
      m_status = ST_OPEN_IN_PROGRESS;
      m_sound = CMdaAudioOutputStream::NewL(*this);
      m_sound->Open(&waveFmt);
      return KErrNone;
   }else {
      return KErrServerBusy;
   }
}

/*----------------------------------------------------------AudioServer::play-+
|                                                                             |
+----------------------------------------------------------------------------*/
void AudioServer::play(char * data)
{
   if (m_status == ST_OPEN_IN_PROGRESS) {
      m_semOpenComplete.Wait();
   }
   if (m_status == ST_OPEN_SUCCESSFUL) {
      m_status = ST_PLAYING;
   }
   if (m_status == ST_PLAYING) {
      TDesC8 & d = *((TDesC8 *)data);
      if (m_sound) {
         m_sound->WriteL(d);
      }
   }
}

/*---------------------------------------------------------AudioServer::close-+
|                                                                             |
+----------------------------------------------------------------------------*/
void AudioServer::close()
{
   if (m_status != ST_CLOSED) {
      if (m_status == ST_OPEN_IN_PROGRESS) {
         m_semOpenComplete.Wait();
      }
      m_status = ST_CLOSED;
      m_sound->Stop();
      delete m_sound;
      m_sound = 0;
   }
}

/*---------------------------------------------AudioServer::MaoscOpenComplete-+
| When the audio streaming has been opened, so that streaming can begin       |
+----------------------------------------------------------------------------*/
void AudioServer::MaoscOpenComplete(TInt error)
{
   if (error==KErrNone) {
      m_sound->SetAudioPropertiesL(m_freq, m_channels);
      m_sound->SetVolume(m_sound->MaxVolume());
      m_sound->SetPriority(EPriorityMuchMore, EMdaPriorityPreferenceNone);
      m_status = ST_OPEN_SUCCESSFUL;
   }else {
      m_status = ST_OPEN_FAILED;
   }
   m_semOpenComplete.Signal();
   // *(char *)0 = 0;  <== here i might have to do a SDL_Delay(10)
   //                      for the others to realize the open is complete
   //                      (looks like there is a dead-lock in symbian)
}

/*---------------------------------------------AudioServer::MaoscBufferCopied-+
| Each time a descriptor containing sound data has been copied                |
+----------------------------------------------------------------------------*/
void AudioServer::MaoscBufferCopied(
   TInt /*error*/,
   TDesC8 const & buffer
) {
   if (m_status == ST_PLAYING) {
      *((long *)((char *)&buffer - sizeof (long))) = 1;
      m_semBufferAvailable.Signal();
   }
}

/*---------------------------------------------AudioServer::MaoscPlayComplete-+
| When all data has been sent                                                 |
+----------------------------------------------------------------------------*/
void AudioServer::MaoscPlayComplete(TInt error)
{
   EPOC_DEBUG(lprintf("AudioServer 1.12 play complete. RC=%d", error));
   m_status = ST_PLAY_ENDED;
}

/*---------------------------------------------------------AudioSession::NewL-+
|                                                                             |
+----------------------------------------------------------------------------*/
AudioSession* AudioSession::NewL(RThread & client, AudioServer * server)
{
   AudioSession * self = new (ELeave) AudioSession(client);
   CleanupStack::PushL(self);
   self->ConstructL(server);
   CleanupStack::Pop();
   return self;
}

/*-------------------------------------------------AudioSession::AudioSession-+
|                                                                             |
+----------------------------------------------------------------------------*/
AudioSession::AudioSession(RThread & client) : CSession(client)
{
}

/*------------------------------------------------AudioSession::~AudioSession-+
|                                                                             |
+----------------------------------------------------------------------------*/
AudioSession::~AudioSession()
{
   if (m_audioServer) {
      User::Panic(KAudioServerName, KErrServerTerminated); // -15
      // CActiveScheduler::Stop();
   }
}

/*---------------------------------------------------AudioSession::ConstructL-+
| 2nd phase constructor                                                       |
+----------------------------------------------------------------------------*/
void AudioSession::ConstructL(AudioServer * server)
{
   CSession::CreateL(*server);      // construct base class
   m_audioServer = server;
}

/*-----------------------------------------------------AudioSession::ServiceL-+
| Handle messages send by client(s)                                           |
+----------------------------------------------------------------------------*/
void AudioSession::ServiceL(const RMessage & message)
{
   TRAPD(err, dispatchMessage(message));
   message.Complete(err);
}

/*----------------------------------------------AudioSession::dispatchMessage-+
|                                                                             |
+----------------------------------------------------------------------------*/
void AudioSession::dispatchMessage(const RMessage & message)
{
   RMessage const & msg = Message();

   switch (message.Function()) {

   case EAudioServerOpen:
      {
         TPckg<TInt> pkgHandle(
            m_audioServer->open(
              (TMdaAudioDataSettings::TAudioCaps)msg.Int0(), // frequence
              (TMdaAudioDataSettings::TAudioCaps)msg.Int1()  // channels
            )
         );
         WriteL(Message().Ptr2(), pkgHandle);
      }
      break;

   case EAudioServerPlay:
      m_audioServer->play((char *)msg.Ptr0());
      break;

   case EAudioServerClose:
      m_audioServer->close();
      break;

   case EAudioServerQuit:
      CActiveScheduler::Stop();
      m_audioServer = 0;
      break;

   default:
      panicClient(KErrArgument);  // -6
      break;
   }
}

/*--------------------------------------------------AudioSession::panicClient-+
|                                                                             |
+----------------------------------------------------------------------------*/
void AudioSession::panicClient(TInt panicCode) const
{
   _LIT(KTxtAudioServerSess,"AudioSession");
   Panic(KTxtAudioServerSess, panicCode);
}

/*-----------------------------------------------------------startAudioServer-+
| Called by the Client to start the audio server.                             |
+----------------------------------------------------------------------------*/
EXPORT_C TInt startAudioServer(RSemaphore & sem)
{
   TFindServer findAudioServer(KAudioServerName);
   TFullName name;
   RThread thread;
   TInt err;

   // caution!  if a server already exists, kill it.
   if (findAudioServer.Next(name) == KErrNone) {
      TFindThread findThread(KAudioServerName);
      if (
         (err = findThread.Next(name), err != KErrNone) ||
         (err = thread.Open(findThread), err != KErrNone)
      ) {
         User::Panic(KAudioServerName, KErrServerBusy);  // -16
      }else {
   		thread.Kill(0);
  		   thread.Close();
      }
   }

   err=thread.Create(
      KAudioServerName,
      AudioServer::startServer,
      KDefaultStackSize,
      NULL,              // same heap as the caller
      &sem
   );

   if (err == KErrNone) {
      // run the client-side server thread
      thread.SetPriority(EPriorityMuchMore);
      thread.Resume();                // start running
      sem.Wait();                     // wait until done
      if (sem.Count() > 1) {          // set to 10 if an error occurred (now 9)
         err = KErrDied;              // that means our thread died (-13)
      }else {
         #if defined (__WINS__)
         UserSvr::ServerStarted(); // notify kernel that a server has started.
         #endif
      }
   }
   thread.Close();              // clean up
   return err;
}

/*===========================================================================*/
