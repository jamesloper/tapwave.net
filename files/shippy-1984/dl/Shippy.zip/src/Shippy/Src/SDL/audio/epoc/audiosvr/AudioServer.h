/* $Id: AudioServer.h,v 1.4 2004/11/30 08:01:52 petrus Exp $ */

#include <e32base.h>

_LIT(KAudioServerName, "SWAudioServer");

// version
const TUint KAudioServerMajorVersionNumber=1;
const TUint KAudioServerMinorVersionNumber=12;
const TUint KAudioServerBuildVersionNumber=4;

class RSemaphore;

// returns a KErrNone, KErrAlreadyExists, KErrGeneral;
IMPORT_C TInt startAudioServer(RSemaphore & semBufferAvailable);

// request codes
enum TAudioServerRequest
{
   EAudioServerOpen,
   EAudioServerPlay,
   EAudioServerClose,
   EAudioServerQuit
};

/*===========================================================================*/
