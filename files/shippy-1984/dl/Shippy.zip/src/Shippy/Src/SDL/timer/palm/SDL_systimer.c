/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2004 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org

    RDTSC stuff by lompik (lompik@voila.fr) 20/03/2002 
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_systimer.c,v 1.2 2004/10/27 00:03:55 fdie Exp $";
#endif

#include "SDL_error.h"
#include "SDL_timer.h"
#include "SDL_timer_c.h"
#include <PalmOS.h>

// The first ticks value of the application
static UInt32 firstTick;

// Cache the amount of ticks per second to save a function call.
static UInt32 ticksPerSec;

void SDL_StartTicks(void)
{
   ticksPerSec = SysTicksPerSecond();
   firstTick = TimGetTicks();
}

UInt32 SDL_GetTicks (void)
{
   UInt32 ticks;
   
   if (ticksPerSec == 100)
   {
      ticks = (TimGetTicks() - ticksPerSec) * 10; // common case is faster/better
   }
   else
   {
      ticks = ((TimGetTicks() - ticksPerSec) * 1000) / ticksPerSec;
   }

   // NOTE: Timestamp must be in range from 0..(1 << 30)
   return ticks & 0x3FFFFFFF; // documented wrap-around
}

void SDL_Delay (Uint32 ms)
{
   UInt32 start = SDL_GetTicks();

   while (SDL_GetTicks() - start < ms)
   {
      /* Some background tasks required while sleeping can be done here insofar we are not multithreaded */
   } 
}

/* This is only called if the event thread is not running */
int SDL_SYS_TimerInit(void)
{
   return 0;
}

void SDL_SYS_TimerQuit(void)
{
}

int SDL_SYS_StartTimer(void)
{
   return 0;
}

void SDL_SYS_StopTimer(void)
{
}
