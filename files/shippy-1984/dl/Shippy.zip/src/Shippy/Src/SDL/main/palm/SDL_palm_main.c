/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997, 1998, 1999, 2000, 2001, 2002  Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org
*/
/* $Id: SDL_palm_main.c,v 1.2 2004/11/13 03:14:28 fdie Exp $ */
/*
    SDL_main.cpp
    The Epoc executable startup functions

    Based on Epoc version by Hannu Viitala (hannu.j.viitala@mbnet.fi)
    Rewritten for Symbian UIQ
    Sep. 30th, 2004  Pierre G. Richard (petrus@superwaba.com)
*/

#include <TapWave.h>

static int parseCommandLine(char *cmdline, char *argv[]);
extern int main(int argc, char **argv);

#define APPLICATION_LAUNCHCODE   ((UInt32)40404)

UInt32 PilotMain (UInt16 launchCode, MemPtr cmdPBP, UInt16 launchFlags)
{
   MemHandle memH = 0;
   int argc = 0;
   char ** argv = 0;
   int status = 0;
      
   if (launchCode != sysAppLaunchCmdNormalLaunch && launchCode != APPLICATION_LAUNCHCODE &&
         (launchFlags & sysAppLaunchFlagSubCall) == 0)
   {
      return status;
   }
   
   if (cmdPBP) 
   {      
      argc = parseCommandLine(cmdPBP, 0);  // 1st pass: get the count
      if (launchCode == APPLICATION_LAUNCHCODE)
      {
         argc++;
      }
      memH = MemHandleNew(argc * sizeof(char*));
      if (!memH)
      {
         return -1;
      }
      argv = (char **) MemHandleLock(memH);      
      if (launchCode == APPLICATION_LAUNCHCODE)
      {
         argv[0] = "superwaba";
         parseCommandLine(cmdPBP, argv + 1);      // 2nd pass: get the data
      }
      else
      {
         parseCommandLine(cmdPBP, argv);      // 2nd pass: get the data
      }
   }

   /* Start the main (main is #defined as SDL_main) */
   status = main(argc, argv);
   
   if (argv) 
   {
      MemHandleUnlock(memH);      
      MemHandleFree(memH);
   }
   return status;   
}

/*-----------------------------------------------------------parseCommandLine-+
| Parse a command line buffer into arguments                                  |
| If argv is null, it just counts the number of arguments.                    |
+----------------------------------------------------------------------------*/
static int parseCommandLine(char *cmdline, char *argv[]) // fdie@ thx Pierre
{
   char * bufp = cmdline;
   int argc = 0;
   int isQuoted;

   while (*bufp) 
   {
      while (*bufp == ' ') ++bufp;               /* Skip whitespaces */
      isQuoted = *bufp == '"';
      if (isQuoted) ++bufp;
      if (*bufp) 
      {
         if (argv) argv[argc] = bufp;
         ++argc;
      }
      if (isQuoted) 
      {
         while (*bufp && (*bufp != '"')) /* Skip over quoted */
         {       
            if (argv && (*bufp == ' ')) *bufp = ' ';
            ++bufp;
         }
      }
      else 
      {
         while (*bufp && (*bufp != ' ')) ++bufp; /* Skip over word */
      }
      if (*bufp) 
      {
         if (argv) *bufp = '\0';
         ++bufp;
      }
   }
   return argc;
}
