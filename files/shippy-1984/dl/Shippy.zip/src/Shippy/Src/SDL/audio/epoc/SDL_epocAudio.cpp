/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2004 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Sam Lantinga
    slouken@libsdl.org
*/

#ifdef SAVE_RCSID
static char rcsid =
 "@(#) $Id: SDL_epocAudio.cpp,v 1.15 2004/12/06 06:06:23 petrus Exp $";
#endif

/* Allow access to a raw mixing buffer */

#include <e32base.h>
#include <e32std.h>
#include <stdlib.h>
#include <string.h>
#include "SDL_audio.h"
#include "SDL_epocaudio.h"
#include "audiosvr/AudioServer.h"
#include "Mda/Common/Audio.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "SDL_timer.h"
#include "SDL_sysaudio.h"
#include "SDL_audio_c.h"

#define _THIS  SDL_AudioDevice * _this

TUint const maxConcurrentRequests = 5;

/* Initialization/Query functions */
static int EPOC_Available(void);
static SDL_AudioDevice * EPOC_CreateDevice(int devindex);
static void EPOC_DeleteDevice(SDL_AudioDevice * device);

/* Audio driver functions */
static int EPOC_OpenAudio(_THIS, SDL_AudioSpec *spec);
// static void EPOC_ThreadInit(_THIS);
static void EPOC_WaitAudio(_THIS);
static Uint8 *EPOC_GetAudioBuf(_THIS);
static void EPOC_PlayAudio(_THIS);
static void EPOC_WaitDone(_THIS);
static void EPOC_CloseAudio(_THIS);

/* Audio driver bootstrap functions */

AudioBootStrap EPOCAUDIO_bootstrap = {
   "epoc", "Symbian OS 6.1",
   EPOC_Available, EPOC_CreateDevice
};

#ifdef __cplusplus
}
#endif

/*-----------------------------------------------ServerSession::ServerSession-+
|                                                                             |
+----------------------------------------------------------------------------*/
ServerSession::ServerSession(TInt & err)
{
   m_isOpen = 0;
   m_bufIndex = 0;

   err = m_semBufferAvailable.CreateLocal(0);
   if (err == KErrNone) {
      err = startAudioServer(m_semBufferAvailable);
      if (err == KErrNone) {
         err = CreateSession(
            KAudioServerName,
            TVersion(
               KAudioServerMajorVersionNumber,
               KAudioServerMinorVersionNumber,
               KAudioServerBuildVersionNumber
            ),
            maxConcurrentRequests
         );
         if (err == KErrNone) {
            err = Share(EAutoAttach); // so SDL_RunAudio thread can use me
         }
         if (err != KErrNone) {
            RHandleBase::Close();
         }
      }
   }
   m_isCreated = (err == KErrNone);
}

/*----------------------------------------------ServerSession::~ServerSession-+
|                                                                             |
+----------------------------------------------------------------------------*/
ServerSession::~ServerSession()
{
   if (m_isOpen) {
      closeAudio();
   }
   if (m_isCreated) {
      TAny * args[KMaxMessageArguments];
      m_semBufferAvailable.Close();
      SendReceive(EAudioServerQuit, args);
      RHandleBase::Close();
   }
}

/*---------------------------------------------------ServerSession::openAudio-+
|                                                                             |
+----------------------------------------------------------------------------*/
TInt ServerSession::openAudio(SDL_AudioSpec * spec)
{
   TInt err;
   TMdaAudioDataSettings::TAudioCaps freq;
   TMdaAudioDataSettings::TAudioCaps channels;
   int i;
   TAny * args[KMaxMessageArguments];
   TPckgBuf<TInt> pkgbuf;

   if (!m_isCreated) {
      SDL_SetError("unknown session");
      return -1;
   }

   #ifdef __WINS__
   // the emulator is AUDIO_S16MSB - thanks, Symbian folk.
   spec->format = AUDIO_S16MSB;
   #else
   spec->format = AUDIO_S16;
   #endif
   switch (spec->freq) {
   case 8000:
      freq = TMdaAudioDataSettings::ESampleRate8000Hz;
      break;
   case 11025:
      freq = TMdaAudioDataSettings::ESampleRate11025Hz;
      break;
   case 16000:
      freq = TMdaAudioDataSettings::ESampleRate16000Hz;
      break;
   case 22050:
      freq = TMdaAudioDataSettings::ESampleRate22050Hz;
      break;
   case 32000:
      freq = TMdaAudioDataSettings::ESampleRate32000Hz;
      break;
   case 44100:
      freq = TMdaAudioDataSettings::ESampleRate44100Hz;
      break;
   case 48000:
      freq = TMdaAudioDataSettings::ESampleRate48000Hz;
      break;
   default:
      spec->freq = 16000;
      freq = TMdaAudioDataSettings::ESampleRate16000Hz;
      break;
   }

   if (spec->channels == 2) {
      channels = TMdaAudioDataSettings::EChannelsStereo;
   }else {
      channels = TMdaAudioDataSettings::EChannelsMono;
      spec->channels = 1;
   }

   /* Check the buffer size -- minimum of 1/4 second (word aligned) */
   if (spec->samples < (spec->freq/4)) {
      spec->samples = (unsigned short)((spec->freq/4)+3)&~3;
   }
   /* Update the fragment size as size in bytes */
   SDL_CalculateAudioSpec(spec);   //>>>PGR: Is this needed?

   /* Open the Audio Server */
   args[0] = (TAny *)freq;
   args[1] = (TAny *)channels;
   args[2] = (TAny *)&pkgbuf;        /* err return code */
   SendReceive(EAudioServerOpen, args);
   err = pkgbuf();
   if (err != KErrNone) {
      SDL_SetError("Can't open Audio Server");
      return -1;
   }

   /* Create the sound buffers */
   for (i = 0; i < NUM_BUFFERS; ++i) {
      char * p = new char[spec->size + (2 * sizeof (long))];  // 2 * int32
      if (!p) {
         while (i--) {
            delete [] (m_rawBuffers[i]-8);
            m_rawBuffers[i] = 0;
         }
         SendReceive(EAudioServerClose, args);
         SDL_OutOfMemory();
         return -1;
      }
      memset(p, 0x00, spec->size + (2 * sizeof (long))); // silence it
      *((long *)p) = 0;
      *((long *)p + 1) = spec->size;
      m_rawBuffers[i] = p + (2 * sizeof (long));
   }

   m_semBufferAvailable.Signal(NUM_BUFFERS-1);  /* NUM_BUFFERS available */
   m_isOpen = 1;
   m_bufIndex = 0;
   return 0;
}

/*--------------------------------------------------ServerSession::closeAudio-+
|                                                                             |
+----------------------------------------------------------------------------*/
void ServerSession::closeAudio()
{
   if (m_isOpen) {
      TAny * args[KMaxMessageArguments];
      m_isOpen = 0;
      SendReceive(EAudioServerClose, args);
      int i = NUM_BUFFERS;
      while (i--) {
         delete [] (m_rawBuffers[i]- ( 2 * sizeof (long)));
         m_rawBuffers[i] = 0;
      }
   }
}

/*---------------------------------------------------ServerSession::waitAudio-+
| Wait until a buffer is available                                            |
+----------------------------------------------------------------------------*/
void ServerSession::waitAudio()
{
   if (m_isOpen) {
      m_semBufferAvailable.Wait();
   }
}

/*-------------------------------------------------ServerSession::getAudioBuf-+
| Get the available buffer                                                    |
+----------------------------------------------------------------------------*/
Uint8 * ServerSession::getAudioBuf()
{
   /* this only is when waitAudio returned... */
   if (m_isOpen) {
      return (Uint8 *)m_rawBuffers[m_bufIndex];
   }else {
      return 0;
   }
}

/*---------------------------------------------------ServerSession::playAudio-+
| Play the current buffer                                                     |
+----------------------------------------------------------------------------*/
int ServerSession::playAudio()
{
   if (m_isOpen) {
      TAny * args[KMaxMessageArguments];
      args[0] = (TAny *)(m_rawBuffers[m_bufIndex] - sizeof (long)); // TDesc8*
      SendReceive(EAudioServerPlay, args);
      m_bufIndex = (m_bufIndex+1)%NUM_BUFFERS;       // circular
      return 1;
   }else {
      return 0;
   }
}

/*----------------------------------------------------ServerSession::waitDone-+
| Wait until the whole play completes                                         |
+----------------------------------------------------------------------------*/
void ServerSession::waitDone()
{
   for (;;) {
      int left = NUM_BUFFERS;
      for (int i=0; i < NUM_BUFFERS; ++i) {
         if (
            (*((long *)(m_rawBuffers[i] - (2 * sizeof (long)))) != 0) &&
            (--left == 0)
         ) {
            return;
         }
      }
      SDL_Delay(100);
   }
}

/*-------------------------------------------------------------EPOC_Available-+
|                                                                             |
+----------------------------------------------------------------------------*/
static int EPOC_Available(void) {
   return 1; /* Always available */
}

/*----------------------------------------------------------EPOC_CreateDevice-+
|                                                                             |
+----------------------------------------------------------------------------*/
static SDL_AudioDevice * EPOC_CreateDevice(int /*devindex*/)
{
   SDL_AudioDevice * _this;
   TInt err;

   /* Initialize all variables that we clean on shutdown */
   _this = (SDL_AudioDevice *)malloc(sizeof (SDL_AudioDevice));
   if (_this) {
      memset(_this, 0, (sizeof *_this));
      _this->hidden = (struct SDL_PrivateAudioData *) new ServerSession(err);
   }
   if (!_this || !_this->hidden) {
      SDL_OutOfMemory();
      if (_this) {
         free(_this);
      }
      return 0;
   }else if (err != KErrNone) {
      SDL_SetError("Couldn't create audio server session (%d)", err);
      delete (ServerSession *)(_this->hidden);
      free(_this);
      return 0;
   }

   /* Set the function pointers */
   _this->OpenAudio = EPOC_OpenAudio;
   _this->ThreadInit = 0; // EPOC_ThreadInit;
   _this->WaitAudio = EPOC_WaitAudio;
   _this->PlayAudio = EPOC_PlayAudio;
   _this->GetAudioBuf = EPOC_GetAudioBuf;
   _this->WaitDone = EPOC_WaitDone;
   _this->CloseAudio = EPOC_CloseAudio;
   _this->free = EPOC_DeleteDevice;

   return _this;
}

/*----------------------------------------------------------EPOC_DeleteDevice-+
|                                                                             |
+----------------------------------------------------------------------------*/
static void EPOC_DeleteDevice(_THIS)
{
   delete (ServerSession *)(_this->hidden);
   free(_this);
}

/*-------------------------------------------------------------EPOC_OpenAudio-+
|                                                                             |
+----------------------------------------------------------------------------*/
int EPOC_OpenAudio(_THIS, SDL_AudioSpec * spec)
{
   return ((ServerSession *)(_this->hidden))->openAudio(spec);
}

/*------------------------------------------------------------EPOC_CloseAudio-+
|                                                                             |
+----------------------------------------------------------------------------*/
void EPOC_CloseAudio(_THIS)
{
   ((ServerSession *)(_this->hidden))->closeAudio();
}

/*-------------------------------------------------------------EPOC_WaitAudio-+
| Wait until a buffer is available                                            |
+----------------------------------------------------------------------------*/
void EPOC_WaitAudio(_THIS)
{
   ((ServerSession *)(_this->hidden))->waitAudio();
}

/*-----------------------------------------------------------EPOC_GetAudioBuf-+
| Get the available buffer                                                    |
+----------------------------------------------------------------------------*/
Uint8 * EPOC_GetAudioBuf(_THIS)
{
   return ((ServerSession *)(_this->hidden))->getAudioBuf();
}

/*-------------------------------------------------------------EPOC_PlayAudio-+
| Play the current buffer                                                     |
+----------------------------------------------------------------------------*/
void EPOC_PlayAudio(_THIS)
{
   ((ServerSession *)(_this->hidden))->playAudio();
}

/*--------------------------------------------------------------EPOC_WaitDone-+
| Wait until the whole play complete                                          |
+----------------------------------------------------------------------------*/
void EPOC_WaitDone(_THIS)
{
   ((ServerSession *)(_this->hidden))->waitDone();
}

/*===========================================================================*/
