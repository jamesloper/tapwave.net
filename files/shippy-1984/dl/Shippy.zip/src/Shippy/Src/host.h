/*
	File:			host.h

	Description:	Host header file.

	Author:			Roger Flores

	Copyright:		Copyright � 2003 by Tapwave, Inc.

	Disclaimer:		IMPORTANT:  This Tapwave software is provided by Tapwave, Inc. ("Tapwave").  Your 
					use is subject to and governed by terms and conditions of the Software Development 
					Kit Agreement ("SDK Agreement") between you and Tapwave.  If you have not entered 
					into Tapwave�s standard SDK Agreement with Tapwave, you have no right or license 
					to use, reproduce, modify, distribute or otherwise exploit this Tapwave software.  
					You may obtain a copy of Tapwave�s standard SDK Agreement by calling 650-960-1817
					or visiting Tapwave at http://www.tapwave.com/developers/. 

	Change History (most recent first):
				
*/

/* Define how some common types are defined on the
host machine.
*/

#ifndef HOSTPALM_H
#define HOSTPALM_H
#include <PalmOS.h>


typedef signed char int8;
typedef unsigned char uint8;
typedef signed short int16;
typedef unsigned short uint16;
typedef long int32;
typedef unsigned long uint32;
typedef long intptr;
typedef unsigned long uintptr;
typedef unsigned char byte;
#define word UInt16 
#define dword UInt32
// TYPES //////////////////////////////////////////////////

// basic unsigned types
typedef unsigned short USHORT;
typedef unsigned short WORD;
typedef unsigned char  UCHAR;
typedef unsigned char  BYTE;
typedef unsigned int   QUAD;
typedef unsigned int   UINT;
typedef unsigned long	DWORD;

typedef float FLOAT;
typedef long	LONG;
typedef void *	LPVOID;
typedef short SHORT;
typedef struct tagRECT {
   LONG left;
   LONG top;
   LONG right;
   LONG bottom;
} RECT;
typedef struct tagPOINT {
  long x;
  long y;
} POINT;

#ifndef __cplusplus
typedef unsigned char bool;
#endif

#ifndef NULL
#define NULL	0
#endif


// The API to the host functions is C based.
#ifdef __cplusplus
extern "C"
{
#endif



// Define this to run full speed.  Leave undefined to run at a constant 
// frame rate.
#define OPTION_DELAY_NONE 1
#define appFileCreator 'PDsp'


/*
 * UI and graphics for Palm OS software are often edited using the 
 * Constructor tool.  Constructor can be told to describe the UI and
 * graphic resources in a header file.  That header is included here.
 */

//AK defines for getting and setting preferences for driver database
#define appPrefVersionNum	1	//AK Set application prefs version here

#define AppHiScorePrefs		0x01


#define __PALM__

// bridge options going into the pno
#define BF_FULLSCREEN 1
#define BF_AUDIO      2
#define BF_LOWMEM     4
#define BF_ZODIAC     8
#define BF_HIRESPLUS  16
#define BF_PLAYMOD    16
#define BF_STOPMOD    32
#define BF_INITMOD    64
#define BF_FREEMOD    128


//AK - provide defines for WINDOWS port of IsoHex
#define HDC void *
#define LPCTSTR char *
#define COLORREF	UInt16

//#define POINT PointType
//#define rand() SysRandom(0)

// Host provided functions
    extern void HostMaskKeys(void);
    extern void HostUnmaskKeys(void);
	extern Err MameAppStart();
	extern UInt32 *host_event_handler;
	extern UInt32 *host_event;
	extern void *MemGluePtrNewL ( UInt32 foo );
	extern void CallEvent();

	extern WinHandle oldDrawWinH;
	extern WinHandle OffScreenH;
	extern WinHandle OffFrameH;
    //extern TwGfxSurfaceType * pictureBitmapP[ObjectBitmapCount];
    //! These are only used if customBlitting is true.  They cache some of the info on
    //! the pictures that will be used often.  Custom blitting means using 
    //! a custom blitter drawing to a frame buffer, versus using the standard
    //! API calls.
    extern Boolean isInputMasked;
    extern UInt16 soundAmp;            // default sound amplitude
    extern Int32 screenWidth;
    extern Int32 screenHeight;
    extern Int32 screenPitch;
    
	// This is the offscreen buffer which is copied to the screen.
    extern UInt16 * screenBufferP;  // DOLATER - This is really a pointer to the pixels!
    extern UInt16 * frameBufferP;
    //! These are used to get the input.  isInputMasked prevents them
    //! from being set or unset repeatedly.  The padding inserted is
	//! to achieve ARM alignment for these data structures.
	//! NOTE: replace with compiler options when CW9 is avaiable.
    //! Indicates which game menu item is selected.
    //! Controls when the next cycle starts
    extern UInt32 cycleNextTime;
    extern UInt32 cycleDurationTime;

// Game provided functions.
#define game_pause 1
#define game_run 0

extern void HostFastDrawLive(UInt8 *buffer, int x, int y, int width, int height, UInt16 *pal16, int IAdjustBase);
extern Boolean IsZodiac;
extern Char* SafeStrCat ( Char *dst, const Char *src, UInt16 maxLengthWithNull, char *theFile, long theLine );
extern Char* SafeStrCopy (Char* dst, const Char* src, UInt16 maxLengthWithNull, char *theFile, long theLine) ;
extern Char * SafeStrIToA ( Char *s, Int32 i, UInt16 maxLengthWithNull, char *theFile, long theLine );

extern char PALMPREFIXDIR[256];
extern char PALMVFSDIR[23];
extern char PALMOPENDIR[23];



#ifdef __cplusplus
}
#endif

#endif