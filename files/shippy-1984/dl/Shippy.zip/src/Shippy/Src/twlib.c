
#include <PalmOS.h>

#include "host.h"

#include "twlib.h"
//#include "stdfile.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DEBUGLIVE

void debug_delay ( void ) {
#if 1
#ifndef MWCW93
  UInt32 t = TimGetTicks();
  while ( TimGetTicks() - t <= 500 ) {
    //HostDrawBuffer(0, 0, 0, 0, 480, 300);
  }
#endif
#endif

#if 1
#ifdef MWCW93
  UInt32 t = TimGetTicks();
  while ( TimGetTicks() - t <= 500 ) {
    //HostDrawBuffer(0, 0, 0, 0, 480, 300);
  }
#endif
#endif

  return;
}

void debug_delay_always ( void ) {
  UInt32 t = TimGetTicks();
  while ( TimGetTicks() - t <= 50 ) {
    //HostDrawBuffer(0, 0, 0, 0, 480, 300);
  }
}

static void debug_clear ( void ) {
#ifdef DEBUGLIVE
  UInt16 *p = NULL;
  UInt32 x;
  //TwGfxLockSurface ( displaySurface, (void**)&p );
  p += ((UInt32)10*(UInt32)480);
  for ( x = 0; x < (UInt32)480 * (UInt32)40; x++ ) {
    *p++ = 0xFFFF;
  }
  //TwGfxUnlockSurface ( displaySurface, true );
#else
  UInt16 *p = (UInt16*) screenBufferP;
  UInt32 x;
  p += ((UInt32)10*(UInt32)480);
  for ( x = 0; x < (UInt32)480 * (UInt32)40; x++ ) {
    *p++ = 0xFFFF;
  }
#endif
}

void debugs ( char *s ) {
	int num;
  /*if ( s [ 0 ] != 'x' ) {
    return;
  }*/
  if ( s && s [ 0 ] ) {

/*#ifdef DEBUGLIVE
    debug_clear();
    //FontDrawChars( s, StrLen ( s ), displaySurface, 10, 10 );
#else
   // HostOpenScreenBuffer();
    debug_clear();
    //FontDrawChars( s, StrLen ( s ), screenBufferH, 10, 10 );
   // HostCloseScreenBuffer();
    //HostDrawBuffer(0, 0, 0, 0, 480, 300);
#endif*/

#ifdef __DEBUG__
    /* log to VFS too */
    {
      static FILE *df = NULL;
      if ( ! df ) {
	df = fopen ( "_debug.txt", "a" );
	fseek ( df, 0, SEEK_END );
      }
      if ( df ) {
	char nl [ 5 ] = "\n";
	num = fwrite ( s, StrLen ( s ), 1, df );
	//zfwrite ( nl, 1, 1, df );
	fclose ( df );
	df = NULL;
      }
    }
#endif

    //debug_delay();
  }
}

void debugu8 ( unsigned short int x ) {
  char buffer [ 20 ];
  StrPrintF ( buffer, "%d %x", x, x );
  debugs ( buffer );
}

void debugu32 ( unsigned int x ) {
  char buffer [ 20 ];
  StrPrintF ( buffer, "%ld %lx", x, x );
  debugs ( buffer );
}

void debugi16 ( int x ) {
  char buffer [ 20 ];
  StrPrintF ( buffer, "%d ", x );
  debugs ( buffer );
}

void twlib_init ( void ) {
  VFSDirCreate ( palm_vfs_vol(), "/PALM/Programs" );
  VFSDirCreate ( palm_vfs_vol(), PALMVFSDIR );
  return;
}

void twlib_test ( void ) {

#if 0
  FILE *f;
  f = fopen ( "pak0.pak", "rb" );
  if ( f ) {
    DEBUGS ( "1 good" );
    fclose ( f );
  } else {
    DEBUGS ( "2 bad" );
  }
  while(1);
#endif

#if 0 // test files
  FILE *f;

  f = fopen ( "hello.txt", "w" );
  if ( f ) {
    fclose ( f );
  }
  f = fopen ( "hello.txt", "r" );
  if ( f ) {
    DEBUGS ( "1 good" );
    fclose ( f );
  } else {
    DEBUGS ( "2 bad" );
  }
#endif

  return;
}

#ifdef __cplusplus
} // extern "C"
#endif

