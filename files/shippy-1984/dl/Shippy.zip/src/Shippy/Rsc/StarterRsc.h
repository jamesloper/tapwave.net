/* pilrc generated file.  Do not edit!*/
#define RomIncompatibleAlert 9990
#define AboutOKButton 9991
#define AboutForm 9995
#define MainForm 9996
#define MainOptionsAboutStarterApp 9997
#define MainFormMenuBar 9998
