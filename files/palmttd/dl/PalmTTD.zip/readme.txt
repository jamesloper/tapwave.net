PalmTTD
Version: R4451
by SpookySoft in collaboration with eSoft Interactive

**** Note ****  
Be sure to read the Technical Support section of this readme for information on dynamic heap, before running TTD.
**************

[------------------------------------
[---------- Introduction:
[----------
PalmTTD is a port of OpenTTD (www.openttd.org) to PalmOS5. OpenTTD is based on the source code of Chris Sawyer's classic game Transport Tycoon Deluxe. PalmTTD currently runs on PalmOS5, including the Tapwave Zodiac.

[------------------------------------
[---------- History of PalmTTD:
[----------
PalmTTD started out as ZodTTD, a port of OpenTTD to the Tapwave Zodiac handheld. ZodTTD has now been replaced with PalmTTD, while still keeping Zodiac-enhanced features such as music playback.

[------------------------------------
[---------- What's needed to play:
[----------
To run PalmTTD, it is *required* that you install PalmTTD with certain files needed from the original retail Transport Tycoon Deluxe, whether for DOS or Windows. You will also need a PalmOS5 PDA.

**** Note ****  
Be sure to read the Technical Support section of this readme for information on dynamic heap, before running TTD.
**************

[------------------------------------
[---------- How to install:
[----------
There is currently no installer for PalmTTD. It must be installed by hand. Here's how:
1. Copy the following files to the PALM/PROGRAMS/DATA/ directory in this document's folder:
	If you have a Windows version of the original TTD, copy over these files from it:
 		TRG1R.GRF 
 		TRGCR.GRF
 		TRGHR.GRF
 		TRGIR.GRF
 		TRGTR.GRF
		SAMPLE.CAT
	If you have a DOS version of the original TTD, copy over these files from it:
		TRG1.GRF
		TRGI.GRF
		TRGC.GRF
		TRGH.GRF
		TRGT.GRF
		SAMPLE.CAT
2. (Optional) If you have a Tapwave Zodiac and would like to listen to the original TTD's music, read how_to_install_music.txt in the GM\ directory in this documents folder to install music at this point.
3. Copy the PALM directory in this documents folder to the root folder of your storage card you'd like to play PalmTTD on. It most likely already has a PALM directory in it's root folder, it's ok, continue copying.
4. Run PalmTTD from your storage card. :)

[------------------------------------
[---------- Tips for using PalmTTD:
[----------
Windowing system:   PalmTTD features a new way to navigate through the windowing system of TTD. TTD's native resolution of 640x480 is kept intact by allowing you to scroll your Palm's (320x320, 480x320, or 320x480 resolution) screen as just like a viewport of the larger 640x480 screen. This way you can have many windows open, even offscreen! To scroll this viewport, use the stylus to tap the edges of the screen. The viewport will pan over in that direction, showing you that part of the screen. This means no more worries of not being able to reach or view parts of certain large windows.

Right-click emulation:   The "folders" button on the Palm (in the case of the Palm T5 this is the 4th button from the left), can be used to emulate a right-click. Just hold it down and use the stylus to navigate. This is very useful when using the map feature of TTD.

Shift-key emulation:   The "calendar" button on the Palm (in the case of the Palm T5 this is the 2nd button from the left) is able to emulate a shift keypress when pressed.

Scrolling: To scroll the main view use the 4/5-way directional pad on the Palm.

Home button: The "home" button is a shortcut to the window that asks if you would like to exit TTD completely.

Note:  It is normal for the main toolbar and statusbar to be placed slightly away from the edge of the screen and centered horizontally. This placement is due to supporting 3 seperate resolutions.


[------------------------------------
[---------- Technical Support:
[----------
PalmTTD is a very complex game, originating from the PC. Most limitations faced when porting this great game over to the Palm, were fixed. One of them, dynamic heap, is still an issue for some models of the Palm. Dynamic heap represents the amount of memory one application can allocate/use at any one point in time. Some Palm's only allow around 4MB (4096K) of their total RAM to be allocated as dynamic heap. PalmTTD *requires* nearly 8MB (8192K) of dynamic heap to run. The more dynamic heap available, the larger the map sizes that can be used as well. PalmTTD shows how much available heap there is on your Palm on the splash screen. If you have too little dynamic heap and attempt to run PalmTTD, you may receive an error indicating "Out Of Memory" or "Null Handle".

The good news is, there are programs for the Palm that allow use of the full amount of RAM on your Palm as Dynamic Heap. PalmTTD has been tested with the utility UDMH, and it works perfectly. UDMH can be found at: www.dmitrygr.com

We are working on this issue, and hopefully utilities such as UDMH will not be needed on certain Palm models in the future.

Current models known to need such a program are:
Palm T5

Current models known to work WITHOUT such a program are:
Palm T3
Tapwave Zodiac 1/2


[------------------------------------
[---------- Known Bugs:
[----------
1. A low priority "bug" is the reporting of "exiting to Unix" instead of "exiting to Palm" on the exit window. This is kept intact with the original OpenTTD language packs.

[------------------------------------
[---------- If you like PalmTTD:
[----------
1. Please donate...
If you like PalmTTD, which is completely free, please donate any amount of PayPal directly to PalmTTD's author:
heirloomer@pobox.com
(For technical support please visit the eSoft Interactive forums mentioned below)
2. Submit feedback to PalmTTD's official forums at http://www.esoftinteractive.com/forums/

[------------------------------------
Thanks for playing PalmTTD!