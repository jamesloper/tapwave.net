These are the 3 unfinished Zodiac Games that were Leaked recently...

1.Hockey Rage - This is fun, the Blue button changed the camera view (doesnt say that in the controls settings). This is the most complete of the 3 games. There is a readme installation file to help, use this same idea to get Street Hoops installed.

2.Street Hoops - Very early, but had potential. Blue button hits the ball out, then run 
around with it and press buttons to either shoot or dunk it. try dunking it!

3.MTX - simple .exe installer, does it all for you. It's only a 1 level, early
build, no AI, timer or anything really. Just drive around.

Do not place street hoops and hockey rage in the same folder on the
launcher, they make your zodiac crash. And street hoops has to be kept
on the side, not on the main circle wheel of launcher of it changed to
hockey rage!

Have Fun and please post some more Zodiac games in alt.binaries.warez.palmpilot

-Psxfan-