ZodMAME
-------

Ported and Optimised for the Tapwave Zodiac by Fangorn.

This is a port of MAME v0.36 (Multiple Arcade Machine Emulator). It was 
originally based on Vilmos' PalmOS PalmMAME which is itself based on MAMECE. 

ZodMAME is extensively optimised to use the ATI graphics chip to boost the
performance of the games.  It uses pretty much every hardware accelerated
function the ATI Imageon chip has to offer (blit, sprites, line drawing, point
drawing, masking), and the MAME core graphics engine had to be rewritten to
make use of this. Because of this some games will not draw completely
correctly, most appear to work fine though.  The 8MBytes of VRAM in the ATI
chip is used for some of the memory requirements in the games meaning more
games will run but much of this memory is used for caching the graphics.

The optimisations have resulted in some games running up to 2-3 times faster
some will run slower. Vector games benefit from the hardware line drawing
meaning that pretty much all the vector games run at full speed with 44KHz
sound.  Most newer games which are more CPU intensive will not see much of an
increase in speed, there is nothing that can be done about that, the Zodiac
would need a faster CPU.

There is full quality sound support in ZodMAME. Using sound in MAME adds extra
processing requirements so some games which run full speed with sound off will
not with it on. Most older games (1985 or earlier) should run full speed with
perfect sound. There is also an option for lower quality sound which can help
some games to run much faster.


INSTALLING
----------

WARNING: Overclocking your Zodiac may cause crashing with ZodMAME due to it's
intensive use of the ATI chip. This is not a fault of ZodMAME but timing
problems can occur with the ATI chip when the CPU is overclocked. 

Simply Hotsync the ZodMAME-Installer.prc file and this will automatically 
install the program, make sure your SD card is inserted into Slot1 before
doing this.

You'll need the following directory structure on the SD card:
/PALM/Programs/ZodMAME/roms/
/PALM/Programs/ZodMAME/samples/

Put your 0.36 version ROMS (zipped) into the roms directory on the SD card.
They MUST be 0.36. You can use clrmamepro to create 0.36 roms from the latest
versions of MAME.

Put the sample files (zipped) into the samples directory. Some MAME games need
these for sound, i.e. Space Invaders, etc.

If you want artwork in Vector games (only a few are supported) then unzip the
artwork.zip file (from the ZodMAME web site) into the artwork directory.

Some MAME games are very memory intensive, ZodMAME uses "Storage Memory" to
load graphics and sound ROMS so most games should load fine but there are some
which are simply to big to run. ZodMAME does not require UDMH for extra memory
as it does this internally and I'd recommend not using UDMH if you have data
on your Tapwave that you don't want corrupting, which UDMH can do. ZodMAME
writes to "Storage Memory" safely so nothing should get corrupted if
a game crashes.

You can put your MAME roms in a different directory, if so you need to change 
the ROM directory preferences in the launcher.

NeoGeo games are not supported by ZodMAME, I wrote ZodNEO to support those
games.


CREATING 0.36 ROMS
------------------

The best way to get your latest MAME roms into 0.36 format is to use the ROLLBACK
ROMS, have a search on google for "mame romset rollback torrent". I prefer ROMCENTER
for fixing the roms. You'll need to generate a v0.36 datfile for ROMCENTER, there's
information on this around the Internet. Get the NEOGEO roms you want to convert 
into a seperate directory, add that path to ROMCENTER, then add the path of the 
ROLLBACK ROMS and your original latest version MAME ROMS. Select the path with your 
ROMS you want to convert, choose the ROMS to convert, right click and do "Fix". It 
then magically converts them to v0.36 format!


USING IT
--------

NOTE: Make sure bluetooth is switched off for maximum performance - it does
slow down the emulator - use BlueFang.

The first time you run ZodMAME the screen will flash black once for each
module as it queries it to find out what games are supported. Whenever you add
or remove a module you will need to use the menu option to search for modules
again and update this list.

The games listed will show the game as being available on the SD card if the
colour of the Game Description is in blue, if it is black it isn't available. 
If it is green then it is a favourite.

If you run a game and it comes right back to the menu then it means your
romset is invalid or not found. If it says it has run out of memory then the
game requires more memory than the Zodiac can supply (by default). 

All the controls are preconfigured for the Zodiac. 
* Four action keys (coloured) map to the Player 1-4 buttons. These also map to
a right joystick for games such as Robotron, BattleZone, etc.
* Right trigger - add coins
* Left trigger - player one start
* Function - UI menu, use joystick select for enter key
* Power Button - pauses the game
* Launcher - Exit MAME (escape key).

The touch screen is split into 4 areas as follows:
* Top Right - switch off/on throttling and frameskip. Useful during the
initialisation phase of a game to speed up the game. Can also be used for
games that don't run at full speed and you would prefer smoother framerate.
* Bottom Right - switches Frame Rate display on and off.
* Top Left - nothing (spare key which generates A key)
* Bottom Left - nothing (spare key which generates C key)

The Menu item "Games > Export Favs", exports your favourites to the Memopad as a
list. You can use this to backup your favourites. You can also easily import
your favourites list by updating the Memopad Note, inserting the list of games
seperated by new lines. Use the "Games > Import Favs" to import the Memopad
list into ZodMAME's favourites.


ZodMAME's homepage is at:
http://zodiacstuff.sourceforge.net/ The source code is in SVN (Subversion).

The ZodMAME Game compatibility list is at:
http://zodiacstuff.sourceforge.net/ZodMAME_compatibility.html

ZodMAME is a free program, developed in my own time. Any donations are
appreciated, and will provide incentive to carry on developing it :)


CHANGE LOG
----------

v1.3 29/08/07
* ROM directory is now configurable in the launcher
* Performance boost for many graphics drivers. CPS1 games have a big boost from this
  tuning with smoother framerate changes.
* Added simpsons support, woohoo!
* Added parodious and aliens support
* bombjack graphics driver tuning, near full speed now with Hi sound.
* Added artwork for Vector games

v1.2 07/07/07 *RETURN RELEASE* (back developing...a bit)
* Moved directory from /PALM/Programs/PalmMAME/ to /PALM/Programs/ZodMAME/ to avoid conflicts 
  between the different MAME versions.
* Implemented Protected Feature Memory (Storage Memory) loading of GFX and SFX Roms for big 
  games. UDMH is not required anymore. All writing to Feature Mem is done safely to avoid any 
  corruption, unlike UDMH!
* Added Favourites Export/Import to Memopad
* Fixed CPS1 graphics transparency/masking issues.
* Put back CPS1 "ghouls" support, still crashes when exiting but no longer corrupts Tapwave
  as UDMH isn't used anymore.
* Fixed graphics drawing problems with JrPacman, Pac-Land, Dig Dug and related games.
* Added 11khz sound rate option (low, high) for lower sound quality but faster speed.
* Added colour fixes from Vilmos, fixes most games that had colour corruption before
  like "Ghosts'n Goblins", "Tapper", "Rampage" etc. Thanks to Vilmos.
* Fixed "Bosconian" graphics, thanks to Vilmos.
* Rewrote "Missile Command" graphics driver for much faster performance.
* Fixed loading of NVRAM config, Williams games now don't need starting twice.
* Added nice "GFX Decoding" wait message


v1.1 15/10/2006 *FINAL RELEASE* (development has now ceased)
* Added Cyclone 68000 ASM core to all modules. Substantial speed up for many 68k games.
  Some that worked before may crash now though.
* Implemented underclocking of MAME CPUs and sound CPUs. Big speedup for many games.
* Samples, such as StarTrek, now load using Storage Memory, i.e. 
  less out of memory errors.
* Graphics optimisations to Capcom CPS1 drawing, some big speed ups.
* 16bit hack to handle 16bit games, thanks Vilmos!
* Vector games memory usage substantially reduced, no more out of memory errors,
  also the startup time has been reduced.
* Various graphical fixes to many games.
* Added favourites support to launcher
* Added Help to launcher
* Fixes to launcher ROM filtering


v1.0 01/09/2005
* Original Release 



THANKS
------

Thankyou to the Tapwave staff (who are sadly no more) for bringing us this
excellent, but overlooked, PDA. Roll on the Micro$oft Juggernaut!

Biggest thanks go to Vilmos who got MAME to run on the PalmOS in the first
place and helped me a lot in this project. Thanks to Squidge for his no-signing
code which will help to keep the Zodiac alive. 


OTHER SOFTWARE OF MINE
----------------------

The following are all available at http://zodiacstuff.sourceforge.net/
ZSpectrum (Zodiac ZX Spectrum Emulator)
CliFrotz (PalmOS Interactive Fiction Interpreter)
ZodSCUMM (ScummVM interpreter for those Monkey Island, Day of the Tentacle etc games)
ZodNEO (NeoGeo emulator optimised for the Tapwave Zodiac)


Enjoy
Simon Quinn (aka Fangorn)
Great Britain, 2007
