PalmMAME 020

Don't forget to search for new roms.  There are a LOT of changes.

Requirements:
- PalmOS 5 an SD card and as much free RAM as possible.  You will need at least 9M free.  Most PalmOS PDAs will also need UDMH which allows storage RAM to be used as dynamic memory.


What's new in PalmMAME 0.20?
 - This is a major fix release falling back to MAME 0.37b5 because 0.37b6 is far too buggy.


What's new in 19?
 - Wow.  Well I decided it was time to upgrade.  So this is almost half-way to my goal of updating to the base MAME 0.37b16
 - So all new working original games from 0.37b1 to 0.37b6 are supported unless they had known problems in which case they are disabled.
 - This makes the file sizes significantly larger as there are updated cpu cores, some new ones and a ton of games.
 - Hacked the CAVE games (Dangun Feveron, Esp Ra. De. and DoDonPachi) to work with palms limited memory.  You must turn off the sound to make these games work and (you might want to sit down) YOU WILL NEED AT LEAST 60MEGS of free RAM to play them.  They work pretty well on the Zodiac though, quite playable.
 - Speedups will be added once the code base is stable again.  Anyone wanting to help optimize the speed should contact me!  Although nothing will be done until I hit the highest MAME version before the speed drops off.
 - NeoGeo module hasn't been updated yet.
 - Artwork has been updated to support later versions of backgrounds.
 - High scores now save and load properly (need a hiscore.dat in your palmmame dir)
 - Smash TV and Total Carnage now work!  


Installing
The loader "PalmMAMELoader.prc" can either be put on SD card, or in regular memory.
The modules must be installed to SD card in the directory /palm/programs/palmmame.  The modules aren't "real" prc files so they cannpt be hotsynced, use an SD card reader or equivalent to move the modules to your SD card.
Roms are NOT provided with PalmMAME, you must find them yourself.
All roms must go on SD card in directory /palm/programs/palmmame/roms and they can remain zipped.
Images for the Status Bar must go on SD card at /palm/programs/palmmame/StatBar/

Sound samples and artwork is supported.

Summary of directory structure on SD card

Modules:	/palm/programs/palmmame/
Roms:		/palm/programs/palmmame/roms/
Samples:	/palm/programs/palmmame/samples/
StatusBar:	/palm/programs/palmmame/StatBar/
Artwork: 	/palm/programs/palmmame/artwork/


Top Three Frequently Asked Questions

Q: The screen says type OK to continue. How do I do that?

A: Left then Right will bypass this screen. Use whatever buttons you configured to left and right.

Q: Why did my game go straight back to the launcher?

A: Your romset is not found or is invalid. Remember ROM files MUST be in 0.36 format. If it works on the PC version of MAME 0.36 then it will work in PalmMAME.

Q. So what are those two boxes on the loader screen with numbers?

A. They allow you to underclock the emulated cpus. You see when you emulate a game like say PacMan, the emulated cpu is doing all the work the original would be -- and that includes sitting there idle waiting for the next piece of work to do! So the idea is to lower it so that the emulated chip is working harder and we end up with a faster game. Most games work fine with both CPU and Audio chips at 80% Some games work great even much lower. You will have to experiment to see what works fastest. Short Answer: Set them to 80 each to speed up the games!


Help!

PalmMAME (and the original MAME) are both complicated programs. For detailed instructions or help visit the forums. There are plenty of people willing to help there.


***For more help or information come join the discussion forum at
http://www.pocketdimension.com

History
What's new in 18.1?
- Added initial support for some IR keyboards:  Targus Keyboard (Model No: PA870), Universal Wireless Keyboard by palm (SKU: 3169WWZ), Stowaway IR Keyboard (Qwerty and Azerty)
- Fixed numerous memory leaks.  Still one left when using 8bit games and the status bar on non-Zodiac machines.

What's new in 18?
- New launcher which supports ratings per ROM.
- Set each game config from launcher
- Default settings for games without specific config settings
- ARM ASM routine to speed up all 8-bit games on Zodiac (anywhere from 3-10fps depending on the game)
- ARM ASM routine to speed up 8-bit games with a modifiable palette on all devices. (anywhere from 3-10fps depending on the game and device)
What's new in 17.7?
- Increased stability.  Far fewer crashes when exiting a game back to the launcher.
- Sound works on Treo 680 and 700p.  Only HI quality sound works well.  Low quality sound only works on palmOS devices without NVFS.
- Added more optimized asm functions to improve speed.
- Small bug-fixes to launcher to help prevent crashes.
- Known bugs:  pacman games crash after extended play, launcher crashes if powered off on rom list.

What's new in 17.6?
- Added some source from ZodNeo to allow larger games to run.  Thanks Fangorn!  This adds the following NeoGeo Games as playable: The King of Fighters '94, Art of Fighting 2, Savage Reign, Samurai Showdown 2, World Heros 2 Jet, Aggressors of Dark Kombat, Voltage Fighter Gowcaizer, Breakers, Magical Drop 3, NeoGeo Cup '98.  Also added are 5 more NeoGeo clones:  puzzldpr, 2020bbh, burningh, songokh, maglordh.
- Reduced module sizes (which also means memory used) by between 500K and 1M each.  All except NeoGeo which stays almost the same, it gained a few kilobytes.
- Fixed loader crash when searching by name was used
- Updated Cyclone to 86 which gets all the Sega16 games working with Cyclone and fixes a few other misc games as well. 

What's New from version 17?
- Reduced memory usage.  The loader can be in ram or SD card.  The modules MUST be on SD card.
- Fixed Joust.  
- Started to update loader.  I haven't finished that yet, but you can enjoy the changes so far.   
- Fixed rotation cutting off screen
- Note:  Program startup and Searching for ROMS will now just blank the screen for a bit.  That's normal and for searching it can feel like a long time, just let it go.
- Added Zodiac hardware acceleration and screen stretching (don't choose scale if you have a Zodiac, it is already on)
- Added more error checking and reporting in loader
- Reduced memory usage of loader
- Fixed some misc loader bugs
- Added Cyclone 0.86 which fixes several games so they may gain extra speedups from this asm 68000 core (hwchamp, riot city, sdi, shdancer, toryumon, hangon, shangon,outrun, blstroid, cchasm, relief, skullxbo, toobin, vindictor, gauntlet, gauntlet2)
- Added artwork support which is essential for some games such as Armor Attack.  Artwork downloads are available in a separate download.
- Zodiac display problems fixed.  (mostly, a few games still have problems such as Gorf and cchasm but they can be played when rotated.)

