MESS 0.36 for PalmOS ported by Vilmos (aka Andrew Kearns)
Comments or donations can be sent to support@pocketdimension.com

MESS stands for Multi Emulator Super System.  MESS is integrated into MAME (Multi Arcade Machine Emulator)

The idea behind MESS is to emulate everything that isn't an arcade machine.  That includes all the consoles and computer systems.

This is a preliminary release where you can use it, but there is lots more to do before I would call it complete.  It has an insane number of systems so I also haven't been able to test all of them.

Installing:

First you need to install PalmMAME.  Install the loader to internal memory or an SD card in /palm/launcher.
If you want to also play arcade games you can install as many modules as you like to /palm/programs/palmmame.  The PalmMESS module is also installed to /palm/programs/palmmame on the SD card.

PalmMAME also comes with a completely skinnable statbar which shows icons during emulation.  Place the entire statbar directory in /palm/programs/palmmame.  Go to www.pocketdimension.com for more statbar themes or skin your own icons and share them in the forum!

Next you need to make the rom directory where palmmame roms are placed:
/palm/programs/palmmame/roms

for PalmMESS you need to make another directory inside for each system, for example:
/palm/programs/palmmame/roms/coleco

Any system roms (bios files) as well as the image files (cartridges, tapes and floppies) are also put in the above directory.  When you run PalmMESS and launch a system it will show all the files it is trying to find for the bios.

Please note:  Zip files are not working for PalmMESS, please unzip roms and images.


Starting up MESS:

First start up the PalmMAME launcher (PMAME) and let it search for modules (the screen will flash).
Second drop down the menu and choose key config.  For the Zodiac I suggest using:
Exit:  House button
P1 Credit: Right Trigger
P1 Start: Left Trigger
Up: Joy up
Down: Joy Down
Left: Joy Left
Right Joy Right
Button 1-4 are the colour action buttons (whichever order you like)
Menu: Function button
Menu Select: Joystick button
Pause: Power
Reset: nothing

Next tap the back button and open the menu again this time choosing MESS.

The MESS screen is a simple command-line with a few helper buttons and options available.  The buttons on the top will just add the text to the command-line which is used to start up MESS.

To use the command-line for MESS you need to enter:
	<system> <device> <image_name>

So for example if you wanted to run an image of GateWay to Apshai on the Colecovision you would enter:

	coleco -cart apshai

then click on the Go button and MESS would be started and attempt to find the bios and image files in /palm/programs/palmmame/roms/coleco.

The command-line is temporary and has a few limitations, the largest being filenames can not have spaces in them.  I would suggest naming them something short as well since you have to type it each time.

If all goes well you will start up the colecovision and the game just like a MAME game.  Coleco has a numeric pad as well as the regular console buttons.  These buttons can be configured just like in MAME by bringing up the menu and changing the specific buttons for your controller or you can try tapping the FPS button on the statbar and it will bring up a keyboard.  Unfortunately the keyboard is not finished yet (the graphics aren't done) but the layout is there and the buttons will work if you can sort out what they are.  ;)

The <device> can be: -cart -flop -tape
Check the MESS help which is also included and shows a chart for the systems and devices supported.

Currently Supported Systems in this release (Yes there are more that are disabled!):

Internal name		Description

a5200				Atari 5200
a7800				Atari 7800
astrocde			Bally Astrocade
coleco				ColecoVision (Original BIOS )
nes					Nintendo Entertainment System
gameboy				Nintendo GameBoy Handheld
gamegear			Sega Game Gear Handheld
vectrex				General Consumer Electric Vectrex - 1982-1984
raaspec				RA+A Spectrum - Modified Vectrex
advision
apple2e				Apple //e
macplus				Apple MacIntosh Plus
a800				Atari 800
c16					Commodore 16
c64					Commodore 64 - NTSC
pet					Commodore PET
coco3				Tandy Color Computer 3
pccga				IBM PC/XT with CGA
zx81				Sinclair ZX-81
			
