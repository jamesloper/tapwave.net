Thruster 1.0 Released!  Merry Christmas, have a free game from me.

Contact:  support@pocketdimension.com

Thruster is a fast paced cave flyer where the goal is to reach as high as you can without crashing while eroding the landscape with your thruster.  To do so you will need some fast reflexes and a good eye.

[b][url=www.pocketdimension.com/PD2_DL/Thruster.zip]Download Thruster[/url][/b]

[img]http://www.pocketdimension.com/PD2_DL/Thruster_image1.jpg[/img]

[img]http://www.pocketdimension.com/PD2_DL/Thruster_image2.jpg[/img]



Featuring:
- Three different game modes
- Two difficulty levels
- High score tables with replay - You can watch previous games and see how the high scores were done.  High scores will be tracked online soon.
- Beautiful backgrounds by Mentis and Mrpropre
- Three included mp3 tracks with the ability to add any MOD or MP3 files to the tracklist.
- More than 2K particles in play at once
- Alpha blended explosions

Installation:
Included in the zip is an installer program.  Just run ThrusterInstaller.exe and hotsync.

How to play:
Fly as high as you can, erode the landscape with your thruster.
Joystick moves left/right, the more you push the faster your ship turns.
Blue/Yellow/Right Trigger is the Thrust button.
Function is pause.

Customization:
Add music in MOD or MP3 format to /palm/programs/Thruster/sounds
Make sure the filename isn't huge, max of 256 characters including the full path to the file.

Credits:
Programming - ANDREW KEARNS
Music and Art - MICHAL WISNIOWSKI
Art - MRPROPRE

Thanks to the author of Spout who gave me the inspiration to make this game.  Thruster is 100% new code done originally to enter into the DCEmu contest, but unfortunately that contest was cancelled.  

Thanks also to all the testers who kept me going.[/url]