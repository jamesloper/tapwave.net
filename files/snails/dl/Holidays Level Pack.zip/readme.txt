SNAILS - THE LONG LOST HOLIDAY BETA
Official Levels and Music

Levels: Randall Schleufer
Gingerbread Ghetto (ginger.lev)
Sketchworld (gingersketch.lev)
Grannies House (gifts.lev)

Music: Jason "Jaybot" Surguine
Moogolph.xm


These levels contain the new structure for .LEV files (Level).

::::::::: SNAILS 1.7 (or above) :::::::::

1.) Unzip these files into the MAIN Snails folder, ensuring the directory structure remains intact.

2.) Run Snails and it will automatically compile a list of all valid levels without further modification.


::::::::: SNAILS 1.6 (or below) :::::::::

1.) Unzip these files into the MAIN Snails folder, ensuring the directory structure remains intact.

2.) Search the "\LEVELS" folder for the GINGER.LEV file. Open it and copy the entire contents.

3.) Go back to the main Snails folder, and open the LEVELS.DAT file. Append/paste the contents of GINGER.LEV to the end of the LEVELS.DAT file. Save LEVELS.DAT

4.) Follow this sequence for GINGERSKETCH.LEV and GIFTS.LEV.

5.) When finished, run Snails and the new levels should appear at the end of the levels list.


:::::::::: STUFF :::::::::::

These levels were initially released as a beta during the 2001 Holiday Season. After the game was launched, these levels were never seen again.

I recently found these levels hidden in a far off corner of Guffies shell, while I was doing his laundry. After confronting him and slapping him with a dead trout, he spilled his guts.

During the Holiday beta, the Moogums were constantly getting their shells whooped. They devised a plan to eradicate this embarrassment by destroying the last remaining bytes of Gingerbread Ghetto and Grannies House. Apparently they tried to suffocate the levels by stuffing them in Guffies sock drawer.

Other than smelling like rotting cheese, these levels are fully intact and good as the day they were created. Have fun.

