Install the PRC to the internal/SD memory. It will create a new folder on the launcher called 'XFExamples'. Open the PRC for it to create the directory on the sd card, it will crash :P

now insert your sd card, go to 'PALM', 'PROGRAMS' then find Hockey... folder, place the pack.cfl file into there, put back into zodiac, and play :)

Installation readme by X/ZMAN
http://www.pda.plankfilms.com (Plank Films Mobile)