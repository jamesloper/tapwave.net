Spout version 11a
Original website is here (includes PC version):
http://www.din.or.jp/~ku_/index.htm (japanese only)

ported to Zodiac by Andrew Kearns Aug 25, 2006

How to play:
Your goal is to fly as high as you can.  Use your thruster to erode the landscape.  
The game is over when the white dot at the center of your ship collides with a wall.

Controls:
Right Trigger and actions A, B and C thrust.
Function pauses.
Home quits to menu, then quits to launcher.

Installing:
You can play Spout from the card or regular RAM.
If you place it on SD card it must be in /palm/launcher

Music:
MOD music will play if you have MOD tracker files located on the SD card at /palm/programs/Noiz2sa/sounds
If you haven't downloaded and run Noiz2sa for Zodiac then you will need to create this directory and add some music to it.  You can get MOD tracker files from http://www.modarchive.com/

To download other games for your Zodiac such as Noiz2sa visit http://www.pocketdimension.com

Thanks to testers:
Charles and Mrpropre
Also thanks to Mrpropre for the snazzy icons!

