*********************************************************************
*                     Tapwave HDK - Readme File                     *
*                                                                   *
* IMPORTANT: Read before using the Tapwave Hardware Developer's Kit *
*********************************************************************

This HDK is designed to provide the necessary hardware information
to create peripherals for the Tapwave Zodiac 1 and 2.

=====================================================================
 WHAT'S INCLUDED IN THE HDK
=====================================================================

* CAD
  CAD files for the Zodiac 1 and 2.

* Documentation
  Tapwave hardware documentation.

=====================================================================
 WHAT'S NEW  / ENHANCEMENTS AND FIXES    --   R1 (2/06/04)                        
=====================================================================

* Created the HDK.

See below for a change history of the hardware developer's kit.

=====================================================================
 KNOWN ISSUES                                                      
=====================================================================


Tapwave, Inc.
1901 Landings Drive
Mountain View, California 94043
(650) 960-1817
http://www.tapwave.com/developer



=====================================================================
Change History:

