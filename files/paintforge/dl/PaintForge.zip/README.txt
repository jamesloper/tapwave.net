
This is the preview version of Paint Forge, dated 2003-11-08.
You most probably need the DAA (Developer Access Application)
to be able to run this.

To install the program, just copy the contents of the PALM
directory to your SD card. There is only these two files
which must be in correct locations:
PALM/Launcher/PaintForge.prc
PALM/Programs/PaintForge-PFrg/font16.pcx

Author's home page: http://iki.fi/sol/


I put this available by request from the author (Jari Komppa).


		- Jetro Lauha, 2005-08-27 - http://jet.ro
