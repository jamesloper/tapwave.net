READ ME
-------
EDGE 1.0

(c)2005 by R. Zane Rutledge and ZaneGames. All Rights Reserved.



Please see http://www.zanegames.com for all FAQ or any further information.

Installation Instructions are contained in the EDGE User Manual (Adobe Acrobat may be required to read it) and repeated below. Lots more useful information is in the manual, and even more online. The latest version of the User Manual can always be downloaded from http://www.rzanerutledge.com/edge/EDGE_UserManual.pdf.

Visit the support forums or online live chat at http://www.zanegames.com.

Thank you for downloading, and I hope you enjoy the game.



HARDWARE REQUIREMENTS


PalmOS

EDGE was originally designed for PalmOS 5 and higher devices with a 320x320 (or higher) resolution. It requires a minimum of 6.5MB of available free RAM. Some of the required database files can be installed to an external data card (SD, Memory Stick, or other) and accessed through VFS (virtual file system). While the main Edge_Data and Edge_Maps databases can also be installed to RAM (if enough storage RAM is available on the device), all sound and music files require use of an external card. The game can be played without an external card if all three .prcs are installed to RAM, but no sound will be available without being installed to external card.


PocketPC

EDGE can also be played on PocketPC devices with the use of the StyleTap application, which allows many PPC devices to run PalmOS software. (See www.styletap.com for download and purchase instructions.) StyleTap version 0.9.085 or higher has been optimized for full compatibility with EDGE. The memory requirements are the same as the Palm version.

EDGE runs best on a newer VGA device in either 66% mode (at 320x320 resolution, as on PalmOS) or in 100% mode (at 480x480 resolution). In 100% mode, EDGE�s 320x320 playfield will be scaled up to 480x480. This will result in some jaggedness of fonts and some pixilation, but will be closer to full-screen.

EDGE can be played on a 240x320 QVGA device as well, although the game will be scaled down from 320x320 to 240x240, which may make some text hard to read and graphics will lose some fidelity.



INSTALLING EDGE

PalmOS

Make sure you meet the hardware and RAM requirements above. If you have an external card, install it into your device and place your device in a cradle (or choose to install EDGE directly to card using a card reader, if available).

The EDGE Automatic Installer can be used to install these files correctly to either RAM or card, or they can be installed manually into the proper directories of the external card using a card reader. (Choose the Automatic Installer online, or use the contents of this zip file to install manually, as described below.)

If installing entirely to external card:
The Edge.prc application should be installed to the /Palm/Launcher folder. Edge_Data.prc and Edge_Maps.prc should be installed to an /Palm/Programs/Edge folder. All .ogg files (sound files) should be installed into a /Palm/Programs/Edge/Sound folder.

If installing to RAM:
The Edge.prc application, Edge_Data.prc and Edge_Maps.prc should be installed to RAM. (A remaining 6.5MB of free RAM is also required to run EDGE.) All .ogg files (sound files) should be installed into a /Palm/Programs/Edge/Sound folder on an external card, if available.

NOTE: Installing the Edge_Data.prc and Edge_Maps.prc databases to RAM will result in slightly faster load times and less pauses during game play, at the sacrifice of available RAM. Also, the access speeds of different brands of external card may affect any pauses, delays, or loading time while playing from card.


PocketPC

All files should be installed to the same folders as listed in the PalmOS instructions. The Edge.prc application should be installed to RAM with the StyleTap Application Installer. The Edge_Data.prc and Edge_Maps.prc can either be installed to RAM or on the card in the /Palm/Programs/Edge folder.

EDGE can be installed directly to RAM using the StyleTap Application Installer. Drag the Edge.prc application, Edge_Data.prc and Edge_Maps.prc into the Installer window and Transfer them to the device. The .oggs should be placed on an external card using a card reader.


More information is available online or in the EDGE User Manual.

(c)2005 by R. Zane Rutledge and ZaneGames. All Rights Reserved.

